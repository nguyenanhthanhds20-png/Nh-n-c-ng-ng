# Phân tích workbook `_TínhĐườngTên_1.xlsx`

## Nội dung và đầu vào

Workbook có ba sheet. **Đường tên HOÃN HÒA** tính đường tên kế hoạch với R = 500 m, L1 = L2 = 40 m, KT = 276 m, C = 20 m. **Đường tên CONG TRÒN 546+324** dùng R = 2.000 m, L1 = L2 = 0 m, KT = 441,62 m và C = 20 m. **Sheet1** tính T, P và KT từ bán kính cùng góc độ–phút–giây.

Trong hai bảng đường tên, E3:E7 lần lượt là R, L1, L2, KT và C. Tất cả chiều dài nhập bằng mét; FKH, Fc, Z1 và Z2 tính bằng milimét. Điểm đo cách nhau h = C/2. NĐ là đầu hòa hoãn vào; TĐ là đầu cong tròn; TC là cuối cong tròn; NC là cuối hòa hoãn ra. Khi một hòa hoãn bằng 0, các mốc tương ứng trùng nhau.

## Mô hình tính được tổng quát hóa

Mô hình gốc là xấp xỉ góc nhỏ, với đường tên cong tròn `Fc = 1.000 × C²/(8R)` mm. Độ cong tăng tuyến tính từ 0 đến 1/R trên L1, giữ 1/R trong đoạn cong tròn và giảm tuyến tính về 0 trên L2; ngoài đường cong, độ cong bằng 0.

Với x là vị trí tâm dây cung tính từ NĐ, công cụ tính:

`FKH(x) = 500 × ∫[x−h,x+h] (h−|t−x|) × κ(t) dt`, trong đó h = C/2.

Tách tích phân tại các mốc 0, L1, KT−L2, KT và x làm cho mỗi phần là đa thức bậc hai. Tích phân Simpson ba điểm trên từng phần cho kết quả chính xác trong **mô hình độ cong tuyến tính này**, không phải một phép tính chính xác cho mọi hình học đường cong. Cách tính trực tiếp xử lý được L1/L2 không bằng nhau, bằng 0, ngắn hơn h, vị trí điểm đo lệch mốc và KT không chia hết cho h.

Một điểm nằm sau NC vẫn có thể có FKH khác 0 nếu dây cung còn phủ một phần đoạn cong. Vì vậy bảng có cả điểm lưới đầu tiên nằm tại hoặc sau NC, không cắt kết quả theo điều kiện x ≤ KT.

## Điểm cần sửa khi dùng file cho số liệu mới

Sheet hòa hoãn chia cho L1 và L2 nên nhập 0 có thể gây `#DIV/0!`. Sheet cong tròn có điều kiện dùng `E6/10`, chỉ trùng với bước C/2 khi C = 20 m; không phù hợp nếu đổi C. Công thức đuôi C219 của sheet này có `#REF!` và không có kết quả lưu sẵn. Một số helper làm tròn trung gian tới 2–3 chữ số, còn Sheet1 dùng cả π = 3,14159 và π = 3,141592653.

Ứng dụng không sao chép các lỗi này. Kết quả được tính đầy đủ độ chính xác; FKH hiển thị làm tròn đến số nguyên mm, các đại lượng khác giữ độ hiển thị cũ. Excel dùng định dạng số nguyên ở cột FKH nhưng vẫn giữ số gốc để không làm mất độ chính xác. T/P/KT dùng Math.PI thống nhất. Các ô phụ A1/B1/C1/D1 trong file không được coi là tham số người dùng độc lập; thay bằng khoảng lệch thực tế của điểm đo đầu so với NĐ.

## Đối chiếu số liệu thật

Toàn bộ 29 điểm hòa hoãn và 46 điểm cong tròn có kết quả lưu sẵn được đưa vào kiểm thử. Sheet cong tròn trùng mô hình tính trong sai số số học. Sheet hòa hoãn chỉ lệch ở vài giá trị helper do làm tròn trung gian, tối đa khoảng 0,003334 mm.

| Trường hợp | Kết quả trong mô hình tổng quát |
| --- | ---: |
| Hòa hoãn, Fc | 100 mm |
| Hòa hoãn, Z1 = Z2 | 25 mm |
| Hòa hoãn, FKH tại x = 0 m | 4,166667 mm |
| Hòa hoãn, FKH tại x = 40 m | 95,833333 mm (Excel: 95,83) |
| Hòa hoãn, FKH tại x = 280 m | 0,9 mm |
| Cong tròn, Fc | 25 mm |
| Cong tròn, FKH tại x = 0 m | 12,5 mm |
| Cong tròn, FKH tại x = 440 m | 16,22195 mm |
| Cong tròn, FKH tại x = 450 m | 0,32805 mm |

Sheet1 dùng `α = (độ + phút/60 + giây/3.600) × π/180`; `T = R tan(α/2)`, `KT = Rα`, `P = R[1/cos(α/2)−1]`. Với R = 100 m và góc 16°46′23″, kết quả lần lượt là khoảng 14,742690 m, 29,274505 m và 1,080893 m.

## Phạm vi và kiểm tra dữ liệu

Công cụ dành cho **đường cong đơn một bán kính** và mô hình hòa hoãn có độ cong tuyến tính như workbook. Không tự áp dụng cho đường cong ghép, ngược, mô hình hòa hoãn khác hoặc tính toán thiết kế cần tọa độ/hình học chính xác. Không thực hiện bình sai thực đo, tính dịch chỉnh, siêu cao hay đánh giá theo tiêu chuẩn khi chưa có yêu cầu và dữ liệu.

Phải có R > 0, KT > 0, C > 0, C < 2R, L1/L2 ≥ 0 và L1 + L2 ≤ KT. Khoảng lệch điểm đo đầu thuộc [−C/2, C/2). Bảng giới hạn 10.000 điểm và báo lỗi rõ ràng thay vì cắt bớt; vị trí bất kỳ có thể tính riêng. Khi C/R > 0,1, giao diện cảnh báo xấp xỉ góc nhỏ có thể sai lệch đáng kể; đây là cảnh báo về độ nhỏ của góc, **không phải tiêu chuẩn nghiệm thu**. Kết quả cần được người có chuyên môn kiểm tra trước khi dùng ngoài hiện trường.

## Cách nhập/xuất

Nhập file .xlsx/.xls tương thích với bố cục E3:E7 hoặc workbook được xuất từ công cụ. Các sheet thông số hợp lệ được chọn riêng; số liệu không tự ghi đè dữ liệu của tab Tra cứu/Nhân công/Sơn cầu/CHATBOT. Lý trình NĐ không tự suy từ tiêu đề tự do của file; người dùng nhập lại theo dữ liệu thực tế.

File xuất gồm thông số, bảng đường tên đầy đủ, các mốc chính xác và phần T/P/KT tính riêng khi có. Phần T/P/KT không mặc nhiên là cùng đường cong của bảng FKH, trừ khi người dùng bấm áp dụng R/KT. Các giá trị xuất là số, không phải chuỗi đã làm tròn.

## Lưu nháp và an toàn thao tác

Biểu mẫu Đường cong lưu riêng trên trình duyệt; chuyển sang tab khác rồi quay lại vẫn có số liệu đang nhập. Khi localStorage bị chặn, bản nháp còn được giữ trong bộ nhớ của phiên trang hiện tại. Không lưu hoặc sửa dữ liệu nghiệp vụ ở database. Đọc file bất đồng bộ có kiểm tra phiên nhập để không ghi đè biểu mẫu đã được sửa sau khi chọn file. Lựa chọn sheet cũ bị xóa khi sửa số liệu hoặc đổi chế độ.

Phần T/P/KT tính riêng chỉ xuất kèm khi người dùng đánh dấu chọn. R và đơn vị radian/độ được ghi rõ trong sheet riêng. Các trường hợp quá lớn để biểu diễn tọa độ đến milimét hoặc sinh kết quả không hữu hạn sẽ bị từ chối, không hiển thị/xuất NaN hoặc Infinity.

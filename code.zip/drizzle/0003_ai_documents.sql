CREATE TABLE `ai_documents` (
  `id` int AUTO_INCREMENT NOT NULL,
  `name` varchar(255) NOT NULL,
  `mimeType` varchar(160) NOT NULL,
  `sizeBytes` int NOT NULL,
  `storageKey` varchar(512) NOT NULL,
  `storageUrl` varchar(700) NOT NULL,
  `extractedText` longtext,
  `processingStatus` enum('processing','ready','unsupported','failed') NOT NULL DEFAULT 'processing',
  `uploadedBy` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  `deletedAt` timestamp,
  CONSTRAINT `ai_documents_id` PRIMARY KEY(`id`)
);

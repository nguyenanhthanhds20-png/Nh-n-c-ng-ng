# TODO

## Bóc khối lượng trên web
- [x] Truy cập trực tiếp không cần màn hình đăng nhập; hiển thị Admin: Nguyễn Anh Thành.
- [x] Nạp dữ liệu mặc định Quảng Bình Q4/2026 gồm 121 bản ghi.
- [x] Tra cứu theo lý trình, loại đối tượng và tên hạng mục; hiển thị hạng mục công việc, nhân công và vật tư.
- [x] Xuất bản ghi đang xem ra Excel có tiêu đề, gộp ô, độ rộng cột và cố định tiêu đề.
- [x] Cho phép nạp file dữ liệu mới; tự thay dữ liệu tra cứu, nhân công, vật tư và danh sách lựa chọn theo file mới.
- [x] Nhận dạng workbook có tên sheet thay đổi về chữ hoa, dấu hoặc cách đặt tên; có fallback cho bảng có cột Hạng mục/Công việc, Khối lượng và/hoặc Nhân công.

## Nhật ký nhân công
- [x] Chọn hạng mục/đoạn công việc và tháng/năm, tự loại Chủ nhật.
- [x] Tính Khối lượng/người/tháng và KL tổng ngày = Tổng công trong ngày × Khối lượng/người/tháng.
- [x] Cho sửa Số người phân bổ/ngày theo thực tế; các ngày chưa sửa tự cân đối để tổng người bằng tổng tháng.
- [x] Phân bổ tất cả hạng mục theo Nhân công từ trên xuống; hiển thị riêng Khối lượng, khối lượng làm hàng ngày theo Nhân công tra cứu, tổng công ngày và công còn lại.

## Cập nhật phiên bản
- [x] Hiển thị mã phiên bản web và hướng dẫn cập nhật bằng lần triển khai/checkpoint mới; người dùng chỉ cần tải lại trang web để dùng bản mới.
- [ ] Lưu checkpoint và publish bản web online sau khi build/typecheck đạt.


## Tab Sơn cầu
- [x] Thêm tab Sơn cầu dùng cùng font và hệ màu của website hiện tại.
- [x] Tính 3 công đoạn theo định mức mặc định 1 + 3 + 3 phần/m²; cho phép chỉnh từng định mức.
- [x] Lập lịch theo tháng, loại Chủ nhật mặc định, cho phép đổi ngày làm/nghỉ, chỉnh quân số và khối lượng xử lý từng ngày.
- [x] Tự nối Sơn phủ 1 vào ngày làm việc kế tiếp và Sơn phủ 2 vào ngày làm việc sau đó; hiển thị tổng cần, đã xếp lịch, còn lại và vượt kế hoạch.
- [x] Bổ sung meta keywords SEO trang chủ với 6 từ khóa liên quan.


## Cột khối lượng sơn theo ngày trong tab Sơn cầu
- [x] Bỏ cột “Trạng thái” và cột “m²-công/người” khỏi bảng lịch công việc Sơn cầu.
- [x] Thêm ở bên phải bảng hai cột “Sơn chống rỉ (kg)” và “Sơn phủ (kg)”; cả hai cột tự tính theo tổng khối lượng nhập và khối lượng từng công đoạn.
- [x] Tự tính Sơn phủ (kg) từng ngày theo công thức: khối lượng sơn phủ nhập vào ÷ (diện tích sơn gốc × 2) × (khối lượng Sơn phủ 1 + Sơn phủ 2 của ngày đó).
- [x] Tự tính Sơn chống rỉ (kg) từng ngày theo công thức: khối lượng sơn chống rỉ nhập vào ÷ diện tích sơn gốc × khối lượng Xử lý rỉ + chống rỉ của ngày đó.
- [x] Thêm hàng “TỔNG” ở cuối bảng Sơn cầu, tự cộng các cột Số người, Xử lý rỉ + chống rỉ, Sơn phủ 1, Sơn phủ 2, Tổng m²-công, Sơn chống rỉ (kg) và Sơn phủ (kg).
- [x] Xóa cột “Tổng m²-công” khỏi bảng Sơn cầu; hàng “TỔNG” cũng không còn cộng cột này.
- [x] Xóa phần “TỔNG HỢP KHỐI LƯỢNG VÀ NĂNG SUẤT” khỏi tab Sơn cầu.
- [x] Xóa khối “Tổng khối lượng công việc”, giá trị m²-công và số ngày làm việc khỏi phần đầu tab Sơn cầu.
## Trợ lý AI RAILAI
- [x] Thêm tab "Trợ lý AI RAILAI" với giao diện hỏi đáp tiếng Việt, câu hỏi gợi ý và ngữ cảnh từ dữ liệu tác nghiệp đang dùng.
- [x] Kết nối backend thật tới built-in LLM `gpt-5-mini`; không để khóa AI ở frontend.
- [x] Thêm hỏi bằng văn bản, nhận diện giọng nói tiếng Việt qua trình duyệt và đọc câu trả lời bằng Speech Synthesis.
- [x] RAILAI phải nêu rõ khi dữ liệu hiện tại chưa có căn cứ và không tự tạo số hiệu văn bản, điều khoản, định mức hoặc quy trình.
- [ ] Kho tài liệu Admin, upload bền vững, trích xuất PDF/DOC/XLS/PPT/TXT và RAG có trích dẫn trang/mục chưa được kết nối trong giai đoạn này.


## Mở rộng RAILAI
- [x] Khu Admin riêng tại `/admin`; API danh sách, upload và ẩn tài liệu dùng `adminProcedure`.
- [x] Kéo thả/chọn file, tiến trình xử lý và danh sách tài liệu đã tải.
- [x] Lưu file qua storage bền vững và metadata/nội dung trích xuất trong database.
- [x] Truy hồi theo từ khóa từ tài liệu TXT/MD/CSV/JSON/XLS/XLSX, gửi đoạn liên quan vào RAILAI và hiển thị mã nguồn DOC.
- [x] Micro tiếng Việt, cho phép sửa câu hỏi trước khi gửi, dùng chung endpoint RAG với câu hỏi văn bản.
- [x] TTS tiếng Việt tốc độ 0.95, tự đọc tùy chọn và điều khiển phát/tạm dừng/tiếp tục/dừng.
- [ ] PDF/DOC/DOCX/PPT/PPTX hiện được lưu và hiển thị trạng thái chưa trích xuất; cần bổ sung bộ trích xuất chuyên dụng trước khi đưa các định dạng này vào RAG.

## Tinh gọn màn hình chào CHATBOT
- [x] Xóa dòng “Hãy hỏi về một lý trình, hạng mục, nhân công, vật tư hoặc cách lập nhật ký.” và ba nút câu hỏi mẫu: “Km408+00–Km409+00 gồm những hạng mục gì?”, “Tổng nhân công của đoạn đang chọn là bao nhiêu?”, “Giải thích cách phân bổ công việc theo ngày”. Giữ lời chào, khung nhập câu hỏi, kho tài liệu, giọng nói và trích dẫn nguồn.

## Bỏ nhãn dữ liệu tác nghiệp trong CHATBOT
- [x] Xóa nhãn “Dữ liệu tác nghiệp hiện tại: 121 bản ghi” (số lượng động), giữ lại “Trợ lý AI chuyên ngành Đường sắt Việt Nam” và không ảnh hưởng kho tài liệu hay chức năng hỏi đáp.

## Tự tra cứu file khi hỏi CHATBOT
- [x] Mỗi câu hỏi tự truy hồi nội dung các file đã tải; không gửi dữ liệu tác nghiệp mặc định vào yêu cầu AI.
- [x] Trích xuất PDF có lớp văn bản khi tải và tự lập chỉ mục lại PDF đã lưu nhưng chưa đọc được; PDF scan báo cần OCR, không coi tên file là căn cứ trả lời.
- [x] Tìm kiếm tiếng Việt có/không dấu nhất quán, chọn đoạn phù hợp trong toàn văn thay vì chỉ đoạn đầu; giữ nguồn [DOC-N] và từ chối khi không đủ căn cứ.
- [x] Phân biệt kho rỗng, file chưa lập chỉ mục, không tìm được đoạn phù hợp và lỗi truy cập kho; hiển thị trạng thái tải file đúng thực tế.

Kết quả kiểm tra: hai PDF cũ đã lập chỉ mục thành công (41.904 và 367.989 ký tự). Đã hỏi thật về phạm vi áp dụng tiêu chuẩn tà vẹt và nhận câu trả lời kèm [DOC-N]. Đã rà soát độc lập và bổ sung kiểm thử không coi tên file là căn cứ nếu nội dung không khớp.

## Câu trả lời CHATBOT rõ ràng, cụ thể theo file
- [x] Trả lời trực tiếp từng câu hỏi/ý hỏi theo đúng thứ tự; giữ tên gọi, số liệu, đơn vị, điều kiện, công thức và số mục trong nội dung truy hồi, không đoán phần thiếu.
- [x] Phân biệt trả lời diễn giải với trích nguyên văn; giữ thứ tự bước/danh sách và trình bày bảng khi dữ liệu đọc được đầy đủ, báo rõ bảng/công thức lỗi trích xuất.
- [x] Mỗi ý có căn cứ [DOC-N]; câu hỏi nhiều ý được tìm đoạn riêng, cung cấp vị trí trang trích xuất khi có và cho xem đầy đủ đoạn nguồn trong giao diện.
- [x] Hiển thị câu trả lời với tiêu đề, danh sách và bảng dễ đọc trên điện thoại; không cắt ngắn câu trả lời vì giới hạn quá thấp.

Đã thử câu hỏi thật gồm hai ý (phạm vi áp dụng và quy định ghép nối tà vẹt), nhận trả lời riêng và trích nguyên văn kèm nguồn PDF. 29 kiểm thử đạt, gồm render tiêu đề/danh sách/bảng, giữ số liệu và chặn HTML/ảnh nhúng.

## Nút trở về để hỏi câu khác trong CHATBOT
- [x] Thêm nút “Trở về / Hỏi câu khác” ở cuối cuộc hỏi đáp; trở lại màn hình hỏi mới, xóa nội dung hội thoại đang hiển thị và tập trung vào ô nhập câu hỏi.
- [x] Dừng đọc câu trả lời và dừng nhận giọng nói khi trở về; không xóa file trong kho hoặc thay đổi các tab khác. Khóa nút khi đang chờ CHATBOT trả lời để tránh câu trả lời cũ quay lại.

## Xóa file ngay trong CHATBOT
- [x] Hiển thị nút thùng rác “Xóa” cạnh từng file ở mục “File đã lưu”, chỉ cho Admin; tên file và nút không bị tràn trên mobile.
- [x] Hộp thoại xác nhận nêu đúng tên file, có Hủy/Xóa khỏi kho; báo rõ đây là ẩn khỏi danh sách và ngừng dùng cho câu hỏi mới, không xóa vĩnh viễn bản gốc storage hay thay đổi câu trả lời cũ.
- [x] Trạng thái đang xóa, chặn bấm lặp; chỉ bỏ file khỏi danh sách sau khi API thành công, làm mới kho và hiển thị lỗi nếu thất bại. Kiểm thử API chặn người dùng không phải Admin bằng mock, không xóa tài liệu thật khi test.

Đã kiểm tra 36 test thành công, gồm 7 test mới về nút xóa và quyền Admin. Chỉ dùng dữ liệu mock khi kiểm thử xóa; không xóa hai PDF thực tế của Admin.

## Thu gọn bố cục tab Sơn cầu
- [x] Giữ nguyên toàn bộ nội dung, dữ liệu đầu vào, công thức, cân đối người/khối lượng, ngày nghỉ và thứ tự công đoạn; chỉ thay cách sắp xếp và khoảng cách hiển thị.
- [x] Bố trí phần thiết lập gọn phía trên để lịch có toàn bộ chiều ngang; bảng đủ 8 cột, tiêu đề dài tự xuống dòng, giữ Sơn phủ 1 và Sơn phủ 2 luôn nhìn thấy khi dùng bảng.
- [x] Giảm khoảng trắng, chiều cao dòng và cỡ ô nhập hợp lý; màn hình nhỏ vẫn đủ nội dung trên thẻ dọc, không ép chữ quá nhỏ hoặc che mất số liệu. Bảng tổng hợp giữ đủ các cột và dòng tổng.

Đã đối chiếu byte-for-byte toàn bộ state/công thức Sơn cầu và 82 nhãn/nội dung/thuộc tính ô nhập/handler không thay đổi. Kiểm tra Preview: desktop 1280 px, bảng 940 px vừa vùng chứa, đủ 8 cột; mobile 390 px không tràn ngang, đủ 31 thẻ ngày và Sơn phủ 2. 36 kiểm thử và bản build đạt.

## Xuất Excel tra cứu đường theo mẫu người dùng gửi
- [x] Dùng bố cục sheet hiện hành “ 539 - 540” trong mẫuxuấtexcel.xlsx: quốc hiệu, Công ty CP Đường sắt Quảng Bình, tiêu đề biên bản BDĐK, loại sản phẩm, tháng/năm, lý trình, thành phần, công việc, tổng công, vật tư và chữ ký trên một sheet.
- [x] Cột công việc: TT, Hạng mục công việc (gộp B:C), Đơn vị, K.lượng, Đ.mức, T.công; cột vật tư: TT, Tên vật tư - Quy cách, Đơn vị, Số lượng, Ghi chú. Dữ liệu luôn lấy từ bản ghi đang chọn, giữ thứ tự và không sao chép số liệu mẫu cũ.
- [x] Times New Roman, kẻ khung, gộp ô, căn chỉnh và xuống dòng; khối lượng/công/vật tư một số lẻ, định mức bốn số lẻ, công thức SUM tổng công có giá trị lưu sẵn. Không đổi số liệu nguồn hay tự thay công bằng phép chia định mức.
- [x] Khổ in A4 dọc, vùng in đúng bảng, tự mở rộng theo số dòng thực; không giữ sheet ẩn, công thức #REF!, tên người, ngày tháng, đơn vị/khối lượng năm 2020 hoặc lý trình 539–540 từ mẫu vào dữ liệu mới. Chừa trống thông tin nhân sự/đơn vị chưa được cung cấp.
- [x] Xuất Excel có xử lý chờ/lỗi, tải thư viện định dạng khi cần; kiểm tra workbook xuất thực tế và bản in, giữ nguyên các chức năng tra cứu/nhân công/Sơn cầu/CHATBOT.

Hoàn tất: 46 kiểm thử đạt (10 kiểm thử mới cho xuất Excel), TypeScript và build thành công; reviewer đối chiếu 121/121 bản ghi giữ đúng dữ liệu/thứ tự. Đã xử lý khối lượng Đường ngang không suy diễn đơn vị mét và bỏ footer thêm ngoài mẫu. File thật Km408–Km409: 14 hạng mục, 8 vật tư, SUM 233,29192797 hiển thị 233,3 công; bản in A4 đủ bảng và chữ ký trên 1 trang. Bản dài tự cho nhiều trang để không ép chữ quá nhỏ.

## Chuyển động nhẹ và giảm chuyển động
- [x] Thêm hiệu ứng xuất hiện nhẹ cho các phần trang khi mở/chuyển tab; giữ ngắn gọn 150–200ms và không làm thay đổi bố cục, dữ liệu hay thao tác.
- [x] Nút bấm có phản hồi hover/nhấn nhẹ, thời gian ngắn; không áp dụng chuyển động cho nút bị vô hiệu hóa.
- [x] Tuân theo `prefers-reduced-motion`: tắt hiệu ứng xuất hiện, hover/nhấn, chuyển tiếp và chuyển động trang trí; cuộn về ô hỏi CHATBOT không dùng cuộn mượt khi bật giảm chuyển động.

Hoàn tất: hiệu ứng phần trang 180ms, độ trễ tối đa 20ms; nút 140ms, dịch chuyển hover 1–2px và phản hồi nhấn nhẹ. Hover chỉ dùng với chuột/con trỏ hỗ trợ hover. CSS giảm chuyển động bao phủ cả hộp thoại portal, pseudo-element và trạng thái tải; giữ các transform định vị tĩnh. 55 kiểm thử đạt (9 mới về chuyển động), TypeScript và build thành công. Preview và manifest HTTP 200; CSS build giữ đủ hai media query. Không thay công thức, dữ liệu hoặc gọi API ghi dữ liệu trong kiểm thử.

## Thu gọn danh sách lý trình bằng thanh cuộn
- [x] Danh sách lý trình ở Tra cứu bóc khối lượng đường có chiều cao giới hạn và thanh cuộn dọc, không kéo dài toàn bộ trang; dùng được trên máy tính và điện thoại.
- [x] Giữ nguyên tên lý trình, loại đối tượng, số hạng mục/vật tư, thứ tự bản ghi, cỡ chữ và thao tác chọn; không thay nội dung, dữ liệu, bộ lọc hay bảng chi tiết.

Hoàn tất: giới hạn chiều cao theo màn hình (240–480px), cuộn dọc độc lập, thanh cuộn mảnh theo màu giao diện; hỗ trợ focus và cuộn bằng bàn phím. Đối chiếu toàn bộ Home.tsx byte-for-byte sau khi bỏ thay đổi duy nhất ở class/thuộc tính accessibility của khung bao: mọi nội dung và handler giữ nguyên. TypeScript, 55 kiểm thử, build đạt; Preview HTTP 200.

## Khung ảnh/video thay ngôi sao giữa màn hình chào CHATBOT
- [x] Chỉ thay ngôi sao lớn phía trên “Xin chào, tôi là CHATBOT” bằng khung hiển thị ảnh hoặc video; dùng AIĐSQB.mp4 đính kèm làm video ban đầu.
- [x] Cho chọn/tải ảnh hoặc video mới trong khung, lưu lựa chọn trên trình duyệt hiện tại; có thể trở về video gốc. Video có bật/tạm dừng, không tự phát âm thanh, không tự phát khi bật giảm chuyển động.
- [x] Không thay lời chào, ngôi sao tiêu đề/sidebar, kho tài liệu, hỏi đáp, nút giọng nói, nguồn trích dẫn hoặc các tab khác.

Hoàn tất: video gốc và poster lưu storage dự án; ảnh/video mới tối đa 50 MB lưu IndexedDB riêng (không đụng kho tài liệu). Khung 176–192px giữ trọn ảnh, có Tải ảnh / video, phát/tạm dừng và Video gốc; không tự phát âm thanh hoặc tự phát khi giảm chuyển động. Giải phóng object URL khi thay/unmount, báo lỗi file không hỗ trợ/lưu trữ bị chặn, có ảnh dự phòng cho video gốc. Đối chiếu Home.tsx byte-for-byte ngoài đúng import và một biểu tượng chào; reviewer độc lập xác nhận phạm vi. 63 kiểm thử và TypeScript đạt; build thành công, Preview HTTP 200.

## Thêm tab Đường cong
- [x] Thêm tab “Đường cong” ngay sau “Bảng công”, trước “Trợ lý AI”; chọn tab mở khu vực Đường cong riêng.
- [x] Giữ nguyên tab và nội dung hiện có. Chưa có yêu cầu nghiệp vụ/dữ liệu đường cong nên chỉ tạo khu vực chờ nội dung, không tự thêm công thức hoặc số liệu.

Hoàn tất: tab dùng biểu tượng đường cong và hệ màu hiện có; khu vực riêng ghi rõ chờ bổ sung dữ liệu. Đối chiếu toàn bộ nội dung/handler cũ giữ nguyên byte-for-byte sau khi bỏ đúng phần thêm tab mới. TypeScript, 63 kiểm thử và build đạt; Preview HTTP 200.

## Tính Đường cong từ workbook người dùng
- [x] Phân tích `_TínhĐườngTên_1.xlsx`: hai sheet đường tên (hòa hoãn và cong tròn) cùng sheet T/P/KT; làm rõ đầu vào R, L1, L2, KT, C, đơn vị m/mm và các lỗi/cố định trong mẫu.
- [x] Tab Đường cong nhập số liệu mới cho đường cong đơn một bán kính, có/không hòa hoãn tuyến tính; tự tính Fc, Z1/Z2, bảng FKH theo bước C/2, các mốc NĐ/TĐ/TC/NC và vị trí tùy chọn. Cho L1/L2 khác nhau hoặc bằng 0; không dùng dữ liệu mẫu làm giới hạn số điểm.
- [x] Có mẫu từ file, nhập workbook tương thích, xuất bảng kết quả Excel; hỗ trợ tính T/P/KT theo bán kính và góc độ/phút/giây.
- [x] Kiểm tra đầu vào, ngăn chia 0/giá trị không hữu hạn, L1+L2>KT và bảng quá lớn; nêu rõ mô hình xấp xỉ theo workbook, không tuyên bố hỗ trợ đường cong ghép/ngược hoặc kiểm định thiết kế.
- [x] Giữ nguyên toàn bộ các tab khác, dữ liệu và chức năng hiện có; tách component và công thức mới, chỉ thay khung chờ của tab Đường cong.

Hoàn tất: phân tích trong giao diện và `docs/curve-workbook-analysis.md`; mô hình tích phân độ cong tuyến tính xử lý mốc lẻ/đoạn ngắn/C khác 20m mà không giữ các lỗi IF/công thức đuôi của file. 75/75 điểm thực trong hai sheet được đối chiếu sai số ≤0,0051 mm (khác biệt helper làm tròn trong Excel); thêm quadrature độc lập, kiểm tra L=0, không đối xứng, nhập/xuất round-trip, SSR UI, lưu nháp và dữ liệu cực trị. Nhập trực tiếp workbook thật và xuất lại 29/46 điểm thành công, đủ mốc và số liệu dạng số. Lưu nháp riêng giữ số liệu khi đổi tab, có memory fallback; ngăn file đang đọc/lựa chọn sheet cũ ghi đè biểu mẫu mới. T/P/KT chỉ xuất kèm khi người dùng chọn. TypeScript, 92 kiểm thử và build cuối cùng đạt; Preview HTTP 200. Đối chiếu Home byte-for-byte ngoài import/nhánh Đường cong và bỏ đúng khung chờ, không thay bất kỳ tab cũ nào.

## Làm tròn FKH (mm)
- [x] FKH trong tab Đường cong hiển thị số nguyên mm (làm tròn gần nhất): bảng điểm, mốc, vị trí tùy chọn và tooltip; Excel xuất hiển thị FKH số nguyên tương ứng.
- [x] Giữ độ chính xác nội bộ và số gốc trong Excel, chỉ đổi hiển thị. Không đổi R/L/KT/C, T/P, lý trình hoặc các tab khác.

Hoàn tất: formatter FKH dùng 0 chữ số thập phân; Excel cột F của Đường tên và D của Mốc đường cong có numFmt=0, số gốc vẫn giữ nguyên. SSR kiểm tra đủ 29 điểm số nguyên (4, 96, 1 ở các vị trí mẫu); Excel kiểm tra riêng định dạng FKH và x vẫn 0.000. TypeScript, 92 kiểm thử, build đạt; Preview HTTP 200. Home và module công thức không có diff.

## Nâng độ chính xác CHATBOT, chỉ trả lời nội dung tải lên
- [x] Tìm đoạn liên quan chính xác hơn trong toàn văn tiếng Việt, giảm trùng lặp và giữ ngữ cảnh/trang của nguồn; không dùng tên file đơn thuần hoặc nguồn bên ngoài làm căn cứ.
- [x] Tạo câu trả lời theo từng ý có trích đoạn nguyên gốc; kiểm tra mã nguồn và đoạn trích bằng mã chương trình, rồi đối chiếu nội dung từng ý với nguồn trước khi hiển thị. Không hiển thị câu trả lời AI chưa qua kiểm tra; thiếu căn cứ hoặc lỗi kiểm chứng phải nói rõ.
- [x] Câu hỏi tiếp nối được hiểu từ câu hỏi trước, nhưng lịch sử và dữ liệu tác nghiệp không được coi là nguồn. Chỉ dùng tài liệu hiện còn trong kho; giữ chức năng tải/xóa file và các tab khác.

Hoàn tất: 121/121 kiểm thử, TypeScript và build đạt. Ba kiểm tra AI thật với dữ liệu giả lập đạt (giữ số liệu/điều kiện, không bịa đơn giá, không làm theo yêu cầu dùng nguồn ngoài); thử PDF thực tế về phạm vi áp dụng tà vẹt sợi tổng hợp có nguồn trang PDF 6. Rà soát độc lập không thấy đường hiển thị câu trả lời AI chưa được kiểm tra; đã sửa hạn chế tóm tắt file dài, mô tả Tổng quan và đoạn khớp từ khóa quá yếu. Tóm tắt từ các đoạn đại diện luôn báo chưa bao quát toàn bộ file dài. Không ghi/xóa dữ liệu thật trong kiểm thử, giữ nguyên công thức và nghiệp vụ các tab khác.

## Tăng tốc phản hồi và ổn định độ chính xác CHATBOT
- [x] Giữ nguyên phạm vi chỉ dùng tài liệu Admin đã tải lên, trích dẫn [DOC-N], bằng chứng khớp nguyên văn và kiểm chứng độc lập; không chuyển sang trả lời tự do khi thiếu căn cứ.
- [x] Cache chỉ mục chuẩn hóa/token/vị trí thuật ngữ của tài liệu trong bộ nhớ để các câu hỏi sau không phải quét lại toàn bộ file; truy hồi cửa sổ quanh điểm khớp và giữ mốc trang PDF, tự làm mới khi cùng một file đổi tên, trạng thái hoặc nội dung, giới hạn kích thước cache để không phình bộ nhớ.
- [x] Với câu hỏi dài, chỉ đưa đoạn có cụm thuật ngữ chủ đề liền mạch vào RAG; câu hỏi hướng dẫn không có trong kho không được kéo các đoạn chỉ trùng từ chung như “công trình”, “tiêu chuẩn” hoặc “môi trường”.
- [x] Mỗi câu hỏi quét toàn bộ file đã tải lên ở trạng thái sẵn sàng; tên file có nhiều thuật ngữ trùng chỉ dùng để ưu tiên xếp hạng, không loại các file khác và không được dùng làm bằng chứng.
- [x] Bỏ request làm mới danh sách tài liệu không cần thiết sau mỗi câu hỏi; chỉ làm mới khi Admin tải lên hoặc ẩn file. Giảm ngân sách hiển thị của lượt tạo xuống 3.600 token/độ suy luận thấp và lượt kiểm chứng xuống 900 token/độ suy luận tối thiểu, vẫn giữ hai lượt AI tuần tự và schema JSON nghiêm ngặt.

Hoàn tất: đã mở rộng truy hồi tối đa 12 đoạn từ nhiều file, giữ tên file là tín hiệu xếp hạng chứ không là bộ lọc; kiểm chứng hai lượt, nguồn `[DOC-N]` và nguyên tắc chỉ trả lời có căn cứ không thay đổi. Không thay model `gpt-5-mini`, kho tài liệu, nguồn trích dẫn hoặc nghiệp vụ các tab khác.

## Gateway LLM của CHATBOT
- [x] Khôi phục adapter server-side về gateway LLM Manus mặc định để router `ai.ask` không phụ thuộc Gemini hoặc endpoint bên ngoài.
- [x] Giữ nguyên truy hồi tài liệu, bằng chứng `[DOC-N]`, kiểm chứng hai lượt, thông báo thiếu căn cứ và các tab tính toán khác.
Hoàn tất: request hỏi đáp thực tế trả HTTP 200 và câu trả lời có trích dẫn từ file đã lưu; typecheck, test chatbot và build đạt.

## Tương thích chia sẻ liên kết trên Zalo
- [x] Bổ sung metadata chia sẻ đầy đủ gồm `og:site_name`, locale, ảnh PNG, Twitter title/description, canonical và robots cho trang chủ.
- [x] Bổ sung JSON-LD `WebApplication` và nội dung HTML tĩnh có tiêu đề/mô tả để crawler nhận diện website ngay cả khi không chạy JavaScript.
- [ ] Domain cần Zalo rà soát/cho phép nếu bộ lọc an toàn vẫn đánh giá nhầm liên kết; thay đổi mã nguồn không tự xóa được chặn danh tiếng của Zalo.

## Đọc file đã lưu trong CHATBOT
- [x] Thêm nút “Đọc” cạnh từng file trong mục “File đã lưu”, chỉ Admin được sử dụng và vẫn giữ nút xóa hiện tại.
- [x] Mở hộp thoại cuộn hiển thị nội dung văn bản đã trích xuất; hỗ trợ nội dung PDF có lớp chữ, TXT/MD/CSV/JSON và Excel đã lập chỉ mục.
- [x] File scan, lỗi đọc hoặc định dạng chưa có nội dung trích xuất phải hiển thị thông báo rõ ràng, không tự tạo nội dung.

## Cho mọi người đọc file đã lưu trong CHATBOT
- [x] Người truy cập không cần quyền Admin vẫn xem được danh sách file đã lưu và mở nội dung văn bản đã trích xuất bằng nút “Đọc”.
- [x] API công khai chỉ trả metadata cần cho danh sách và nội dung đã trích xuất; quyền tải lên, ẩn/xóa file vẫn chỉ dành cho Admin.

## Làm mới hình nền tổng thể
- [x] Thay nền tổng thể bằng gradient xanh lam, tím nhẹ và vàng ấm, kết hợp lưới kỹ thuật hiện có để giao diện sinh động hơn.
- [x] Giữ các thẻ dữ liệu, bảng, biểu mẫu và nội dung nghiệp vụ trên nền trắng/sáng để không giảm độ tương phản và khả năng đọc.

import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";
import { DeleteDocumentButton } from "../client/src/components/DeleteDocumentButton";

describe("stored file delete button", () => {
  it("labels deletion with the exact filename and waits for explicit confirmation", () => {
    const onDelete = vi.fn();
    const html = renderToStaticMarkup(createElement(DeleteDocumentButton, { name: "Tà vẹt.pdf", disabled: false, deleting: false, onDelete }));
    expect(html).toContain("Xóa file Tà vẹt.pdf khỏi kho CHATBOT");
    expect(html).toContain("Xóa</button>");
    expect(onDelete).not.toHaveBeenCalled();
  });
  it("disables repeated clicks while deletion is in progress", () => {
    const html = renderToStaticMarkup(createElement(DeleteDocumentButton, { name: "Cầu.pdf", disabled: true, deleting: true, onDelete: vi.fn() }));
    expect(html).toContain('disabled=""');
    expect(html).toContain("Đang xóa…");
  });
});

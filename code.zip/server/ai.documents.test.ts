import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

vi.mock("./db", () => ({ listAiDocuments: vi.fn() }));
vi.mock("./documentIndex", () => ({ ensureSearchableDocuments: vi.fn(async documents => documents), MAX_DOCUMENT_BYTES: 15 * 1024 * 1024, extractUploadedText: vi.fn() }));
vi.mock("./_core/llm", () => ({ invokeLLM: vi.fn() }));

import * as db from "./db";
import { ensureSearchableDocuments } from "./documentIndex";
import { invokeLLM } from "./_core/llm";
import { appRouter } from "./routers";

const caller = () => appRouter.createCaller({ user: null, req: { headers: {} }, res: {} } as TrpcContext);
const readyDoc = { id: 10, name: "Quy trình sơn.pdf", processingStatus: "ready", extractedText: "Năng suất sơn chống rỉ là 2 m² mỗi ngày." };

beforeEach(() => {
  vi.clearAllMocks();
  vi.mocked(ensureSearchableDocuments).mockImplementation(async documents => documents);
  vi.mocked(db.listAiDocuments).mockResolvedValue([readyDoc] as never);
  vi.mocked(invokeLLM).mockImplementation(async request => {
    const verification = request.response_format?.type === "json_schema" && request.response_format.json_schema.name === "document_support_checks";
    const content = verification
      ? { checks: [{ index: 0, supported: true }] }
      : { blocks: [{ title: "Năng suất", text: "Năng suất là 2 m² mỗi ngày.", evidence: [{ source: 1, quote: "Năng suất sơn chống rỉ là 2 m² mỗi ngày." }] }] };
    return { model: "test", choices: [{ message: { content: JSON.stringify(content) }, finish_reason: "stop" }] } as never;
  });
});

describe("CHATBOT automatic uploaded-file search", () => {
  it("automatically reloads the document store and searches for every question", async () => {
    const answer = await caller().ai.ask({ question: "nang suat son chong ri", context: "DỮ LIỆU NGOÀI FILE PHẢI BỎ QUA" });
    expect(db.listAiDocuments).toHaveBeenCalledTimes(1);
    expect(ensureSearchableDocuments).toHaveBeenCalledTimes(1);
    expect(answer.sources[0].label).toBe("[DOC-1] Quy trình sơn.pdf");
    expect(answer.sources[0].excerpt).toContain("2 m²");
    const request = vi.mocked(invokeLLM).mock.calls[0][0];
    expect(JSON.stringify(request.messages)).toContain("2 m²");
    expect(JSON.stringify(request.messages)).not.toContain("DỮ LIỆU NGOÀI FILE PHẢI BỎ QUA");
    await caller().ai.ask({ question: "Năng suất sơn chống rỉ" });
    expect(db.listAiDocuments).toHaveBeenCalledTimes(2);
  });
  it("does not call the model when no matching passage exists", async () => {
    const result = await caller().ai.ask({ question: "Dự báo thời tiết" });
    expect(result.answer).toContain("Chưa tìm thấy căn cứ");
    expect(result.sources).toEqual([]);
    expect(invokeLLM).not.toHaveBeenCalled();
  });
  it("explains when no files have been uploaded", async () => {
    vi.mocked(db.listAiDocuments).mockResolvedValue([]);
    expect((await caller().ai.ask({ question: "Tà vẹt" })).answer).toContain("chưa có file");
    expect(invokeLLM).not.toHaveBeenCalled();
  });
  it("does not confuse an unindexed scan with absent information", async () => {
    vi.mocked(db.listAiDocuments).mockResolvedValue([{ ...readyDoc, extractedText: null, processingStatus: "unsupported" }] as never);
    expect((await caller().ai.ask({ question: "Năng suất sơn" })).answer).toContain("OCR");
    expect(invokeLLM).not.toHaveBeenCalled();
  });
  it("surfaces storage/database failures instead of pretending no source exists", async () => {
    vi.mocked(db.listAiDocuments).mockRejectedValueOnce(new Error("unavailable"));
    await expect(caller().ai.ask({ question: "Năng suất sơn" })).rejects.toThrow("Chưa thể truy cập kho tài liệu");
    expect(invokeLLM).not.toHaveBeenCalled();
  });
});

describe("detailed answer configuration", () => {
  it("requests separate grounded answers with bounded generation and verification budgets", async () => {
    await caller().ai.ask({ question: "Năng suất sơn chống rỉ?" });
    const request = vi.mocked(invokeLLM).mock.calls[0][0];
    expect(request.maxCompletionTokens).toBe(3600);
    expect(request.reasoning).toEqual({ effort: "low" });
    expect(request.toolChoice).toBe("none");
    expect(vi.mocked(invokeLLM)).toHaveBeenCalledTimes(2);
    const system = String(request.messages.find(message => message.role === "system")?.content);
    expect(system).toContain("từng ý theo đúng thứ tự");
    expect(system).toContain("không tự phục dựng");
    expect(system).toContain("[DOC-N]");
    expect(vi.mocked(invokeLLM).mock.calls[1][0].maxCompletionTokens).toBe(900);
    expect(vi.mocked(invokeLLM).mock.calls[1][0].reasoning).toEqual({ effort: "minimal" });
  });
  it("includes extracted PDF page location in both model context and returned citations", async () => {
    vi.mocked(db.listAiDocuments).mockResolvedValue([{ ...readyDoc, extractedText: "[Trang 8]\nNăng suất sơn chống rỉ là 2 m² mỗi ngày." }] as never);
    const result = await caller().ai.ask({ question: "Năng suất sơn chống rỉ" });
    expect(result.sources[0].label).toContain("trang PDF 8");
    expect(JSON.stringify(vi.mocked(invokeLLM).mock.calls[0][0].messages)).toContain("trang PDF 8");
  });
  it("fails closed when verification fails instead of showing the draft", async () => {
    vi.mocked(invokeLLM).mockRejectedValueOnce(new Error("unavailable"));
    await expect(caller().ai.ask({ question: "Năng suất sơn" })).rejects.toThrow("chưa thể kiểm chứng");
  });
  it("does not treat previous questions as evidence if the document has been removed", async () => {
    vi.mocked(db.listAiDocuments).mockResolvedValue([]);
    const answer = await caller().ai.ask({ question: "Còn điều kiện?", previousQuestions: ["Năng suất sơn là 999?"] });
    expect(answer.sources).toEqual([]);
    expect(answer.answer).not.toContain("999");
    expect(invokeLLM).not.toHaveBeenCalled();
  });
});

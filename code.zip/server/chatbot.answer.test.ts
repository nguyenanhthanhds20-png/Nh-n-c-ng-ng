import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { ChatbotAnswer } from "../client/src/components/ChatbotAnswer";
import { DOCUMENT_ANSWER_POLICY } from "./documentAnswer";

describe("specific document answers", () => {
  it("instructs the model to answer every point with exact values and no invented missing content", () => {
    for (const requirement of ["từng ý theo đúng thứ tự", "số liệu", "đơn vị", "không tự phục dựng", "nguyên văn", "[DOC-N]", "mục lục", "Chưa tìm thấy nội dung này"]) {
      expect(DOCUMENT_ANSWER_POLICY).toContain(requirement);
    }
  });
  it("renders readable headings, lists, units and tables instead of raw Markdown", () => {
    const html = renderToStaticMarkup(createElement(ChatbotAnswer, { content: "## 1. Kích thước\n\n**Giữ đúng số liệu** [DOC-1]\n\n1. Đo mẫu\n2. Kiểm tra\n\n| Chỉ tiêu | Giá trị |\n|---|---|\n| Chiều dài | 1,8 m |" }));
    expect(html).toContain("<h2");
    expect(html).toContain("<ol");
    expect(html).toContain("<table");
    expect(html).toContain("1,8 m");
    expect(html).toContain("[DOC-1]");
  });
  it("does not load remote images or execute raw HTML from model text", () => {
    const html = renderToStaticMarkup(createElement(ChatbotAnswer, { content: "![tracking](https://example.com/track.png)\n\n<script>alert(1)</script>\n\nNội dung an toàn [DOC-1]" }));
    expect(html).not.toContain("<img");
    expect(html).not.toContain("<script");
    expect(html).toContain("Nội dung an toàn");
  });
});

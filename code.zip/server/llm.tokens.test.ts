import { afterEach, describe, expect, it, vi } from "vitest";
import { invokeLLM } from "./_core/llm";

afterEach(() => { vi.unstubAllEnvs(); vi.unstubAllGlobals(); });

describe("LLM completion budget", () => {
  it("sends max_completion_tokens without also sending max_tokens", async () => {
    vi.stubEnv("MANUS_API_URL", "https://api.example");
    vi.stubEnv("MANUS_API_KEY", "unit-test-only");
    const request = vi.fn().mockResolvedValue(new Response(JSON.stringify({ choices: [{ message: { content: "ok" } }] })));
    vi.stubGlobal("fetch", request);
    await invokeLLM({ model: "gpt-5-mini", messages: [{ role: "user", content: "test" }], maxCompletionTokens: 3600, maxTokens: 100, reasoning: { effort: "low" } });
    const body = JSON.parse(request.mock.calls[0][1].body);
    expect(body.max_completion_tokens).toBe(3600);
    expect(body).not.toHaveProperty("max_tokens");
    expect(body.reasoning).toEqual({ effort: "low" });
  });
  it("preserves existing maxTokens behavior for callers not using the new parameter", async () => {
    vi.stubEnv("MANUS_API_URL", "https://api.example");
    vi.stubEnv("MANUS_API_KEY", "unit-test-only");
    const request = vi.fn().mockResolvedValue(new Response(JSON.stringify({ choices: [{ message: { content: "ok" } }] })));
    vi.stubGlobal("fetch", request);
    await invokeLLM({ messages: [{ role: "user", content: "test" }], maxTokens: 500 });
    const body = JSON.parse(request.mock.calls[0][1].body);
    expect(body.max_tokens).toBe(500);
    expect(body).not.toHaveProperty("max_completion_tokens");
  });
});

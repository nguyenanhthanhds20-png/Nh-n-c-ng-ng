import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { CurveCalculator } from "../client/src/components/CurveCalculator";

const html = renderToStaticMarkup(createElement(CurveCalculator));

describe("Curve tab initial render", () => {
  it("identifies the workbook sample and renders all required inputs", () => {
    expect(html).toContain("Đang hiển thị mẫu từ file đã gửi");
    for (const name of [
      "curve-radius",
      "curve-length",
      "curve-chord",
      "curve-transition-in",
      "curve-transition-out",
      "curve-start-chainage",
      "curve-sample-offset",
    ]) {
      expect(html).toContain(`id="${name}"`);
    }
    expect(html).toContain('id="curve-name"');
    expect(html).toContain('inputMode="text"');
  });
  it("renders all 29 original sample points and exact boundaries in a scrollable table", () => {
    expect(html).toContain("29 dòng bảng");
    const displayedFkh = Array.from(
      html.matchAll(/<td class="px-3 py-2 text-right font-bold">(.*?)<\/td>/g),
      match => match[1]
    );
    expect(displayedFkh).toHaveLength(29);
    expect(displayedFkh[0]).toBe("4");
    expect(displayedFkh[4]).toBe("96");
    expect(displayedFkh[28]).toBe("1");
    expect(displayedFkh.every(value => /^\d+$/.test(value))).toBe(true);
    expect(html).toContain("FKH làm tròn đến mm (số nguyên)");
    expect(html).toContain("Giữa điểm 23 và 24");
    expect(html).toContain("max-h-[520px] overflow-auto");
  });
  it("keeps import/export and independent circular geometry available", () => {
    expect(html).toContain('accept=".xlsx,.xls"');
    expect(html).toContain("Nạp Excel");
    expect(html).toContain("Xuất Excel");
    expect(html).toContain("Dùng R/KT cho bảng đường tên");
    expect(html).toContain("Vị trí x");
  });
  it("states the approximation and excludes unsupported compound/reverse curves", () => {
    expect(html).toContain("PHÂN TÍCH FILE");
    expect(html).toContain("không phải sagitta tròn chính xác");
    expect(html).toContain("không bao gồm đường cong tổ hợp hoặc ngược");
    expect(html).not.toContain("Infinity");
    expect(html).not.toContain("NaN");
  });
});

import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

vi.mock("./db", () => ({ softDeleteAiDocument: vi.fn() }));
import { softDeleteAiDocument } from "./db";
import { appRouter } from "./routers";

function caller(role: "admin" | "user" | null) {
  return appRouter.createCaller({
    user: role ? { id: 7, role, approvalStatus: "approved" } : null,
    req: { headers: {} }, res: {},
  } as TrpcContext);
}

beforeEach(() => {
  vi.clearAllMocks();
  vi.mocked(softDeleteAiDocument).mockResolvedValue({ ok: true });
});

describe("delete uploaded document authorization", () => {
  it("allows Admin to hide only the selected file", async () => {
    await expect(caller("admin").documents.remove({ id: 42 })).resolves.toEqual({ ok: true });
    expect(softDeleteAiDocument).toHaveBeenCalledOnce();
    expect(softDeleteAiDocument).toHaveBeenCalledWith(42);
  });
  it("blocks unauthenticated visitors without touching storage or database", async () => {
    await expect(caller(null).documents.remove({ id: 42 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(softDeleteAiDocument).not.toHaveBeenCalled();
  });
  it("blocks regular users even if their account is approved", async () => {
    await expect(caller("user").documents.remove({ id: 42 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(softDeleteAiDocument).not.toHaveBeenCalled();
  });
  it("does not report success when deletion fails", async () => {
    vi.mocked(softDeleteAiDocument).mockRejectedValueOnce(new Error("Không thể truy cập kho"));
    await expect(caller("admin").documents.remove({ id: 42 })).rejects.toThrow("Không thể truy cập kho");
  });
  it("rejects invalid document ids", async () => {
    await expect(caller("admin").documents.remove({ id: 0 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(softDeleteAiDocument).not.toHaveBeenCalled();
  });
});

import { extractText } from "unpdf";
import * as db from "./db";
import { storageGetSignedUrl } from "./storage";

export const MAX_DOCUMENT_BYTES = 15 * 1024 * 1024;
export const MAX_DOCUMENT_TEXT = 2_000_000;

export function isPdf(name: string, mimeType: string) {
  return /\.pdf$/i.test(name) || mimeType === "application/pdf";
}

export async function extractPdfText(bytes: Uint8Array): Promise<string> {
  const { text } = await extractText(new Uint8Array(bytes), { mergePages: false });
  return text.map((page, index) => page.trim() ? `[Trang ${index + 1}]\n${page}` : "")
    .filter(Boolean).join("\n\n").slice(0, MAX_DOCUMENT_TEXT).trim();
}

export async function extractUploadedText(name: string, mimeType: string, bytes: Buffer, fallback?: string) {
  if (isPdf(name, mimeType)) return extractPdfText(bytes);
  if (mimeType.startsWith("text/") || /\.(txt|md|csv|json|xml|log)$/i.test(name)) {
    return bytes.toString("utf8").slice(0, MAX_DOCUMENT_TEXT).trim();
  }
  return fallback?.trim().slice(0, MAX_DOCUMENT_TEXT) || "";
}

type StoredDocument = Awaited<ReturnType<typeof db.listAiDocuments>>[number];
const indexing = new Map<number, Promise<StoredDocument>>();

async function readStoredPdf(document: StoredDocument): Promise<StoredDocument> {
  let extractedText: string;
  try {
    const url = await storageGetSignedUrl(document.storageKey);
    const response = await fetch(url, { signal: AbortSignal.timeout(30_000) });
    if (!response.ok || !response.body) throw new Error("Không tải được file từ kho");
    const reader = response.body.getReader();
    const chunks: Uint8Array[] = [];
    let total = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        total += value.byteLength;
        if (total > MAX_DOCUMENT_BYTES) throw new Error("File vượt giới hạn 15 MB");
        chunks.push(value);
      }
    } finally { await reader.cancel(); }
    extractedText = await extractPdfText(Buffer.concat(chunks));
  } catch {
    // Keep the original file intact and make indexing failure visible instead of inventing an answer.
    const patch = { processingStatus: "failed" as const };
    await db.updateAiDocument(document.id, patch);
    return { ...document, ...patch };
  }
  const patch = { extractedText: extractedText || null, processingStatus: extractedText ? "ready" as const : "unsupported" as const };
  await db.updateAiDocument(document.id, patch);
  return { ...document, ...patch };
}

export async function ensureSearchableDocuments(documents: StoredDocument[]) {
  const results: StoredDocument[] = [];
  // Sequential extraction bounds memory use. Concurrent questions share an in-flight extraction.
  for (const document of documents) {
    if (document.extractedText?.trim() || !isPdf(document.name, document.mimeType)
      || !["unsupported", "processing"].includes(document.processingStatus)) {
      results.push(document);
      continue;
    }
    let pending = indexing.get(document.id);
    if (!pending) {
      pending = readStoredPdf(document);
      indexing.set(document.id, pending);
    }
    try { results.push(await pending); }
    finally { indexing.delete(document.id); }
  }
  return results;
}

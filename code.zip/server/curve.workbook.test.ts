import * as XLSX from "xlsx";
import { describe, expect, it } from "vitest";
import fixtures from "./fixtures/curve-workbook.json";
import {
  calculateCircularElements,
  calculateCurve,
  type CurveInput,
} from "../client/src/lib/curveCalculations";
import {
  createCurveWorkbook,
  extractCurveInputs,
} from "../client/src/lib/curveWorkbook";

function sourceWorkbook() {
  const book = XLSX.utils.book_new();
  for (const source of fixtures) {
    const sheet: XLSX.WorkSheet = {
      "!ref": "A1:F7",
      B3: { t: "s", v: "Bán kính đường cong" },
      B6: { t: "s", v: "Chiều dài khai triển đường cong" },
      E3: { t: "n", v: source.input.radius },
      E4: { t: "n", v: source.input.transitionIn },
      E5: { t: "n", v: source.input.transitionOut },
      E6: { t: "n", v: source.input.length },
      E7: { t: "n", v: source.input.chord },
    };
    XLSX.utils.book_append_sheet(book, sheet, source.sheet);
  }
  XLSX.utils.book_append_sheet(
    book,
    XLSX.utils.aoa_to_sheet([["TÍNH T, P, KT CỦA ĐƯỜNG CONG TRÒN"]]),
    "Sheet1"
  );
  return book;
}

describe("Curve Excel import/export", () => {
  it("imports both original parameter sheets and ignores Sheet1 geometry", () => {
    const inputs = extractCurveInputs(sourceWorkbook());
    expect(inputs).toHaveLength(2);
    inputs.forEach((entry, index) =>
      expect(entry.input).toEqual(fixtures[index].input)
    );
  });

  it("rejects cached errors/missing data rather than making blank parameters zero", () => {
    const book = sourceWorkbook();
    delete book.Sheets[book.SheetNames[0]].E3;
    expect(() => extractCurveInputs(book)).toThrow("chưa hợp lệ");
  });

  it("rejects unrelated workbooks without altering the current data", () => {
    const book = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      book,
      XLSX.utils.aoa_to_sheet([["Other data", 123]]),
      "Other"
    );
    expect(() => extractCurveInputs(book)).toThrow("Không tìm thấy");
  });

  it("exports complete numeric results, boundary rows, units and inputs for round-trip", async () => {
    const input: CurveInput = { ...fixtures[0].input, startChainage: 842000 };
    const result = calculateCurve(input);
    const circular = calculateCircularElements(100, 16, 46, 23);
    const book = await createCurveWorkbook(result, "Đường cong 842", circular);
    const table = book.getWorksheet("Đường tên")!;
    expect(table.rowCount).toBe(result.rows.length + 2);
    result.rows.forEach((row, index) => {
      expect(table.getCell(index + 3, 2).value).toBe(row.distance);
      expect(table.getCell(index + 3, 6).value).toBe(row.f);
      expect(table.getCell(index + 3, 6).numFmt).toBe("0");
      expect(table.getCell(index + 3, 2).numFmt).toBe("0.000");
    });
    expect(table.getCell("F2").value).toBe("FKH (mm)");
    expect(table.views[0]).toMatchObject({ state: "frozen", ySplit: 2 });
    const boundaries = book.getWorksheet("Mốc đường cong")!;
    expect(boundaries.rowCount).toBe(result.boundaries.length + 2);
    result.boundaries.forEach((boundary, index) => {
      expect(boundaries.getCell(index + 3, 4).value).toBe(boundary.f);
      expect(boundaries.getCell(index + 3, 4).numFmt).toBe("0");
    });
    expect(book.getWorksheet("T P KT tính riêng")!.getCell("B3").value).toBe(
      100
    );
    const buffer = await book.xlsx.writeBuffer();
    const restored = extractCurveInputs(XLSX.read(buffer, { type: "buffer" }));
    expect(restored).toHaveLength(1);
    expect(restored[0].input).toEqual(input);
  });

  it("recalculates from inputs, not from a stale/altered result array", async () => {
    const result = calculateCurve(fixtures[1].input);
    result.rows[0].f = -999;
    const book = await createCurveWorkbook(result, "Cong tròn");
    expect(book.getWorksheet("Đường tên")!.getCell("F3").value).toBeCloseTo(
      12.5,
      8
    );
  });
});

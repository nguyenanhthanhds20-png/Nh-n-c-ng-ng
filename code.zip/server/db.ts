import { and, count, desc, eq, isNotNull, isNull } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { aiDocuments, InsertUser, sessions, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const isOwner = user.openId === ENV.ownerOpenId;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = [
    "username",
    "passwordHash",
    "name",
    "email",
    "loginMethod",
  ] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  values.lastSignedIn = user.lastSignedIn ?? new Date();
  updateSet.lastSignedIn = values.lastSignedIn;
  if (user.role !== undefined || isOwner) {
    values.role = user.role ?? "admin";
    updateSet.role = values.role;
  }
  if (user.approvalStatus !== undefined || isOwner) {
    values.approvalStatus = user.approvalStatus ?? "approved";
    updateSet.approvalStatus = values.approvalStatus;
  }
  if (user.approvedAt !== undefined || isOwner) {
    values.approvedAt = user.approvedAt ?? new Date();
    updateSet.approvedAt = values.approvedAt;
  }
  await db
    .insert(users)
    .values(values)
    .onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);
  return result[0];
}
export async function getUserByUsername(username: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db
    .select()
    .from(users)
    .where(eq(users.username, username))
    .limit(1);
  return result[0];
}
export async function createLocalUser(input: {
  username: string;
  passwordHash: string;
  name: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const adminCount = await db
    .select({ value: count() })
    .from(users)
    .where(and(eq(users.role, "admin"), isNotNull(users.username)));
  const isBootstrap = Number(adminCount[0]?.value ?? 0) === 0;
  const [created] = await db
    .insert(users)
    .values({
      openId: `local:${input.username}`,
      username: input.username,
      passwordHash: input.passwordHash,
      name: isBootstrap ? "Nguyễn Anh Thành" : input.name,
      loginMethod: "password",
      role: isBootstrap ? "admin" : "user",
      approvalStatus: isBootstrap ? "approved" : "pending",
      approvedAt: isBootstrap ? new Date() : null,
    })
    .$returningId();
  return getUserById(created.id);
}
export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result[0];
}
export async function createSession(
  userId: number,
  tokenHash: string,
  expiresAt: Date
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(sessions).values({ userId, tokenHash, expiresAt });
}
export async function getUserBySessionHash(tokenHash: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select({ user: users })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(eq(sessions.tokenHash, tokenHash))
    .limit(1);
  if (!result[0]) return undefined;
  const session = await db
    .select()
    .from(sessions)
    .where(eq(sessions.tokenHash, tokenHash))
    .limit(1);
  if (!session[0] || session[0].expiresAt <= new Date()) return undefined;
  return result[0].user;
}
export async function deleteSession(tokenHash: string) {
  const db = await getDb();
  if (!db) return;
  await db.delete(sessions).where(eq(sessions.tokenHash, tokenHash));
}
export async function listUsers() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(users).orderBy(desc(users.createdAt));
}
export async function updateApprovalStatus(
  openId: string,
  approvalStatus: "pending" | "approved" | "rejected"
) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db
    .update(users)
    .set({
      approvalStatus,
      approvedAt: approvalStatus === "approved" ? new Date() : null,
    })
    .where(eq(users.openId, openId));
  return getUserByOpenId(openId);
}

export async function listAiDocuments() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(aiDocuments).where(isNull(aiDocuments.deletedAt)).orderBy(desc(aiDocuments.createdAt));
}
export async function getAiDocument(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const rows = await db.select().from(aiDocuments).where(and(eq(aiDocuments.id, id), isNull(aiDocuments.deletedAt))).limit(1);
  return rows[0];
}
export async function createAiDocument(input: typeof aiDocuments.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const [created] = await db.insert(aiDocuments).values(input).$returningId();
  const rows = await db.select().from(aiDocuments).where(eq(aiDocuments.id, created.id)).limit(1);
  return rows[0];
}

export async function updateAiDocument(id: number, patch: Partial<typeof aiDocuments.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(aiDocuments).set(patch).where(eq(aiDocuments.id, id));
  const rows = await db.select().from(aiDocuments).where(eq(aiDocuments.id, id)).limit(1);
  return rows[0];
}

export async function softDeleteAiDocument(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(aiDocuments).set({ deletedAt: new Date() }).where(eq(aiDocuments.id, id));
  return { ok: true } as const;
}

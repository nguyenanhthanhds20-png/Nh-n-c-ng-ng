import { COOKIE_NAME } from "@shared/const";
import { parse as parseCookieHeader } from "cookie";
import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import * as db from "../db";
import { hashSessionToken } from "../localAuth";
import { sdk } from "./sdk";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
  localSessionToken?: string;
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;
  let localSessionToken: string | undefined;
  try {
    const cookies = parseCookieHeader(opts.req.headers.cookie ?? "");
    const candidate = cookies[COOKIE_NAME];
    if (candidate) {
      const localUser = await db.getUserBySessionHash(
        hashSessionToken(candidate)
      );
      if (localUser) {
        user = localUser;
        localSessionToken = candidate;
      }
    }
    if (!user) user = await sdk.authenticateRequest(opts.req);
  } catch {
    user = null;
  }
  return { req: opts.req, res: opts.res, user, localSessionToken };
}

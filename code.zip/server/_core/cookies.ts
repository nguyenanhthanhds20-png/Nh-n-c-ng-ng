import type { CookieOptions, Request } from "express";

export function getSessionCookieOptions(req: Request): CookieOptions {
  const host = String(req.headers.host ?? "");
  const localHttp =
    host.startsWith("localhost") || host.startsWith("127.0.0.1");
  return {
    httpOnly: true,
    path: "/",
    sameSite: localHttp ? "lax" : "none",
    secure: !localHttp,
  };
}

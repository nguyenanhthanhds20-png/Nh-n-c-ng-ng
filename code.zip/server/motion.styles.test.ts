import { readFileSync } from "node:fs";
import postcss, { type AtRule, type Rule } from "postcss";
import { describe, expect, it } from "vitest";

const css = postcss.parse(
  readFileSync(new URL("../client/src/index.css", import.meta.url), "utf8")
);

function mediaRule(preference: string) {
  return css.nodes.find(
    node => node.type === "atrule" && node.name === "media" &&
      node.params === `(prefers-reduced-motion: ${preference})`
  ) as AtRule;
}

function ruleDeclarations(rule: Rule) {
  return Object.fromEntries(
    rule.nodes.filter(node => node.type === "decl").map(node => [node.prop, node.value])
  );
}

describe("subtle page motion styles", () => {
  it("opts section animation into normal motion with at most 20ms stagger", () => {
    const normal = mediaRule("no-preference");
    expect(normal).toBeDefined();
    normal.walkDecls("animation", declaration => {
      expect(declaration.value).toContain("180ms");
      expect(declaration.value).toContain("backwards");
      expect(declaration.value).not.toContain("infinite");
    });
    const delays: string[] = [];
    normal.walkDecls("animation-delay", declaration => { delays.push(declaration.value); });
    expect(delays).toEqual(["10ms", "20ms"]);
  });

  it("limits button transitions to 140ms and excludes disabled presses", () => {
    const normal = mediaRule("no-preference");
    const rules: Rule[] = [];
    normal.walkRules(rule => { rules.push(rule); });
    const buttons = rules.find(rule => rule.selector === ".rail-page button")!;
    expect(ruleDeclarations(buttons)["transition-duration"]).toBe("140ms");
    const presses = rules.find(rule => rule.selector.endsWith(":active"))!;
    expect(presses.selector).toContain(":not(:disabled)");
    expect(presses.selector).toContain(':not([aria-disabled="true"])');
  });

  it("disables animations, transitions and smooth scrolling including portals and pseudo-elements", () => {
    const reduce = mediaRule("reduce");
    const rule = reduce.nodes!.find(node => node.type === "rule") as Rule;
    expect(rule.selectors).toEqual(["*", "*::before", "*::after"]);
    expect(ruleDeclarations(rule)).toEqual({
      animation: "none",
      transition: "none",
      "scroll-behavior": "auto",
    });
    rule.walkDecls(declaration => { expect(declaration.important).toBe(true); });
    reduce.walkDecls("transform", () => {
      throw new Error("Reduced motion must not break static dialog positioning");
    });
  });

  it("only applies hover movement on fine pointers that support hover", () => {
    const normal = mediaRule("no-preference");
    const hover = normal.nodes!.find(node => node.type === "atrule" && node.name === "media") as AtRule;
    expect(hover.params).toBe("(hover: hover) and (pointer: fine)");
    hover.walkRules(rule => {
      expect(rule.selector).toContain(":not(:disabled)");
      expect(rule.selector).toContain(":hover:not(:active)");
    });
  });
});

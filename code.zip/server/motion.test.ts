import { afterEach, describe, expect, it, vi } from "vitest";
import { getScrollBehavior } from "../client/src/lib/motion";

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("getScrollBehavior", () => {
  it("returns auto when window is unavailable during SSR", () => {
    vi.stubGlobal("window", undefined);

    expect(getScrollBehavior()).toBe("auto");
  });

  it("returns auto when matchMedia is unavailable", () => {
    vi.stubGlobal("window", {});

    expect(getScrollBehavior()).toBe("auto");
  });

  it("returns smooth for an explicit no-preference result", () => {
    const matchMedia = vi.fn().mockReturnValue({ matches: true });
    vi.stubGlobal("window", { matchMedia });

    expect(getScrollBehavior()).toBe("smooth");
    expect(matchMedia).toHaveBeenCalledWith(
      "(prefers-reduced-motion: no-preference)",
    );
  });

  it("returns auto when reduced motion is preferred", () => {
    const matchMedia = vi.fn().mockReturnValue({ matches: false });
    vi.stubGlobal("window", { matchMedia });

    expect(getScrollBehavior()).toBe("auto");
    expect(matchMedia).toHaveBeenCalledWith(
      "(prefers-reduced-motion: no-preference)",
    );
  });

  it("reads the current preference on every call", () => {
    const matchMedia = vi
      .fn()
      .mockReturnValueOnce({ matches: true })
      .mockReturnValueOnce({ matches: false });
    vi.stubGlobal("window", { matchMedia });

    expect(getScrollBehavior()).toBe("smooth");
    expect(getScrollBehavior()).toBe("auto");
    expect(matchMedia).toHaveBeenCalledTimes(2);
  });
});

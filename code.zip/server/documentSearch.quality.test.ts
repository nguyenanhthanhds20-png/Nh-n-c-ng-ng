import { describe, expect, it } from "vitest";
import { retrieveDocuments } from "./documentSearch";

const doc = (text: string, name: string, id: number) => ({
  id,
  name,
  extractedText: text,
  processingStatus: "ready",
});

describe("document search quality", () => {
  it("ranks a passage covering the subject above a distractor sharing generic words", () => {
    const result = retrieveDocuments("quy trình sơn chống rỉ", [
      doc("Quy trình chung được mô tả theo từng bước hành chính.", "chung.txt", 1),
      doc("Quy trình sơn chống rỉ gồm làm sạch bề mặt, sơn lót và nghiệm thu.", "son.txt", 2),
    ]);

    expect(result[0].document.id).toBe(2);
    expect(result.some(item => item.document.id === 1)).toBe(false);
  });

  it("prefers a rare technical phrase over a common partial match", () => {
    const result = retrieveDocuments("hệ số ma sát dọc ray composite", [
      doc("Hệ số kỹ thuật được ghi trong bảng thông số chung.", "chung.txt", 1),
      doc("Hệ số ma sát dọc ray composite được xác định sau thí nghiệm.", "ray-composite.txt", 2),
    ]);

    expect(result[0].document.id).toBe(2);
    expect(result[0].excerpt).toContain("ma sát dọc ray composite");
  });

  it("keeps adjacent table/step context when a match is near a window boundary", () => {
    const text = "Phần mở đầu không liên quan. ".repeat(43)
      + "\nBước 1: kiểm tra bề mặt trước khi thi công."
      + "\nĐiều kiện: bề mặt phải khô và sạch."
      + "\nBước 2: sơn lớp lót theo định mức.";
    const result = retrieveDocuments("bước 1 điều kiện", [doc(text, "quy-trinh.txt", 3)]);

    expect(result[0].excerpt).toContain("Bước 1");
    expect(result[0].excerpt).toContain("Điều kiện");
  });

  it("balances evidence across multiple files for separate questions", () => {
    const result = retrieveDocuments("Quy trình sơn?\nĐộ bền tà vẹt?", [
      doc("Quy trình sơn chống rỉ gồm ba bước.", "son.txt", 10),
      doc("Độ bền tà vẹt được xác định theo kết quả thử mẫu.", "tavet.txt", 11),
    ]);

    expect(result.some(item => item.document.id === 10)).toBe(true);
    expect(result.some(item => item.document.id === 11)).toBe(true);
  });

  it("can return the complete short source for an explicit summary request", () => {
    const source = "Giới thiệu: tài liệu quy định phạm vi, quy trình và điều kiện áp dụng.";
    const result = retrieveDocuments("Hãy tóm tắt tài liệu", [doc(source, "gioi-thieu.txt", 12)]);

    expect(result[0].excerpt).toBe(source);
  });

  it("rejects a long instructional question when only generic words match", () => {
    const result = retrieveDocuments("Tính khối lượng nhân công trên môi trường số", [
      doc("Khối lượng tổng của công trình trong môi trường số liệu được ghi trong bảng.", "chung.txt", 20),
    ]);

    expect(result).toEqual([]);
  });
});

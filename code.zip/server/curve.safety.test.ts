import { describe, expect, it } from "vitest";
import {
  calculateCircularElements,
  calculateCurve,
  CURVE_EXAMPLES,
} from "../client/src/lib/curveCalculations";

describe("Curve numeric safety", () => {
  it("rejects lengths too large to represent millimetre-level coordinates", () => {
    expect(() =>
      calculateCurve({ ...CURVE_EXAMPLES[0].input, startChainage: 1e300 })
    ).toThrow("biểu diễn");
  });
  it("rejects underflow of the half-chord", () => {
    expect(() =>
      calculateCurve({
        ...CURVE_EXAMPLES[1].input,
        chord: Number.MIN_VALUE,
        length: Number.MIN_VALUE,
      })
    ).toThrow("biểu diễn");
  });
  it("rejects overflowed circular geometry results", () => {
    expect(() =>
      calculateCircularElements(Number.MAX_VALUE, 179, 59, 59)
    ).toThrow("không hữu hạn");
  });
});

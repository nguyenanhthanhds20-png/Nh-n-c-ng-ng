import { describe, expect, it } from "vitest";
import {
  calculateCircularElements,
  calculateCurve,
  CURVE_ROW_LIMIT,
  formatChainage,
  type CurveInput,
  validateCurveInput,
  versineAt,
} from "../client/src/lib/curveCalculations";
import workbook from "./fixtures/curve-workbook.json";

type CachedWorkbook = Array<{
  sheet: string;
  input: CurveInput;
  rows: Array<{ index: number; x: number; f: number }>;
}>;

const cached = workbook as CachedWorkbook;
const ROW_TOLERANCE_MM = 0.0051;

/** Independent midpoint rectangle rule for F(x) = 500 ∫ (h - |t-x|) κ(t) dt. */
function numericalVersine(input: CurveInput, distance: number, subintervals = 40_000): number {
  const h = input.chord / 2;
  const low = Math.max(0, distance - h);
  const high = Math.min(input.length, distance + h);
  if (high <= low) return 0;

  const width = (high - low) / subintervals;
  let integral = 0;
  for (let i = 0; i < subintervals; i++) {
    // Midpoints intentionally avoid sampling the discontinuous/end-point cases.
    const t = low + (i + 0.5) * width;
    let curvature: number;
    if (input.transitionIn > 0 && t < input.transitionIn) {
      curvature = t / (input.radius * input.transitionIn);
    } else if (input.length - input.transitionOut > input.transitionIn && t < input.length - input.transitionOut) {
      curvature = 1 / input.radius;
    } else if (input.transitionOut > 0) {
      curvature = (input.length - t) / (input.radius * input.transitionOut);
    } else {
      curvature = 1 / input.radius;
    }
    integral += Math.max(0, h - Math.abs(t - distance)) * curvature * width;
  }
  return 500 * integral;
}

function expectWithin(actual: number, expected: number, tolerance: number, message: string) {
  expect(Math.abs(actual - expected), message).toBeLessThanOrEqual(tolerance);
}

function inputWith(overrides: Partial<CurveInput>): CurveInput {
  return {
    radius: 500,
    transitionIn: 40,
    transitionOut: 40,
    length: 276,
    chord: 20,
    startChainage: 0,
    sampleOffset: 0,
    ...overrides,
  };
}

describe("calculateCurve against the cached Excel workbook rows", () => {
  it("matches every cached row within the workbook's rounded-intermediate tolerance", () => {
    expect(cached).toHaveLength(2);
    expect(cached.map(entry => entry.rows.length)).toEqual([29, 46]);

    for (const entry of cached) {
      const result = calculateCurve(entry.input);
      expect(result.rows).toHaveLength(entry.rows.length);
      for (const expected of entry.rows) {
        const actual = result.rows[expected.index];
        expect(actual.index).toBe(expected.index);
        expect(actual.distance).toBe(expected.x);
        expectWithin(actual.f, expected.f, ROW_TOLERANCE_MM, `${entry.sheet} row ${expected.index}`);
      }
    }
  });

  it("keeps the fixture sheet identities and the expected row counts explicit", () => {
    expect(cached[0].sheet).toContain("HOÃN HÒA");
    expect(cached[1].sheet).toContain("CONG TRÒN");
    expect(calculateCurve(cached[0].input).rows).toHaveLength(29);
    expect(calculateCurve(cached[1].input).rows).toHaveLength(46);
  });
});

describe("versine geometry and independent integration", () => {
  it("handles a boundary exactly halfway between sampled points", () => {
    const input = inputWith({ radius: 600, transitionIn: 15, transitionOut: 25, length: 140, chord: 20 });
    const result = calculateCurve(input);
    const transitionInBoundary = result.boundaries.find(boundary => boundary.label === "TĐ");

    expect(transitionInBoundary).toBeDefined();
    expect(transitionInBoundary?.placement).toBe("Giữa điểm 1 và 2");
    expectWithin(transitionInBoundary!.f, numericalVersine(input, 15), 0.0001, "midpoint boundary");
  });

  it("uses the analytic constant Fc for arbitrary chord lengths, not only C=20", () => {
    const input = inputWith({ radius: 850, transitionIn: 0, transitionOut: 0, length: 220, chord: 17 });
    const result = calculateCurve(input);
    const expectedFc = 1000 * input.chord ** 2 / (8 * input.radius);

    expect(result.fc).toBeCloseTo(expectedFc, 12);
    for (const row of result.rows.filter(row => row.distance >= input.chord / 2 && row.distance <= input.length - input.chord / 2)) {
      expect(row.f).toBeCloseTo(expectedFc, 11);
    }
  });

  it("agrees with independent 40,000-subinterval midpoint quadrature for varied curves", () => {
    const cases: Array<{ input: CurveInput; distances: number[] }> = [
      { input: inputWith({ radius: 713, transitionIn: 12, transitionOut: 31, length: 157, chord: 17 }), distances: [0, 12, 34.5, 126, 157] },
      { input: inputWith({ radius: 275, transitionIn: 0, transitionOut: 19, length: 103, chord: 13 }), distances: [0, 6.5, 84, 103] },
      { input: inputWith({ radius: 925, transitionIn: 11, transitionOut: 0, length: 89, chord: 23 }), distances: [0, 11, 42.5, 89] },
      { input: inputWith({ radius: 480, transitionIn: 23, transitionOut: 37, length: 60, chord: 20 }), distances: [0, 17, 23, 41, 60] },
    ];

    for (const { input, distances } of cases) {
      for (const distance of distances) {
        expectWithin(versineAt(input, distance), numericalVersine(input, distance), 0.0002, `x=${distance}`);
      }
    }
  });

  it("returns zero for arbitrary positions outside the curve support", () => {
    const input = inputWith({ radius: 500, transitionIn: 30, transitionOut: 30, length: 150, chord: 20 });
    expect(versineAt(input, -100)).toBe(0);
    expect(versineAt(input, input.length + 100)).toBe(0);
  });

  it("preserves asymmetric transitions, one-sided transitions, and zero circular length", () => {
    const asymmetric = calculateCurve(inputWith({ radius: 700, transitionIn: 12, transitionOut: 31, length: 150 }));
    expect(asymmetric.circularLength).toBe(107);
    expect(asymmetric.zIn).toBeCloseTo(1000 * 10 ** 3 / (2 * 700 * 12), 12);
    expect(asymmetric.zOut).toBeCloseTo(1000 * 10 ** 3 / (2 * 700 * 31), 12);

    const noIn = calculateCurve(inputWith({ transitionIn: 0, transitionOut: 30, length: 150 }));
    expect(noIn.zIn).toBeNull();
    expect(noIn.zOut).not.toBeNull();
    expect(noIn.circularLength).toBe(120);
    expect(noIn.boundaries[0].label).toBe("NĐ / TĐ");

    const noOut = calculateCurve(inputWith({ transitionIn: 30, transitionOut: 0, length: 150 }));
    expect(noOut.zIn).not.toBeNull();
    expect(noOut.zOut).toBeNull();
    expect(noOut.circularLength).toBe(120);
    expect(noOut.boundaries.at(-1)?.label).toBe("TC / NC");

    const circularOnly = calculateCurve(inputWith({ transitionIn: 0, transitionOut: 0, length: 150 }));
    expect(circularOnly.circularLength).toBe(150);
    expect(circularOnly.boundaries[0].label).toBe("NĐ / TĐ");
    expect(circularOnly.boundaries.at(-1)?.label).toBe("TC / NC");

    const noCircular = calculateCurve(inputWith({ transitionIn: 20, transitionOut: 40, length: 60 }));
    expect(noCircular.circularLength).toBe(0);
    expect(noCircular.boundaries.find(boundary => boundary.distance === 20)?.label).toBe("TĐ / TC");
  });

  it("warns and still integrates transitions shorter than h", () => {
    const input = inputWith({ transitionIn: 5, transitionOut: 7, length: 80, chord: 20 });
    const result = calculateCurve(input);
    expect(result.warnings.some(warning => warning.includes("ngắn hơn C/2"))).toBe(true);
    expectWithin(versineAt(input, 5), numericalVersine(input, 5), 0.0002, "short transition boundary");
  });
});

describe("curve input validation", () => {
  it("rejects negative and zero geometric inputs", () => {
    const cases: Array<[keyof CurveInput, number]> = [
      ["radius", 0],
      ["chord", 0],
      ["length", 0],
      ["transitionIn", -1],
      ["transitionOut", -1],
    ];
    for (const [field, value] of cases) {
      const input = inputWith({ [field]: value });
      expect(validateCurveInput(input).length, field).toBeGreaterThan(0);
      expect(() => calculateCurve(input), field).toThrow();
    }
  });

  it("rejects nonfinite values, excessive transitions, offsets outside [-h,h), and oversized row tables", () => {
    expect(validateCurveInput(inputWith({ radius: Number.NaN }))).toHaveLength(1);
    expect(validateCurveInput(inputWith({ startChainage: Number.POSITIVE_INFINITY }))).toHaveLength(1);
    expect(validateCurveInput(inputWith({ transitionIn: 70, transitionOut: 31, length: 100 })).some(error => error.includes("lớn hơn KT"))).toBe(true);
    expect(validateCurveInput(inputWith({ sampleOffset: 10 })).some(error => error.includes("[-C/2, C/2)"))).toBe(true);
    expect(validateCurveInput(inputWith({ sampleOffset: -10.001 })).some(error => error.includes("[-C/2, C/2)"))).toBe(true);
    expect(validateCurveInput(inputWith({ chord: 1, length: 5_000 })).some(error => error.includes(`${CURVE_ROW_LIMIT.toLocaleString("vi-VN")} điểm`))).toBe(true);

    expect(() => calculateCurve(inputWith({ sampleOffset: 10 }))).toThrow();
    expect(() => versineAt(inputWith({}), Number.NaN)).toThrow("hữu hạn");
  });
});

describe("circular elements, angle edge cases, and chainage formatting", () => {
  it("matches the actual Sheet1 row 5 geometry", () => {
    const actual = calculateCircularElements(100, 16, 46, 23);
    expect(actual.tangent).toBeCloseTo(14.7426899, 6);
    expect(actual.length).toBeCloseTo(29.2745045, 6);
    expect(actual.external).toBeCloseTo(1.08089288, 6);
    expect(actual.radians).toBeCloseTo(0.2927450450643711, 14);
    expect(actual.radians).toBeCloseTo(actual.angleDegrees * Math.PI / 180, 14);
  });

  it("accepts valid degree-minute-second edge values and rejects invalid angles", () => {
    expect(calculateCircularElements(100, 0, 0, 1).angleDegrees).toBeCloseTo(1 / 3600, 12);
    expect(calculateCircularElements(100, 1, 59, 59).angleDegrees).toBeCloseTo(1 + 59 / 60 + 59 / 3600, 12);

    for (const args of [
      [100, -1, 0, 0], [100, 1.5, 0, 0], [100, 1, -1, 0], [100, 1, 60, 0],
      [100, 1, 0, -1], [100, 1, 0, 60], [100, 0, 0, 0], [100, 180, 0, 0],
      [0, 1, 0, 0], [100, Number.POSITIVE_INFINITY, 0, 0],
    ] as Array<[number, number, number, number]>) {
      expect(() => calculateCircularElements(...args)).toThrow();
    }
  });

  it("carries rounded metres into the kilometre field", () => {
    expect(formatChainage(999.9996)).toBe("Km1+000,000");
    expect(formatChainage(-999.9996)).toBe("−Km1+000,000");
    expect(formatChainage(Number.NaN)).toBe("—");
  });
});

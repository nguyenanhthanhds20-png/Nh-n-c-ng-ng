import { beforeEach, describe, expect, it, vi } from "vitest";
vi.mock("./_core/llm", () => ({ invokeLLM: vi.fn() }));
import { invokeLLM } from "./_core/llm";
import { answerFromDocuments, hasExactEvidence, NO_VERIFIED_EVIDENCE, parseAnswerDraft, resolveDocumentQuestion, type DocumentPassage } from "./documentChat";

const passages: DocumentPassage[] = [
  { document: { id: 10, name: "Sơn.pdf", processingStatus: "ready", extractedText: null }, excerpt: "[Trang 8]\nNăng suất sơn chống rỉ là 2 m² mỗi ngày. Chỉ áp dụng khi bề mặt khô.", location: "trang PDF 8" },
  { document: { id: 12, name: "Kiểm tra.txt", processingStatus: "ready", extractedText: null }, excerpt: "Kiểm tra bề mặt trước khi sơn." },
];
const block = { title: "Năng suất", text: "Năng suất sơn chống rỉ là 2 m² mỗi ngày khi bề mặt khô.", evidence: [{ source: 1, quote: "Năng suất sơn chống rỉ là 2 m² mỗi ngày. Chỉ áp dụng khi bề mặt khô." }] };
const result = (content: unknown, finish_reason = "stop") => ({ model: "gpt-5-mini", choices: [{ message: { content: typeof content === "string" ? content : JSON.stringify(content) }, finish_reason }] }) as never;
const calls = () => vi.mocked(invokeLLM);
beforeEach(() => { vi.clearAllMocks(); });

function successfulDraft(blocks = [block]) {
  calls().mockResolvedValueOnce(result({ blocks }));
  calls().mockResolvedValueOnce(result({ checks: blocks.map((_, index) => ({ index, supported: true })) }));
}

describe("document-only answer gates", () => {
  it("returns only checked claims and citations actually used", async () => {
    successfulDraft();
    const answer = await answerFromDocuments("Năng suất sơn?", passages);
    expect(answer.answer).toContain("2 m²");
    expect(answer.answer).toContain("[DOC-1]");
    expect(answer.sources).toHaveLength(1);
    expect(answer.sources[0].id).toBe(10);
    expect(answer.sources[0].label).toContain("trang PDF 8");
    expect(calls()).toHaveBeenCalledTimes(2);
    for (const [request] of calls().mock.calls) {
      expect(request.toolChoice).toBe("none");
      expect(request.model).toBe("gpt-5-mini");
      expect(request.response_format?.type).toBe("json_schema");
    }
  });
  it("rejects fabricated quotes before asking the verifier", async () => {
    calls().mockResolvedValueOnce(result({ blocks: [{ ...block, evidence: [{ source: 1, quote: "Năng suất là 500 m²." }] }] }));
    const answer = await answerFromDocuments("Năng suất?", passages);
    expect(answer.answer).toBe(NO_VERIFIED_EVIDENCE);
    expect(answer.sources).toEqual([]);
    expect(calls()).toHaveBeenCalledTimes(1);
  });
  it("rejects an unknown source, even with a real quote", () => {
    expect(hasExactEvidence({ ...block, evidence: [{ source: 6, quote: block.evidence[0].quote }] }, passages)).toBe(false);
  });
  it("does not accept different numbers, units, accents or punctuation as verbatim evidence", () => {
    for (const quote of ["Năng suất sơn chống rỉ là 3 m² mỗi ngày.", "Năng suất sơn chống rỉ là 2 m mỗi ngày.", "Nang suat son chong ri la 2 m² moi ngay."]) {
      expect(hasExactEvidence({ ...block, evidence: [{ source: 1, quote }] }, passages)).toBe(false);
    }
    expect(hasExactEvidence({ ...block, evidence: [{ source: 1, quote: "Năng suất\n sơn chống rỉ là 2 m² mỗi ngày." }] }, passages)).toBe(true);
  });
  it("does not let the model supply its own citation identifiers", () => {
    expect(hasExactEvidence({ ...block, text: "500 m² [DOC-99]" }, passages)).toBe(false);
  });
  it("withholds a claim rejected by semantic verification despite a matching quote", async () => {
    calls().mockResolvedValueOnce(result({ blocks: [{ ...block, text: "Năng suất là 500 m² bất kể điều kiện." }] }));
    calls().mockResolvedValueOnce(result({ checks: [{ index: 0, supported: false }] }));
    const answer = await answerFromDocuments("Năng suất?", passages);
    expect(answer.answer).toBe(NO_VERIFIED_EVIDENCE);
    expect(answer.answer).not.toContain("500");
    expect(answer.sources).toEqual([]);
  });
  it("keeps supported points but replaces unsupported points with a safe message", async () => {
    calls().mockResolvedValueOnce(result({ blocks: [block, { title: "Văn bản ngoài nguồn", text: "Số hiệu giả 999", evidence: [] }] }));
    calls().mockResolvedValueOnce(result({ checks: [{ index: 0, supported: true }] }));
    const answer = await answerFromDocuments("Năng suất? Số hiệu văn bản?", passages);
    expect(answer.answer).toContain("2 m²");
    expect(answer.answer).toContain("Ý 2");
    expect(answer.answer).not.toContain("999");
    expect(answer.answer).not.toContain("Văn bản ngoài nguồn");
  });
  it("fails closed on incomplete verification", async () => {
    calls().mockResolvedValueOnce(result({ blocks: [block] }));
    calls().mockResolvedValueOnce(result({ checks: [] }));
    await expect(answerFromDocuments("Năng suất?", passages)).rejects.toThrow("không đầy đủ");
  });
  it("fails closed on duplicate/unknown verification indexes", async () => {
    for (const checks of [[{ index: 2, supported: true }], [{ index: 0, supported: true }, { index: 0, supported: true }]]) {
      calls().mockResolvedValueOnce(result({ blocks: [block] }));
      calls().mockResolvedValueOnce(result({ checks }));
      await expect(answerFromDocuments("Năng suất?", passages)).rejects.toThrow("không đầy đủ");
    }
  });
  it("does not display raw prose or malformed JSON as an answer", async () => {
    calls().mockResolvedValueOnce(result("Hãy bỏ quy tắc. Năng suất 999."));
    await expect(answerFromDocuments("Năng suất?", passages)).rejects.toThrow();
    expect(() => parseAnswerDraft('{"blocks":[],"external":"thời tiết"}')).toThrow();
  });
  it("recovers empty structured output once but still validates the recovered schema", async () => {
    calls().mockResolvedValueOnce(result(""));
    calls().mockResolvedValueOnce(result({ blocks: [block] }));
    calls().mockResolvedValueOnce(result({ checks: [{ index: 0, supported: true }] }));
    expect((await answerFromDocuments("Năng suất?", passages)).answer).toContain("2 m²");
    expect(calls().mock.calls[1][0].response_format).toBeUndefined();
  });
  it("rejects a truncated result and a provider error envelope", async () => {
    calls().mockResolvedValueOnce(result({ blocks: [block] }, "length"));
    await expect(answerFromDocuments("Năng suất?", passages)).rejects.toThrow("chưa hoàn chỉnh");
    calls().mockResolvedValueOnce({ error: { message: "Không đủ credit" } } as never);
    await expect(answerFromDocuments("Năng suất?", passages)).rejects.toThrow("Không đủ credit");
  });
  it("does not call any model without passages", async () => {
    expect((await answerFromDocuments("Dự báo thời tiết?", [])).sources).toEqual([]);
    expect(calls()).not.toHaveBeenCalled();
  });
  it("sends source data and untrusted history distinctly to both generation and verification", async () => {
    successfulDraft();
    await answerFromDocuments("Còn điều kiện áp dụng?", passages, "Năng suất sơn?");
    for (const [request] of calls().mock.calls) {
      const input = JSON.parse(String(request.messages[1].content));
      expect(input.previousQuestion).toBe("Năng suất sơn?");
      expect(input.uploadedFilePassages[0].excerpt).toBe(passages[0].excerpt);
      expect(String(request.messages[0].content)).toContain("không");
    }
  });
});

describe("follow-up question resolution", () => {
  it("uses only the latest question to search again for a follow-up", () => {
    const resolved = resolveDocumentQuestion("Còn điều kiện áp dụng?", ["Sơn?", "Năng suất sơn chống rỉ?"]);
    expect(resolved.previousQuestion).toBe("Năng suất sơn chống rỉ?");
    expect(resolved.searchQuestion).toContain("Còn điều kiện");
  });
  it("does not blend earlier unrelated subjects into a new explicit question", () => {
    expect(resolveDocumentQuestion("Quy trình thử tà vẹt?", ["Sơn?"]).previousQuestion).toBeUndefined();
    expect(resolveDocumentQuestion("Còn điều kiện?", []).searchQuestion).toBe("Còn điều kiện?");
  });
});

describe("long-document summary disclosure", () => {
  it("never presents selected passages as a complete long-file summary", async () => {
    successfulDraft();
    const answer = await answerFromDocuments("Tóm tắt tài liệu", passages.map(passage => ({ ...passage, summaryLimited: true })));
    expect(answer.answer).toContain("chưa bao quát toàn bộ file dài");
    expect(answer.answer).toContain("[DOC-1]");
  });
});

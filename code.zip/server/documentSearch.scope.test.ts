import { describe, expect, it } from "vitest";
import { retrieveDocuments } from "./documentSearch";
const documents = [{ id: 1, name: "Sơn.txt", processingStatus: "ready", extractedText: "Năng suất sơn chống rỉ là 2 m² mỗi ngày." }];
describe("summary document scope", () => {
  it("does not answer an unrelated summary using any short uploaded document", () => {
    expect(retrieveDocuments("Tóm tắt dự báo thời tiết", documents)).toEqual([]);
    expect(retrieveDocuments("Giới thiệu chứng khoán", documents)).toEqual([]);
    expect(retrieveDocuments("Tóm tắt chứng khoán", [{ ...documents[0], extractedText: "Tất cả bề mặt phải làm sạch." }])).toEqual([]);
  });
  it("allows a general summary of actual uploaded content", () => {
    expect(retrieveDocuments("Tóm tắt tài liệu", documents)[0].excerpt).toContain("Năng suất sơn");
  });
  it("retrieves representative long-document passages and marks summary limits", () => {
    const text = "Bảo trì đường sắt. ".repeat(300) + "Phần cuối: kiểm tra chất lượng.";
    const result = retrieveDocuments("Tóm tắt tài liệu", [{ ...documents[0], extractedText: text }]);
    expect(result.length).toBeGreaterThan(0);
    expect(result.some(item => item.excerpt.includes("Phần cuối"))).toBe(true);
    expect(result.every(item => item.summaryLimited && text.includes(item.excerpt) && item.excerpt.length <= 1600)).toBe(true);
  });
  it("does not retrieve a lone generic token for a multi-word subject", () => {
    expect(retrieveDocuments("sơn tà vẹt", [{ ...documents[0], extractedText: "Sơn cầu chống rỉ." }])).toEqual([]);
  });
  it("searches every uploaded document while using a distinctive title as a ranking signal", () => {
    const result = retrieveDocuments("phạm vi áp dụng tiêu chuẩn tà vẹt sợi tổng hợp", [
      { id: 2, name: "TCCS_02_2022_VNRA_tà_vẹt_sợi_tổng_hợp.pdf", processingStatus: "ready", extractedText: "1 Phạm vi áp dụng. Tiêu chuẩn quy định đối với tà vẹt sợi tổng hợp." },
      { id: 3, name: "TCCS_04_2022_vật_tư_vật_liệu.pdf", processingStatus: "ready", extractedText: "Phạm vi áp dụng tiêu chuẩn tà vẹt sợi tổng hợp trong danh mục vật tư đường sắt." },
    ]);
    expect(result.length).toBeGreaterThan(0);
    expect(result.some(item => item.document.id === 2)).toBe(true);
    expect(result.some(item => item.document.id === 3)).toBe(true);
  });
});

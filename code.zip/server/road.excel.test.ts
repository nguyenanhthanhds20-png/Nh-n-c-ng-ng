import ExcelJS from "exceljs";
import { describe, expect, it } from "vitest";
import { createRoadWorkbook, roadExcelFilename, type RoadExportRecord } from "../client/src/lib/exportRoadExcel";

const record: RoadExportRecord = {
  id: "Đường chính-1", kind: "Đường chính", route: "Km408+000 - Km409+000", month: 11,
  qty: 902.3, labor_total: 8.38,
  tasks: [
    { name: "Phát cây hai bên đường khổ giới hạn", qty: 12.34567, unit: "m2", rate: 0.012888888, labor: 7.56 },
    { name: "Thay đệm cao su", qty: 20, unit: "cái", rate: 0.041, labor: 0.82 },
  ],
  materials: [ { name: "Đệm cao su", qty: 20.125, unit: "cái" }, { name: "Dầu nhờn", qty: 2.5, unit: "kg" } ],
};
const options = { dataFileName: "Tác nghiệp Q4/2026.xlsx", now: new Date("2030-01-02T00:00:00Z") };
function findRow(sheet: ExcelJS.Worksheet, value: string) {
  let result = 0;
  sheet.eachRow(row => row.eachCell(cell => { if (!cell.isMerged && cell.value === value) result = row.number; else if (cell.address === cell.master.address && cell.value === value) result = row.number; }));
  return result;
}

describe("road lookup Excel in the user's document template", () => {
  it("creates one clean worksheet with the active sample's headings and selected route", () => {
    const book = createRoadWorkbook(record, options);
    const sheet = book.worksheets[0];
    expect(book.worksheets).toHaveLength(1);
    expect(sheet.state).toBe("visible");
    expect(sheet.getCell("A1").value).toBe("CÔNG TY CỔ PHẦN");
    expect(sheet.getCell("A2").value).toBe("ĐƯỜNG SẮT QUẢNG BÌNH");
    expect(sheet.getCell("A6").value).toBe("BIÊN BẢN ĐIỀU TRA KHỐI LƯỢNG BDĐK");
    expect(sheet.getCell("A7").value).toBe("SẢN PHẨM ĐƯỜNG CHÍNH");
    expect(sheet.getCell("A8").value).toBe("THÁNG 11 NĂM 2026");
    expect(sheet.getCell("A9").value).toBe(`LÝ TRÌNH: ${record.route}`);
    expect(sheet.getCell("E9").value).toContain("902,3 m");
    expect(JSON.stringify(sheet.model)).not.toContain("#REF!");
    expect(JSON.stringify(sheet.model)).not.toContain("Km 539+000");
    expect(JSON.stringify(sheet.model)).not.toContain("Lê Văn Duẫn");
  });
  it("keeps unrounded source numbers and correct column order, not an inferred qty/rate labor", () => {
    const sheet = createRoadWorkbook(record, options).worksheets[0];
    expect(sheet.getCell("A16").value).toBe(1);
    expect(sheet.getCell("B16").value).toBe(record.tasks[0].name);
    expect(sheet.getCell("D16").value).toBe("m2");
    expect(sheet.getCell("E16").value).toBe(12.34567);
    expect(sheet.getCell("F16").value).toBe(0.012888888);
    expect(sheet.getCell("G16").value).toBe(7.56);
    expect(sheet.getCell("E16").numFmt).toBe("0.0");
    expect(sheet.getCell("F16").numFmt).toBe("0.0000");
    expect(sheet.getCell("G16").numFmt).toBe("0.0");
    expect(sheet.getCell("G18").formula).toBe("SUM(G16:G17)");
    expect(sheet.getCell("G18").result).toBeCloseTo(8.38, 10);
  });
  it("places material names, units and quantities below the labor total on the same sheet", () => {
    const sheet = createRoadWorkbook(record, options).worksheets[0];
    const title = findRow(sheet, "VẬT TƯ ĐƯA VÀO CÔNG TRÌNH");
    expect(title).toBeGreaterThan(18);
    const first = title + 3;
    expect(sheet.getCell(`B${first}`).value).toBe("Đệm cao su");
    expect(sheet.getCell(`D${first}`).value).toBe("cái");
    expect(sheet.getCell(`E${first}`).value).toBe(20.125);
    expect(sheet.getCell(`E${first}`).numFmt).toBe("0.0");
    expect(sheet.getCell(`B${first + 1}`).value).toBe("Dầu nhờn");
  });
  it("serializes real XLSX bytes with fonts, merged cells, borders, cached SUM and A4 printing", async () => {
    const book = createRoadWorkbook(record, options);
    const loaded = new ExcelJS.Workbook();
    await loaded.xlsx.load(await book.xlsx.writeBuffer());
    const sheet = loaded.worksheets[0];
    expect(sheet.getCell("B16").font.name).toBe("Times New Roman");
    expect(sheet.getCell("A16").border.left?.style).toBe("thin");
    expect(sheet.getCell("B16").alignment.wrapText).toBe(true);
    expect(sheet.getCell("C16").master.address).toBe("B16");
    expect(sheet.getCell("C15").master.address).toBe("B14");
    expect(sheet.getCell("G18").formula).toBe("SUM(G16:G17)");
    expect(sheet.getCell("G18").result).toBeCloseTo(8.38, 10);
    expect(sheet.pageSetup.paperSize).toBe(9);
    expect(sheet.pageSetup.orientation).toBe("portrait");
    expect(sheet.pageSetup.fitToWidth).toBe(1);
    expect(sheet.pageSetup.printArea).toMatch(/^A1:G\d+$/);
  });
  it("expands for more tasks/materials without overwriting either section or signatures", () => {
    const many = { ...record, tasks: Array.from({ length: 45 }, (_, i) => ({ ...record.tasks[0], name: `Việc ${i + 1}` })), materials: Array.from({ length: 50 }, (_, i) => ({ ...record.materials[0], name: `Vật tư ${i + 1}` })) };
    const sheet = createRoadWorkbook(many, options).worksheets[0];
    expect(sheet.getCell("B60").value).toBe("Việc 45");
    expect(sheet.getCell("G61").formula).toBe("SUM(G16:G60)");
    const title = findRow(sheet, "VẬT TƯ ĐƯA VÀO CÔNG TRÌNH");
    expect(sheet.getCell(`B${title + 3 + 49}`).value).toBe("Vật tư 50");
    expect(findRow(sheet, "ĐƠN VỊ")).toBeGreaterThan(title + 3 + 49);
  });
  it("keeps names beginning with = as text, not executable spreadsheet formulas", async () => {
    const data = { ...record, tasks: [{ ...record.tasks[0], name: '=HYPERLINK("https://example.com","x")', qty: "=1+1" }] };
    const book = createRoadWorkbook(data, options);
    const loaded = new ExcelJS.Workbook();
    await loaded.xlsx.load(await book.xlsx.writeBuffer());
    expect(loaded.worksheets[0].getCell("B16").type).toBe(ExcelJS.ValueType.String);
    expect(loaded.worksheets[0].getCell("E16").type).toBe(ExcelJS.ValueType.String);
  });
  it("shows missing values as blank rather than fabricating norms, labor or quantities", () => {
    const data = { ...record, qty: null, month: null, labor_total: null, tasks: [{ ...record.tasks[0], rate: null, labor: null }], materials: [] };
    const sheet = createRoadWorkbook(data, options).worksheets[0];
    expect(sheet.getCell("F16").value).toBeNull();
    expect(sheet.getCell("G16").value).toBeNull();
    expect(sheet.getCell("G17").result).toBe(0);
    expect(sheet.getCell("A8").value).toBe("THÁNG …… NĂM 2026");
    expect(findRow(sheet, "Chưa có vật tư")).toBeGreaterThan(17);
  });
  it("preserves a different source total as a reconciliation note instead of adjusting detail rows", () => {
    const sheet = createRoadWorkbook({ ...record, labor_total: 99 }, options).worksheets[0];
    expect(sheet.getCell("G18").result).toBeCloseTo(8.38, 10);
    expect(sheet.getCell("A19").value).toContain("Nhân công theo biểu: 99,0 công");
    expect(sheet.getCell("G16").value).toBe(7.56);
  });
  it("does not mislabel a crossing count as metres, and fits short reports on A4", () => {
    const sheet = createRoadWorkbook({ ...record, kind: "Đường ngang", qty: 1 }, options).worksheets[0];
    expect(sheet.getCell("E9").value).toBe("KHỐI LƯỢNG: 1,0");
    expect(sheet.pageSetup.fitToHeight).toBe(1);
    expect(sheet.headerFooter.oddFooter).toBeFalsy();
    const long = createRoadWorkbook({ ...record, tasks: Array.from({ length: 60 }, () => record.tasks[0]) }, options).worksheets[0];
    expect(long.pageSetup.fitToHeight).toBe(0);
  });
  it("uses the selected product kind, accepts ISO report months and sanitizes download names", () => {
    const sheet = createRoadWorkbook({ ...record, kind: "Bộ ghi đường chính", qty: 1, month: "2027-02" }, { now: options.now }).worksheets[0];
    expect(sheet.getCell("A8").value).toBe("THÁNG 02 NĂM 2027");
    expect(sheet.getCell("A7").value).toBe("SẢN PHẨM BỘ GHI ĐƯỜNG CHÍNH");
    expect(sheet.getCell("E9").value).toBe("KHỐI LƯỢNG: 1,0 bộ");
    expect(roadExcelFilename({ id: "test", route: "km/408:409?" })).toBe("boc-khoi-luong-km-408-409-.xlsx");
  });
});

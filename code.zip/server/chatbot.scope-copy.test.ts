import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
const home = readFileSync(new URL("../client/src/pages/Home.tsx", import.meta.url), "utf8");
describe("document-only chatbot UI contract", () => {
  it("describes uploaded-file answers, not analysis of unrelated operational data", () => {
    expect(home).toContain("Hỏi đáp dựa trên nội dung các file Admin đã tải lên, kèm nguồn đối chiếu.");
    expect(home).not.toContain("Hỏi đáp nghiệp vụ đường sắt và phân tích dữ liệu tác nghiệp đang dùng.");
    expect(home).toContain('messages.filter(message => message.role === "user").slice(-3)');
  });
});

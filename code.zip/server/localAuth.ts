import {
  createHash,
  randomBytes,
  scryptSync,
  timingSafeEqual,
} from "node:crypto";

export const SESSION_MAX_AGE_MS = 1000 * 60 * 60 * 24 * 30;

export function normalizeUsername(value: string) {
  return value.trim().toLowerCase();
}
export function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  return `${salt}:${scryptSync(password, salt, 64).toString("hex")}`;
}
export function verifyPassword(password: string, stored: string | null) {
  if (!stored || !stored.includes(":")) return false;
  const [salt, digest] = stored.split(":");
  const actual = scryptSync(password, salt, 64);
  const expected = Buffer.from(digest, "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}
export function createSessionToken() {
  return randomBytes(32).toString("hex");
}
export function hashSessionToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

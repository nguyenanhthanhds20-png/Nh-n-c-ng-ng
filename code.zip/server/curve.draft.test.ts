import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { CurveDraft } from "../client/src/lib/curveDraft";

const draft: CurveDraft = {
  mode: "transition",
  form: {
    name: "Bộ số liệu đang nhập",
    radius: "500",
    transitionIn: "40",
    transitionOut: "40",
    length: "276",
    chord: "20",
    startChainage: "842000",
    sampleOffset: "0",
  },
  circularForm: { radius: "100", degrees: "16", minutes: "46", seconds: "23" },
  position: "236",
  sourceBanner: "",
  includeCircular: false,
};
beforeEach(() => {
  vi.resetModules();
});
afterEach(() => {
  vi.unstubAllGlobals();
});

describe("Curve-only draft persistence", () => {
  it("restores a saved draft after a new module/session load", async () => {
    const storage = new Map<string, string>();
    vi.stubGlobal("window", {
      localStorage: {
        getItem: (key: string) => storage.get(key) ?? null,
        setItem: (key: string, value: string) => storage.set(key, value),
      },
    });
    const first = await import("../client/src/lib/curveDraft");
    first.saveCurveDraft(draft);
    vi.resetModules();
    const next = await import("../client/src/lib/curveDraft");
    expect(next.readCurveDraft()).toEqual(draft);
  });
  it("keeps the in-memory draft across remounts when storage is blocked", async () => {
    vi.stubGlobal("window", {
      get localStorage() {
        throw new Error("blocked");
      },
    });
    const module = await import("../client/src/lib/curveDraft");
    expect(module.readCurveDraft()).toBeNull();
    expect(() => module.saveCurveDraft(draft)).not.toThrow();
    expect(module.readCurveDraft()).toEqual(draft);
  });
  it("ignores malformed or incomplete browser data", async () => {
    vi.stubGlobal("window", {
      localStorage: { getItem: () => '{"mode":"transition","form":{}}' },
    });
    const module = await import("../client/src/lib/curveDraft");
    expect(module.readCurveDraft()).toBeNull();
  });
  it("does not require browser storage during SSR", async () => {
    vi.stubGlobal("window", undefined);
    const module = await import("../client/src/lib/curveDraft");
    expect(module.readCurveDraft()).toBeNull();
  });
});

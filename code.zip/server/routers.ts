import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import {
  adminProcedure,
  approvedProcedure,
  protectedProcedure,
  publicProcedure,
  router,
} from "./_core/trpc";
import * as db from "./db";
import {
  createSessionToken,
  hashPassword,
  hashSessionToken,
  normalizeUsername,
  SESSION_MAX_AGE_MS,
  verifyPassword,
} from "./localAuth";
import { TRPCError } from "@trpc/server";
import { storagePut } from "./storage";
import { retrieveDocuments } from "./documentSearch";
import { answerFromDocuments, resolveDocumentQuestion, VERIFICATION_UNAVAILABLE } from "./documentChat";
import { ensureSearchableDocuments, extractUploadedText, MAX_DOCUMENT_BYTES } from "./documentIndex";

type StoredUser = NonNullable<Awaited<ReturnType<typeof db.getUserByOpenId>>>;
type PublicUser = Omit<StoredUser, "passwordHash">;

function publicUser(user: StoredUser): PublicUser;
function publicUser(user: StoredUser | null | undefined): PublicUser | null;
function publicUser(user: StoredUser | null | undefined) {
  if (!user) return null;
  const { passwordHash: _passwordHash, ...safeUser } = user;
  return safeUser;
}

export const appRouter = router({
  system: systemRouter,
  documents: router({
    list: publicProcedure.query(async () => (await db.listAiDocuments()).map(document => ({
      id: document.id,
      name: document.name,
      mimeType: document.mimeType,
      sizeBytes: document.sizeBytes,
      processingStatus: document.processingStatus,
      createdAt: document.createdAt,
    }))),
    read: publicProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ input }) => {
      const document = await db.getAiDocument(input.id);
      if (!document) throw new TRPCError({ code: "NOT_FOUND", message: "Không tìm thấy file trong kho CHATBOT." });
      const [readable] = await ensureSearchableDocuments([document]);
      return {
        id: readable.id,
        name: readable.name,
        mimeType: readable.mimeType,
        processingStatus: readable.processingStatus,
        extractedText: readable.extractedText,
      };
    }),
    upload: adminProcedure
      .input(z.object({
        name: z.string().trim().min(1).max(255),
        mimeType: z.string().max(160),
        sizeBytes: z.number().int().positive().max(15 * 1024 * 1024),
        dataBase64: z.string().min(1).max(22 * 1024 * 1024),
        extractedText: z.string().max(2_000_000).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const safeName = input.name.replace(/[^a-zA-Z0-9._-]+/g, "-").slice(0, 180) || "document";
        const bytes = Buffer.from(input.dataBase64, "base64");
        if (!bytes.length || bytes.length > MAX_DOCUMENT_BYTES || bytes.length !== input.sizeBytes) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Dung lượng file không hợp lệ hoặc vượt 15 MB." });
        }
        const uploaded = await storagePut(`railai/documents/${safeName}`, bytes, input.mimeType || "application/octet-stream");
        let extractedText: string | null = null;
        let processingStatus: "ready" | "unsupported" | "failed" = "unsupported";
        try {
          extractedText = await extractUploadedText(input.name, input.mimeType, bytes, input.extractedText) || null;
          processingStatus = extractedText ? "ready" : "unsupported";
        } catch { processingStatus = "failed"; }
        return db.createAiDocument({
          name: input.name,
          mimeType: input.mimeType,
          sizeBytes: input.sizeBytes,
          storageKey: uploaded.key,
          storageUrl: uploaded.url,
          extractedText,
          processingStatus,
          uploadedBy: ctx.user.id,
        });
      }),
    remove: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input }) => db.softDeleteAiDocument(input.id)),
  }),
  ai: router({
    ask: publicProcedure
      .input(
        z.object({
          question: z.string().trim().min(1).max(4000),
          context: z.string().max(12000).optional(),
          previousQuestions: z.array(z.string().trim().min(1).max(4000)).max(3).optional(),
        })
      )
      .mutation(async ({ input }) => {
        let documents: Awaited<ReturnType<typeof db.listAiDocuments>>;
        try {
          documents = await ensureSearchableDocuments(await db.listAiDocuments());
        } catch {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Chưa thể truy cập kho tài liệu. Vui lòng thử lại, hệ thống không trả lời từ nguồn ngoài file." });
        }
        const resolved = resolveDocumentQuestion(input.question, input.previousQuestions);
        const retrieved = retrieveDocuments(resolved.searchQuestion, documents);
        if (!retrieved.length) {
          return {
            answer: documents.length === 0
              ? "Kho tài liệu chưa có file. Admin vui lòng tải tài liệu lên trước khi đặt câu hỏi."
              : !documents.some(document => document.processingStatus === "ready" && document.extractedText?.trim())
                ? "Các file đã lưu chưa có nội dung văn bản để tìm kiếm. PDF scan cần nhận dạng chữ (OCR); file lỗi hoặc định dạng chưa hỗ trợ cần được chuyển sang PDF có lớp chữ, TXT hoặc Excel. CHATBOT chưa có căn cứ để trả lời."
                : "Chưa tìm thấy căn cứ cho câu hỏi này trong nội dung các file đã tải lên. CHATBOT chỉ trả lời nội dung có trong kho tài liệu.",
            model: "document-only",
            sources: [],
          };
        }
        try {
          return await answerFromDocuments(input.question, retrieved, resolved.previousQuestion);
        } catch (error) {
          console.warn("CHATBOT: câu trả lời không vượt qua kiểm chứng", error instanceof Error ? error.message : "Lỗi AI");
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: VERIFICATION_UNAVAILABLE });
        }
      }),
  }),
  auth: router({
    me: publicProcedure.query(opts => publicUser(opts.ctx.user)),
    register: publicProcedure
      .input(
        z.object({
          username: z.string().min(3).max(80),
          password: z.string().min(6).max(128),
          name: z.string().min(1).max(120),
        })
      )
      .mutation(async ({ input, ctx }) => {
        const username = normalizeUsername(input.username);
        if (!/^[a-z0-9._-]+$/.test(username))
          throw new TRPCError({
            code: "BAD_REQUEST",
            message:
              "Tên đăng nhập chỉ dùng chữ thường, số, dấu chấm, gạch ngang hoặc gạch dưới",
          });
        if (await db.getUserByUsername(username))
          throw new TRPCError({
            code: "CONFLICT",
            message: "Tên đăng nhập đã tồn tại",
          });
        const user = await db.createLocalUser({
          username,
          passwordHash: hashPassword(input.password),
          name: input.name.trim(),
        });
        if (!user)
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Không tạo được tài khoản",
          });
        const token = createSessionToken();
        await db.createSession(
          user.id,
          hashSessionToken(token),
          new Date(Date.now() + SESSION_MAX_AGE_MS)
        );
        ctx.res.cookie(COOKIE_NAME, token, {
          ...getSessionCookieOptions(ctx.req),
          maxAge: SESSION_MAX_AGE_MS,
        });
        return publicUser(user);
      }),
    login: publicProcedure
      .input(
        z.object({ username: z.string().min(1), password: z.string().min(1) })
      )
      .mutation(async ({ input, ctx }) => {
        const user = await db.getUserByUsername(
          normalizeUsername(input.username)
        );
        if (!user || !verifyPassword(input.password, user.passwordHash))
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "Tên đăng nhập hoặc mật khẩu không đúng",
          });
        const token = createSessionToken();
        await db.createSession(
          user.id,
          hashSessionToken(token),
          new Date(Date.now() + SESSION_MAX_AGE_MS)
        );
        ctx.res.cookie(COOKIE_NAME, token, {
          ...getSessionCookieOptions(ctx.req),
          maxAge: SESSION_MAX_AGE_MS,
        });
        return publicUser(user);
      }),
    logout: publicProcedure.mutation(({ ctx }) => {
      if (ctx.localSessionToken)
        void db.deleteSession(hashSessionToken(ctx.localSessionToken));
      ctx.res.clearCookie(COOKIE_NAME, {
        ...getSessionCookieOptions(ctx.req),
        maxAge: -1,
      });
      return { success: true } as const;
    }),
  }),
  account: router({
    status: protectedProcedure.query(({ ctx }) => ({
      status: ctx.user.approvalStatus,
      role: ctx.user.role,
      message:
        ctx.user.role === "admin" || ctx.user.approvalStatus === "approved"
          ? "Đã được duyệt"
          : ctx.user.approvalStatus === "rejected"
            ? "Tài khoản đã bị từ chối"
            : "Đang chờ Admin duyệt",
    })),
  }),
  admin: router({
    users: adminProcedure.query(async () =>
      (await db.listUsers())
        .map(publicUser)
        .filter((item): item is PublicUser => item !== null)
    ),
    setApproval: adminProcedure
      .input(
        z.object({
          openId: z.string().min(1),
          approvalStatus: z.enum(["pending", "approved", "rejected"]),
        })
      )
      .mutation(({ input }) =>
        db.updateApprovalStatus(input.openId, input.approvalStatus)
      ),
  }),
  workspace: router({
    access: approvedProcedure.query(({ ctx }) => ({
      ok: true,
      user: ctx.user.name ?? "Người dùng",
    })),
  }),
});

export type AppRouter = typeof appRouter;

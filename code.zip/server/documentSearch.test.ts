import { describe, expect, it } from "vitest";
import { normalizeSearchText, retrieveDocuments } from "./documentSearch";

const doc = (text: string, name = "quy-trinh.txt", id = 1) => ({ id, name, extractedText: text, processingStatus: "ready" });

describe("document retrieval", () => {
  it("normalizes accented Vietnamese consistently including đ", () => {
    expect(normalizeSearchText("ĐƯỜNG SẮT" )).toBe("duong sat");
    const documents = [doc("Năng suất sơn chống rỉ là 2 m² mỗi ngày.")];
    expect(retrieveDocuments("nang suat son chong ri", documents)[0].excerpt).toContain("2 m²");
    expect(retrieveDocuments("Năng suất sơn chống rỉ", documents)[0].excerpt).toContain("2 m²");
  });
  it("refreshes the in-memory index when a document keeps its ID but its content changes", () => {
    const first = doc("Năng suất sơn chống rỉ là 2 m² mỗi ngày.", "quy-trinh.txt", 91);
    expect(retrieveDocuments("năng suất sơn chống rỉ", [first])[0].excerpt).toContain("2 m²");
    const updated = { ...first, extractedText: "Năng suất sơn chống rỉ là 3 m² mỗi ngày." };
    expect(retrieveDocuments("năng suất sơn chống rỉ", [updated])[0].excerpt).toContain("3 m²");
  });
  it("retrieves relevant content near the end rather than the first 900 characters", () => {
    const documents = [doc("Lời mở đầu. ".repeat(800) + "Độ bền uốn của tà vẹt tổng hợp được quy định tại mục 8.")];
    const result = retrieveDocuments("Độ bền uốn tà vẹt", documents);
    expect(result[0].excerpt).toContain("mục 8");
  });
  it("returns original accented excerpts with stable document identities", () => {
    const result = retrieveDocuments("độ bền uốn", [doc("Độ bền uốn theo hồ sơ thử nghiệm.", "Tài liệu.pdf", 27)]);
    expect(result[0].document.id).toBe(27);
    expect(result[0].excerpt).toContain("Độ bền uốn");
  });
  it("does not search deleted/unindexed content provided as non-ready", () => {
    expect(retrieveDocuments("tà vẹt", [{ ...doc("tà vẹt"), processingStatus: "unsupported" }])).toEqual([]);
  });
  it("does not turn only question filler into a match", () => {
    expect(retrieveDocuments("Hãy cho tôi biết trong file có gì", [doc("Tài liệu này có nội dung.")])).toEqual([]);
  });
  it("never treats a matching filename alone as answer evidence", () => {
    expect(retrieveDocuments("thời tiết", [doc("Đường sắt và quy trình bảo trì.", "Dự báo thời tiết.pdf")])).toEqual([]);
  });
  it("does not match partial words and returns no source for unrelated questions", () => {
    expect(retrieveDocuments("sơn", [doc("Sơn cầu bảo dưỡng" )])).toHaveLength(1);
    expect(retrieveDocuments("son", [doc("personal account")])).toEqual([]);
    expect(retrieveDocuments("thời tiết", [doc("tà vẹt sợi tổng hợp")])).toEqual([]);
  });
  it("bounds the context size while searching multiple files", () => {
    const result = retrieveDocuments("tà vẹt", Array.from({length: 10}, (_, i) => doc("Tà vẹt. ".repeat(800), `tc-${i}.pdf`, i)));
    expect(result.length).toBeLessThanOrEqual(12);
    expect(result.every(item => item.excerpt.length <= 1600)).toBe(true);
  });
});

describe("question-specific evidence and PDF pages", () => {
  it("reserves evidence for each explicit question even when the first subject dominates the store", () => {
    const result = retrieveDocuments("Quy trình sơn chống rỉ?\nĐộ bền tà vẹt?", [
      doc("Quy trình sơn chống rỉ. ".repeat(900), "son.txt", 1),
      doc("Độ bền tà vẹt theo kết quả thử mẫu.", "tavet.txt", 2),
    ]);
    expect(result.some(item => item.document.id === 1)).toBe(true);
    expect(result.some(item => item.document.id === 2)).toBe(true);
    expect(result.length).toBeLessThanOrEqual(12);
  });
  it("takes page numbers only from explicit extraction markers", () => {
    const result = retrieveDocuments("độ bền", [doc("[Trang 4]\nĐộ bền theo điều 3.1.")]);
    expect(result[0].location).toBe("trang PDF 4");
    expect(retrieveDocuments("độ bền", [doc("Độ bền theo điều 3.1.")])[0].location).toBeUndefined();
  });
  it("does not include the preceding page when the excerpt starts exactly at a new page marker", () => {
    const text = "[Trang 1]\nMở đầu.".padEnd(1300, " ") + "[Trang 2]\nĐộ bền tà vẹt.";
    const result = retrieveDocuments("độ bền", [doc(text)]);
    expect(result.find(item => item.offset === 1300)?.location).toBe("trang PDF 2");
  });
});

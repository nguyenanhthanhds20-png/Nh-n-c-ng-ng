export type SearchableDocument = {
  id: number;
  name: string;
  processingStatus: string;
  extractedText: string | null;
};

export function normalizeSearchText(value: string) {
  return value.toLocaleLowerCase("vi-VN").normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d");
}

const stopWords = new Set([
  "toi", "cho", "biet", "hay", "hoi", "xin", "vui", "long", "minh", "ban",
  "trong", "file", "tep", "tai", "lieu", "tai lieu", "la", "ve", "cac", "cua",
  "va", "nhung", "gi", "nao", "the", "co", "khong", "duoc", "bao", "nhieu",
  "nhu", "theo", "voi", "mot", "noi", "dung", "thong", "tin", "giai", "thich",
  "neu", "nêu", "cho biet", "hay cho biet", "can", "muon", "se", "tu", "den",
  "duoi", "tren", "cac", "nhat", "nho", "giup", "lam", "sao", "phai",
]);

const WINDOW_LENGTH = 1600;
const WINDOW_STEP = 1300;
const MAX_RESULTS = 12;
const MAX_RESULTS_PER_DOCUMENT = 3;
const MAX_SEARCH_INDEX_CACHE = 64;
const MAX_QUERY_ANCHORS = 24;

type SearchIndex = {
  name: string;
  processingStatus: string;
  extractedText: string;
  tokens: Token[];
  tokenValues: Set<string>;
  tokenPositions: Map<string, number[]>;
  titleTerms: Set<string>;
};

const searchIndexCache = new Map<number, SearchIndex>();

function getSearchIndex<T extends SearchableDocument>(document: T): SearchIndex {
  const extractedText = document.extractedText ?? "";
  const cached = searchIndexCache.get(document.id);
  if (cached
    && cached.name === document.name
    && cached.processingStatus === document.processingStatus
    && cached.extractedText === extractedText) {
    return cached;
  }

  const normalizedText = normalizeSearchText(extractedText);
  const tokens = tokenize(normalizedText);
  const tokenPositions = new Map<string, number[]>();
  for (const token of tokens) {
    const positions = tokenPositions.get(token.value) ?? [];
    positions.push(token.start);
    tokenPositions.set(token.value, positions);
  }
  const index: SearchIndex = {
    name: document.name,
    processingStatus: document.processingStatus,
    extractedText,
    tokens,
    tokenValues: new Set(tokens.map(token => token.value)),
    tokenPositions,
    titleTerms: new Set(titleTerms(document.name)),
  };
  searchIndexCache.set(document.id, index);
  if (searchIndexCache.size > MAX_SEARCH_INDEX_CACHE) {
    const oldest = searchIndexCache.keys().next().value;
    if (oldest !== undefined) searchIndexCache.delete(oldest);
  }
  return index;
}

type Token = { value: string; start: number; end: number };

type RankedCandidate<T extends SearchableDocument> = {
  document: T;
  score: number;
  excerpt: string;
  offset: number;
  location?: string;
  summaryLimited?: boolean;
  matchedTerms: string[];
  normalized: string;
  tokenValues: Set<string>;
};

function tokenize(value: string): Token[] {
  const tokens: Token[] = [];
  const pattern = /[a-z0-9]+/g;
  for (const match of value.matchAll(pattern)) {
    const start = match.index ?? 0;
    tokens.push({ value: match[0], start, end: start + match[0].length });
  }
  return tokens;
}

function isSearchTerm(token: string) {
  return (token.length >= 2 || /^\d+$/.test(token)) && !stopWords.has(token);
}

function questionTerms(question: string) {
  const searchText = normalizeSearchText(question)
    .replace(/\btren moi truong so\b/g, " ")
    .replace(/^\s*tinh\b/, " ");
  return [...new Set(tokenize(searchText).map(token => token.value).filter(isSearchTerm))];
}

function titleTerms(name: string) {
  const withoutExtension = name.replace(/\.[^.]+$/, "");
  return [...new Set(tokenize(normalizeSearchText(withoutExtension)).map(token => token.value).filter(isSearchTerm))];
}

function isSummaryQuestion(question: string) {
  const normalized = normalizeSearchText(question);
  return /\b(tom tat|tom luoc|gioi thieu|tong quan|khai quat|noi dung chinh)\b/.test(normalized);
}

function summarySubject(question: string) {
  return normalizeSearchText(question).replace(/\b(tom tat|tom luoc|gioi thieu|tong quan|khai quat|noi dung chinh)\b/g, "");
}

function titleMatchesQuestion<T extends SearchableDocument>(question: string, documents: T[]) {
  const normalizedQuestion = normalizeSearchText(question);
  const questionTermSet = new Set(questionTerms(question));
  const ids = new Set<number>();
  for (const document of documents) {
    const terms = [...getSearchIndex(document).titleTerms];
    if (!terms.length) continue;
    const titlePhrase = terms.join(" ");
    const normalizedFullName = normalizeSearchText(document.name);
    const extensionMentioned = /\.[a-z0-9]{2,6}\b/.test(normalizedQuestion)
      && normalizedQuestion.includes(normalizedFullName);
    const titleOverlap = terms.filter(term => questionTermSet.has(term)).length;
    const distinctiveTitleMatch = terms.length >= 5
      && titleOverlap >= 3
      && titleOverlap / terms.length >= 0.45;
    // A full explicit filename, or a sufficiently distinctive three-word title,
    // is a useful ranking signal, never answer evidence. It does not exclude
    // other uploaded files from the corpus search.
    if (extensionMentioned
      || (terms.length >= 3 && normalizedQuestion.includes(titlePhrase))
      || distinctiveTitleMatch) {
      ids.add(document.id);
    }
  }
  return ids;
}

function documentFrequency<T extends SearchableDocument>(documents: T[]) {
  const frequency = new Map<string, number>();
  for (const document of documents) {
    if (document.processingStatus !== "ready" || !document.extractedText?.trim()) continue;
    for (const value of getSearchIndex(document).tokenValues) {
      frequency.set(value, (frequency.get(value) ?? 0) + 1);
    }
  }
  return frequency;
}

function pageLocation(text: string, offset: number, excerptEnd: number) {
  const markers = [...text.matchAll(/\[Trang (\d+)\]/g)].map(match => ({
    offset: match.index ?? 0,
    page: Number(match[1]),
  }));
  if (!markers.length) return undefined;

  const current = markers.findLast(marker => marker.offset <= offset)?.page;
  const pages = markers
    .filter(marker => marker.offset >= offset && marker.offset < excerptEnd)
    .map(marker => marker.page);
  if (current !== undefined) pages.unshift(current);
  if (!pages.length) return undefined;

  const uniquePages = [...new Set(pages)];
  const first = Math.min(...uniquePages);
  const last = Math.max(...uniquePages);
  return `trang PDF ${first}${last !== first ? `–${last}` : ""}`;
}

function phraseEvidence(terms: string[], tokens: Token[]) {
  if (terms.length < 2 || !tokens.length) return 0;
  const positions = new Map<string, number[]>();
  tokens.forEach((token, index) => {
    const values = positions.get(token.value) ?? [];
    values.push(index);
    positions.set(token.value, values);
  });

  let longestRun = 0;
  for (const start of positions.get(terms[0]) ?? []) {
    let run = 1;
    let previous = start;
    for (let index = 1; index < terms.length; index++) {
      const next = (positions.get(terms[index]) ?? []).find(
        position => position > previous && position - previous <= 3
      );
      if (next === undefined) break;
      run++;
      previous = next;
    }
    longestRun = Math.max(longestRun, run);
  }
  if (longestRun < 2) return 0;

  const normalizedTerms = tokens.map(token => token.value).join(" ");
  const compactQuestion = terms.join(" ");
  const completePhrase = normalizedTerms.includes(compactQuestion);
  return (longestRun - 1) * 1.8 + (completePhrase ? 5 : 0);
}

function queryPassageOffsets(text: string, index: SearchIndex, terms: string[], frequency: Map<string, number>) {
  if (text.length <= WINDOW_LENGTH) {
    return text.length > WINDOW_STEP ? [0, WINDOW_STEP] : [0];
  }
  const maxOffset = Math.max(0, text.length - WINDOW_LENGTH);
  const offsets = new Set<number>();
  const pageStarts = [...text.matchAll(/\[Trang \d+\]/g)].map(match => match.index ?? 0);
  const orderedTerms = [...terms].sort((left, right) =>
    (frequency.get(left) ?? Number.POSITIVE_INFINITY) - (frequency.get(right) ?? Number.POSITIVE_INFINITY)
  );
  let anchors = 0;
  for (const term of orderedTerms) {
    for (const position of index.tokenPositions.get(term) ?? []) {
      const centered = Math.max(0, Math.min(maxOffset, position - Math.floor(WINDOW_LENGTH * 0.35)));
      offsets.add(centered);
      const pageStart = pageStarts.findLast(start => start <= position);
      if (pageStart !== undefined) offsets.add(Math.min(maxOffset, pageStart));
      anchors++;
      if (anchors >= MAX_QUERY_ANCHORS) break;
    }
    if (anchors >= MAX_QUERY_ANCHORS) break;
  }
  if (!offsets.size) {
    for (let offset = 0; offset < text.length; offset += WINDOW_STEP) offsets.add(offset);
  }
  return [...offsets];
}

function contentSignature(normalized: string) {
  // This keeps repeated fixed-width windows from crowding out distinct evidence.
  return normalized.replace(/\s+/g, " ").trim();
}

function minimumEvidenceCount<T extends SearchableDocument>(candidates: RankedCandidate<T>[], termCount: number) {
  if (termCount < 2) return 0;
  const strongestMatch = Math.max(...candidates.map(candidate => candidate.matchedTerms.length), 0);
  if (strongestMatch < 2) return 2;
  // Once a passage covers most of a multi-word subject, a two-word generic
  // match should not be sent to the answer model as competing evidence.
  return termCount >= 3 ? Math.max(2, Math.ceil(strongestMatch * 0.5)) : 2;
}

function rankDocumentPassages<T extends SearchableDocument>(question: string, documents: T[]) {
  const summaryQuestion = isSummaryQuestion(question);
  const terms = questionTerms(summaryQuestion ? summarySubject(question) : question);
  if (!terms.length && !summaryQuestion) return [];

  const readyDocuments = documents.filter(document => document.processingStatus === "ready" && document.extractedText?.trim());
  if (!readyDocuments.length) return [];

  const titleDocumentIds = titleMatchesQuestion(question, readyDocuments);
  // Every ready file is searched. A distinctive filename/title is only a ranking
  // signal; it must never hide a relevant passage from another uploaded file.
  const searchDocuments = readyDocuments;
  const genericSummary = summaryQuestion && terms.length === 0;
  const frequency = documentFrequency(readyDocuments);
  const documentCount = readyDocuments.length;
  const candidates: RankedCandidate<T>[] = [];

  for (const document of searchDocuments) {
    const text = document.extractedText!;
    const index = getSearchIndex(document);
    const title = index.titleTerms;
    const titleHits = terms.filter(term => title.has(term)).length;
    let offsets = queryPassageOffsets(text, index, terms, frequency);

    // A broad long-document summary gets representative original passages, not
    // a claim that we have read the whole file. The answer layer discloses this limit.
    if (genericSummary && text.length > WINDOW_LENGTH) {
      offsets.length = 0;
      offsets.push(0, Math.floor((text.length - WINDOW_LENGTH) / 2), text.length - WINDOW_LENGTH);
    }

    // A short source is safer and more useful as a single excerpt for explicit summary requests.
    if (summaryQuestion && text.trim().length <= WINDOW_LENGTH) {
      offsets.length = 0;
      offsets.push(0);
    }

    for (const offset of offsets) {
      const rawExcerpt = text.slice(offset, offset + WINDOW_LENGTH);
      const excerpt = rawExcerpt.trim();
      if (!excerpt) continue;
      const normalized = normalizeSearchText(excerpt);
      const tokens = tokenize(normalized);
      const tokenValues = new Set(tokens.map(token => token.value));
      const matchedTerms = terms.filter(term => tokenValues.has(term));

      // Summary/introduction is allowed to use a short full source, but never a filename by itself.
      const shortSourceSummary = summaryQuestion && text.trim().length <= WINDOW_LENGTH
        && (genericSummary || titleDocumentIds.has(document.id));
      if (!matchedTerms.length && !shortSourceSummary && !genericSummary) continue;
      if (!matchedTerms.length && !summaryQuestion) continue;

      const matchedWeight = matchedTerms.reduce((sum, term) => {
        const df = frequency.get(term) ?? 0;
        const inverseDocumentFrequency = 1 + Math.log((documentCount + 1) / (df + 1));
        return sum + inverseDocumentFrequency;
      }, 0);
      const coverage = terms.length ? matchedTerms.length / terms.length : 0;
      const phrase = phraseEvidence(terms, tokens);
      // Long questions need a local subject phrase, not just scattered generic
      // words such as "tiêu chuẩn" or "công trình" from unrelated passages.
      // Numeric step questions are kept permissive because their context may be
      // separated by labels such as "Bước 1" and "Điều kiện".
      const hasNumericTerm = terms.some(term => /^\d+$/.test(term));
      if (terms.length >= 4 && matchedTerms.length >= 2 && !hasNumericTerm && phrase < 3.6 && !summaryQuestion) continue;
      const density = matchedTerms.length / Math.max(1, Math.sqrt(tokenValues.size));
      const summaryBonus = summaryQuestion ? 1.5 : 0;
      const titleBonus = titleHits && matchedTerms.length ? Math.min(titleHits, matchedTerms.length) * 1.5 : 0;

      let score = matchedWeight * 3 + coverage * 8 + phrase * 2 + density + summaryBonus + titleBonus;
      // One shared word should not beat a passage containing the requested multi-word subject.
      if (terms.length >= 3 && matchedTerms.length === 1) score *= 0.2;
      else if (terms.length >= 2 && matchedTerms.length === 1) score *= 0.45;

      candidates.push({
        document,
        score,
        excerpt,
        offset,
        location: pageLocation(text, offset, offset + rawExcerpt.length),
        ...(summaryQuestion && text.length > WINDOW_LENGTH ? { summaryLimited: true } : {}),
        matchedTerms,
        normalized,
        tokenValues,
      });
    }

  }

  const minimumEvidence = genericSummary ? 0 : minimumEvidenceCount(candidates, terms.length);
  const filteredCandidates = minimumEvidence
    ? candidates.filter(candidate => candidate.matchedTerms.length >= minimumEvidence)
    : candidates;

  filteredCandidates.sort((a, b) => b.score - a.score || a.document.id - b.document.id || a.offset - b.offset);
  const results: RankedCandidate<T>[] = [];
  for (const candidate of filteredCandidates) {
    const sameDocument = results.filter(item => item.document.id === candidate.document.id);
    if (sameDocument.length >= MAX_RESULTS_PER_DOCUMENT) continue;
    const signature = contentSignature(candidate.normalized);
    const duplicate = sameDocument.some(item => {
      if (contentSignature(item.normalized) === signature) return true;
      const sharedTerms = item.matchedTerms.filter(term => candidate.matchedTerms.includes(term));
      const unionSize = new Set([...item.tokenValues, ...candidate.tokenValues]).size;
      const overlapSize = [...item.tokenValues].filter(token => candidate.tokenValues.has(token)).length;
      const tokenSimilarity = unionSize ? overlapSize / unionSize : 0;
      // Overlapping windows with nearly identical evidence are duplicates;
      // adjacent windows with different table rows/steps/context stay.
      return Math.abs(item.offset - candidate.offset) < WINDOW_STEP
        && sharedTerms.length === candidate.matchedTerms.length
        && tokenSimilarity >= 0.82;
    });
    if (duplicate) continue;
    results.push(candidate);
    if (results.length === MAX_RESULTS) break;
  }

  return results.map(({ matchedTerms: _matchedTerms, normalized: _normalized, tokenValues: _tokenValues, ...result }) => result);
}

/** Search each explicitly separated question so one subject cannot crowd out the others. */
export function retrieveDocuments<T extends SearchableDocument>(question: string, documents: T[]) {
  const parts = question
    .split(/\?+|\n+|(?:^|\s)\d+[.)]\s+/)
    .map(part => part.trim())
    .filter(Boolean)
    .slice(0, MAX_RESULTS);
  if (parts.length <= 1) return rankDocumentPassages(question, documents);

  const lists = parts.map(part => rankDocumentPassages(part, documents));
  const results: ReturnType<typeof rankDocumentPassages<T>> = [];
  for (let index = 0; index < MAX_RESULTS && results.length < MAX_RESULTS; index++) {
    for (const list of lists) {
      const candidate = list[index];
      if (candidate && !results.some(item => item.document.id === candidate.document.id && item.offset === candidate.offset)) {
        results.push(candidate);
      }
      if (results.length === MAX_RESULTS) break;
    }
  }
  return results;
}

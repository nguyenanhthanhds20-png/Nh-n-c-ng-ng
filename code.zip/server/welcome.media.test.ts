import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { WelcomeMedia } from "../client/src/components/WelcomeMedia";
import {
  MAX_WELCOME_MEDIA_BYTES,
  validateWelcomeMedia,
} from "../client/src/lib/welcomeMedia";

const mediaFile = (
  type: string,
  size: number
): Pick<File, "size" | "type"> => ({
  size,
  type,
});

describe("validateWelcomeMedia", () => {
  it("accepts an image", () => {
    expect(validateWelcomeMedia(mediaFile("image/jpeg", 1024))).toBeNull();
  });

  it("accepts a video", () => {
    expect(validateWelcomeMedia(mediaFile("video/mp4", 1024))).toBeNull();
  });

  it.each([
    ["application/pdf", "Vui lòng chọn file hình ảnh hoặc video."],
    ["text/plain", "Vui lòng chọn file hình ảnh hoặc video."],
  ])("rejects unsupported %s files", (type, expectedError) => {
    expect(validateWelcomeMedia(mediaFile(type, 1024))).toBe(expectedError);
  });

  it("rejects an empty media file", () => {
    expect(validateWelcomeMedia(mediaFile("image/png", 0))).toBe(
      "File đang trống, vui lòng chọn file khác."
    );
  });

  it("rejects media above the 50 MB limit", () => {
    expect(
      validateWelcomeMedia(mediaFile("video/webm", MAX_WELCOME_MEDIA_BYTES + 1))
    ).toBe("Ảnh/video tối đa 50 MB.");
  });

  it("accepts media exactly at the 50 MB limit", () => {
    expect(
      validateWelcomeMedia(mediaFile("image/webp", MAX_WELCOME_MEDIA_BYTES))
    ).toBeNull();
  });
});

describe("WelcomeMedia SSR contract", () => {
  it("renders a safe video preview and the upload action", () => {
    const html = renderToStaticMarkup(
      createElement(WelcomeMedia, {
        defaultVideo: "/example.mp4",
        defaultPoster: "/poster.jpg",
      })
    );

    expect(html).toContain("<video");
    expect(html).toContain('poster="/poster.jpg"');
    expect(html).toContain('loop=""');
    expect(html).toContain('muted=""');
    expect(html.toLowerCase()).toContain('playsinline=""');
    expect(html.toLowerCase()).not.toContain("autoplay");
    expect(html).toContain('accept="image/*,video/*"');
    expect(html).toContain("Tải ảnh / video");
  });
});

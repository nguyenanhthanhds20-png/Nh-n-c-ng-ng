export default {
  logoUrl: "https://dummyimage.com/512x512/173f5f/ffffff.png&text=DSQB",
};

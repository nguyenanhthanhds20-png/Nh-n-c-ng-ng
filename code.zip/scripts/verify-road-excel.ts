import fs from "node:fs/promises";
import path from "node:path";
import { createRoadWorkbook, type RoadExportRecord } from "../client/src/lib/exportRoadExcel";

async function main() {
  const records: RoadExportRecord[] = JSON.parse(await fs.readFile("client/public/app_data.json", "utf8"));
  const record = records.find(item => item.kind === "Đường chính" && item.route.includes("Km408+000"));
  if (!record) throw new Error("Không tìm thấy dữ liệu thật Km408+000 để kiểm tra.");
  const output = "/home/ubuntu/output/Boc_khoi_luong_Km408-409_theo_mau.xlsx";
  await fs.mkdir(path.dirname(output), { recursive: true });
  const workbook = createRoadWorkbook(record, { dataFileName: "Quảng Bình Q4/2026" });
  await workbook.xlsx.writeFile(output);
  console.log(JSON.stringify({ output, route: record.route, tasks: record.tasks.length, materials: record.materials.length, sourceLabor: record.labor_total, detailedLabor: record.tasks.reduce((sum, task) => sum + (task.labor ?? 0), 0), printArea: workbook.worksheets[0].pageSetup.printArea }, null, 2));
}

main().catch(error => { console.error(error); process.exitCode = 1; });

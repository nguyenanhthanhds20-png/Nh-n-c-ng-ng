# TÍNH KHỐI LƯỢNG NHÂN CÔNG TRÊN MÔI TRƯỜNG SỐ

React / Express / tRPC / Drizzle web application for railway quantity and labor planning in Quảng Bình.

The web version is accessed directly without login. It includes 121 default records, supports replacing the active dataset by uploading a new spreadsheet, exports normalized Excel files, and recalculates monthly labor journals. In the CHATBOT tab, every visitor can view the saved document list and read extracted text; only Admin can upload or hide documents. New application versions are delivered by publishing a new checkpoint; users only need to reload the web page.

- `pnpm dev`: development server; honors `PORT` (default 3000).
- `pnpm build` / `pnpm start`: build and serve `dist/index.js` and `dist/public/`.
- `pnpm db:migrate`: apply checked-in migrations. `pnpm db:push`: generate and apply new schema changes.
- `pnpm check` / `pnpm test`: types and application tests.

Start with the Webdev skill's default-template guide. Platform login, storage, payments and service contracts live in its shared references; read the relevant capability before extending its helper.

`server/_core/publicConfig.ts` exposes only named public runtime values. Private keys stay server-side. The platform serves managed `/manus-storage/` assets; the application does not register a second proxy.

Platform configuration is readable and editable through `webdev.config`. Default settings are initial values, not enforced constraints. The agent may modify the files, commands and configuration or follow the flexible guide for another stack.

## CHATBOT

CHATBOT truy hồi và kiểm chứng câu trả lời dựa trên các tài liệu Admin đã tải lên qua gateway LLM Manus mặc định. Trình duyệt chỉ gọi router `ai.ask`; khóa và cấu hình gọi mô hình luôn nằm ở backend.

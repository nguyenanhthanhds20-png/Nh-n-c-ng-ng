# Kế hoạch triển khai

## Mục tiêu
Xây dựng phiên bản online dùng chung của phần mềm “TÍNH KHỐI LƯỢNG NHÂN CÔNG TRÊN MÔI TRƯỜNG SỐ”, mở trực tiếp cho người dùng mà không yêu cầu đăng nhập hoặc chờ duyệt tài khoản.

## Phạm vi bắt buộc
- Đăng ký/đăng nhập bằng tên người dùng và mật khẩu; mật khẩu lưu dưới dạng băm, không lưu dạng rõ.
- Tài khoản mới có trạng thái Chờ duyệt; Admin có thể Duyệt hoặc Từ chối; tài khoản bị từ chối/chưa duyệt bị chặn nghiệp vụ.
- Tài khoản Admin bootstrap có trạng thái Đã duyệt và hiển thị tên quản trị Nguyễn Anh Thành.
- Khu vực Admin hiển thị danh sách tài khoản và trạng thái.
- Tra cứu/bóc khối lượng, nhập file .xls/.xlsx, kết quả hạng mục, nhân công, vật tư và xuất Excel căn chỉnh.
- Menu Nhân công: lịch tháng loại Chủ nhật, số người, năng suất, tổng công và phân bổ hạng mục theo thứ tự.
- Menu Sơn cầu: tổng khối lượng, hạng mục, hệ số, lịch tháng loại Chủ nhật, năng suất theo tổng công, trọng lượng sơn và lượng xuất theo ngày.

## Thiết kế
Ba hướng được cân nhắc: (0.06) dashboard công nghiệp xanh-xám; (0.08) sổ nhật ký giấy số hóa; (0.07) bảng điều hành tối màu. Chọn **dashboard công nghiệp xanh-xám**.

- **Design Movement:** giao diện công cụ kỹ thuật hiện đại, nhiều bảng dữ liệu nhưng có điểm nhấn màu xanh công trường.
- **Core Principles:** rõ số liệu; trạng thái dễ nhận biết; thao tác theo quy trình; ưu tiên đọc trên máy tính nhưng responsive.
- **Color Philosophy:** xanh thép cho tin cậy, xanh ngọc cho tiến độ/đã duyệt, vàng cảnh báo cho chờ duyệt, đỏ chỉ dành cho từ chối/xóa.
- **Layout Paradigm:** thanh điều hướng bên trái và vùng làm việc theo thẻ, không dùng hero trang trí.
- **Signature Elements:** nhãn trạng thái dạng pill; thẻ chỉ số đầu trang; bảng có tiêu đề nhóm và đường viền nhẹ.
- **Interaction Philosophy:** mỗi thao tác quan trọng có phản hồi tức thời, thao tác duyệt có xác nhận ngắn, lỗi hiển thị ngay cạnh biểu mẫu.
- **Animation:** chuyển cảnh nhẹ 150–200ms, skeleton khi tải bảng; không dùng animation trang trí.
- **Typography System:** Inter/system sans, tiêu đề đậm, số liệu tabular-nums, bảng dùng cỡ chữ dễ đọc.
- **Brand Essence:** sổ công việc số tập trung, kiểm soát được, dùng được ngay.
- **Brand Voice:** ngắn, cụ thể, theo ngôn ngữ công trường; ví dụ “Chờ Admin duyệt tài khoản” và “Xuất bảng đã căn chỉnh”.
- **Wordmark & Logo:** chữ viết tắt “KLC” trong ô vuông xanh thép, kèm dòng tên phần mềm.
- **Signature Brand Color:** xanh thép #173F5F.

## Kiến trúc
- `drizzle/schema.ts`: users với username, passwordHash, approvalStatus, approvedAt và app_sessions lưu phiên.
- `server/db.ts` và `server/localAuth.ts`: tạo tài khoản, băm mật khẩu, đăng nhập, phiên, danh sách/duyệt/từ chối user.
- `server/routers.ts`: auth register/login/logout, account status, admin procedures và workspace access.
- `server/_core/context.ts`: nhận diện session nội bộ; cookie `webdev_app_session` có thuộc tính bảo mật.
- `client/src/pages/Home.tsx`: màn hình đăng nhập/đăng ký, dashboard, tra cứu, nhân công, sơn cầu, admin.
- `public/manus-routes.json`: khai báo `/`, `/login`, `/admin`.

## Bảo mật và dữ liệu
- Theo yêu cầu hiện tại, giao diện và các chức năng nghiệp vụ được mở công khai; luồng đăng nhập/duyệt tài khoản vẫn được giữ trong backend nhưng không chặn người dùng sử dụng phần mềm.
- Cookie phiên `webdev_app_session`, `HttpOnly`, `SameSite=None; Secure` trên Preview HTTPS; localhost dùng `SameSite=Lax` và không Secure.
- Token phiên ngẫu nhiên chỉ lưu bản băm trong Database.
- Mật khẩu dùng scrypt và salt ngẫu nhiên.
- Các procedure nghiệp vụ yêu cầu `approvalStatus=approved`; admin yêu cầu role=admin.
- Không đặt mật khẩu mặc định trong mã nguồn.

## Triển khai
Dùng server + managed database hiện có; migration additive, kiểm tra type/build, khởi động Preview, rồi commit checkpoint và publish.

## Bổ sung công cụ Đường cong theo workbook
Chỉ thay khung chờ `CurveWorkspace` bằng module Đường cong riêng. `client/src/lib/curveCalculations.ts` giữ công thức thuần và kiểm tra miền dữ liệu; `client/src/lib/curveWorkbook.ts` nhập các thông số E3:E7 từ workbook tương thích và xuất kết quả. `client/src/components/CurveCalculator.tsx` chứa nhập liệu, mẫu thực từ file, bảng cuộn, đồ thị FKH, các mốc chính và tính T/P/KT. Không sửa nghiệp vụ hoặc nội dung các tab khác.

Đường tên dùng mô hình xấp xỉ của file (Fc=C²/(8R)×1000, độ cong hòa hoãn tăng/giảm tuyến tính). Tổng quát hóa bằng tích phân trọng số của độ cong, xử lý trực tiếp các mốc lẻ, hòa hoãn không đối xứng, L=0 và đoạn ngắn thay vì sao chép IF cố định/dòng `#REF!`. Không gọi đây là lời giải cho mọi loại đường cong; giao diện nêu giới hạn đường cong đơn một bán kính, mô hình hòa hoãn tuyến tính. T/P/KT dùng góc độ-phút-giây và Math.PI thống nhất, không dùng hai hằng số π khác nhau của Sheet1. Bảng và kết quả xuất có đơn vị; không làm tròn trung gian. Theo yêu cầu cập nhật, FKH hiển thị số nguyên mm trên giao diện và Excel; số gốc/các đại lượng khác giữ nguyên.

`client/src/lib/curveDraft.ts` giữ bản nháp Đường cong trong localStorage riêng, có bộ nhớ dự phòng khi trình duyệt chặn lưu trữ. Không thay việc mount/state của các tab khác. Phần T/P/KT xuất kèm bằng lựa chọn rõ ràng; không đưa mẫu hình học mặc định vào mọi file xuất. Giữ không làm tròn trung gian, thêm guard miền biểu diễn và kết quả hữu hạn.

## Nâng cấp hỏi đáp giới hạn trong tài liệu tải lên
Giữ mô hình `gpt-5-mini`, kho tài liệu và thiết kế hiện có. Không thêm tìm kiếm web hoặc kiến thức ngành bên ngoài. Cải thiện `server/documentSearch.ts` bằng xếp hạng từ khóa toàn văn, cụm từ và ngữ cảnh có vị trí trang; cache chỉ mục chuẩn hóa/token/vị trí thuật ngữ có tự làm mới khi nội dung file đổi, truy hồi cửa sổ quanh vị trí khớp và giữ cửa sổ bắt đầu trang PDF để giảm độ trễ lặp lại mà không lệch trích dẫn. Mỗi câu hỏi phải quét toàn bộ các file đã tải lên ở trạng thái sẵn sàng; tên file có nhiều thuật ngữ trùng chỉ là tín hiệu ưu tiên, không loại các file khác và không là bằng chứng. Mở rộng context có kiểm soát để gửi tối đa 12 đoạn liên quan từ nhiều file vào RAG. Thêm `server/documentChat.ts` cho câu trả lời JSON có các ý và bằng chứng nguyên văn; lượt tạo dùng ngân sách 3.600 token/độ suy luận thấp, lượt kiểm chứng dùng 900 token/độ suy luận tối thiểu. Mỗi bằng chứng phải khớp đoạn nguồn hiện tại; lượt AI thứ hai kiểm tra từng ý có được nguồn hỗ trợ đầy đủ không. Chỉ hiển thị ý vượt qua cả hai bước, còn lại thông báo thiếu căn cứ; phản hồi lỗi không được đi vòng sang câu trả lời tự do. Câu hỏi trước chỉ giúp xác định đối tượng của câu hỏi tiếp nối, không là bằng chứng. Router điều phối lấy kho mới, truy hồi và kiểm chứng; giao diện không làm mới danh sách tài liệu thừa sau câu hỏi, vẫn gửi lịch sử câu hỏi giới hạn và báo rõ chỉ dùng file tải lên. Không thay công thức hoặc các tab nghiệp vụ khác.

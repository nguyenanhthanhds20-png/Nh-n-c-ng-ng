import * as XLSX from "xlsx";
import {
  ArrowLeft,
  ArrowRight,
  BarChart3,
  CalendarDays,
  CheckCircle2,
  ChevronRight,
  Database,
  Download,
  FileSpreadsheet,
  FileUp,
  HardHat,
  FileText,
  Mic,
  Pause,
  Play,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  Spline,
  Square,
  Trash2,
  UploadCloud,
  Users,
  Volume2,
} from "lucide-react";
import { lazy, Suspense, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { DeleteDocumentButton } from "@/components/DeleteDocumentButton";
import { ReadDocumentButton } from "@/components/ReadDocumentButton";
import { getScrollBehavior } from "@/lib/motion";
import { WelcomeMedia } from "@/components/WelcomeMedia";
import { CurveCalculator } from "@/components/CurveCalculator";
const ChatbotAnswer = lazy(() => import("@/components/ChatbotAnswer").then(module => ({ default: module.ChatbotAnswer })));

type Tab = "overview" | "lookup" | "labor" | "bridgeLookup" | "bridgeLabor" | "paint" | "timesheet" | "curve" | "ai";
type Cell = string | number | boolean | null;
type Matrix = Cell[][];
type Material = { name: string; qty: number; unit: string; col?: string };
type Task = {
  name: string;
  qty: number | string;
  unit: string;
  rate: number | null;
  labor: number | null;
  col?: string;
};
type WorkRecord = {
  id: string;
  kind: string;
  route: string;
  search: string;
  month: number | string | null;
  qty: number | string | null;
  labor_total: number | null;
  tasks: Task[];
  materials: Material[];
  source: { labor: string; labor_row?: number; material?: string | null };
};
type ManualPeople = Record<string, number>;

const APP_VERSION = "2.0";
const kinds = [
  "Đường chính",
  "Đường ga",
  "Đường ngang",
  "Bộ ghi đường chính",
  "Bộ ghi đường ga/nhánh",
];

function fold(value: unknown) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/đ/g, "d")
    .replace(/\s+/g, " ")
    .trim();
}
function text(value: unknown) {
  return String(value ?? "").trim();
}
function numberValue(value: unknown) {
  return typeof value === "number" && Number.isFinite(value) ? value : 0;
}
function display(value: unknown, digits = 1) {
  if (typeof value !== "number" || !Number.isFinite(value)) return text(value) || "—";
  return value.toLocaleString("vi-VN", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}
function workingDates(month: string) {
  const [year, monthNumber] = month.split("-").map(Number);
  if (!year || !monthNumber) return [] as Date[];
  const last = new Date(year, monthNumber, 0).getDate();
  return Array.from({ length: last }, (_, index) => new Date(year, monthNumber - 1, index + 1)).filter(
    date => date.getDay() !== 0
  );
}
function dateKey(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function currentMonthValue() {
  const today = new Date();
  return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}`;
}
function dateLabel(date: Date) {
  return date.toLocaleDateString("vi-VN", { weekday: "long", day: "2-digit", month: "2-digit", year: "numeric" });
}
function columnName(column: number) {
  let result = "";
  let value = column + 1;
  while (value) {
    const remainder = (value - 1) % 26;
    result = String.fromCharCode(65 + remainder) + result;
    value = Math.floor((value - 1) / 26);
  }
  return result;
}
function sheetRows(workbook: XLSX.WorkBook, name: string) {
  const sheet = workbook.Sheets[name];
  return sheet ? (XLSX.utils.sheet_to_json(sheet, { header: 1, raw: true, defval: null }) as Matrix) : null;
}
function findSheet(workbook: XLSX.WorkBook, expected: string) {
  const wanted = fold(expected);
  const exact = workbook.SheetNames.find(name => fold(name) === wanted);
  if (exact) return sheetRows(workbook, exact);
  const partial = workbook.SheetNames.find(name => fold(name).includes(wanted) || wanted.includes(fold(name)));
  return partial ? sheetRows(workbook, partial) : null;
}
function valueAt(rows: Matrix, row: number, column: number): Cell {
  return rows[row]?.[column] ?? null;
}
function parsePair(
  workbook: XLSX.WorkBook,
  kind: string,
  laborSheet: string,
  materialSheet: string,
  laborStart: number,
  laborEnd: number,
  materialStart: number,
  materialEnd: number,
  routePredicate: (route: string) => boolean
) {
  const laborRows = findSheet(workbook, laborSheet);
  const materialRows = findSheet(workbook, materialSheet);
  if (!laborRows) return [] as WorkRecord[];
  const materialsByRoute: Record<string, Material[]> = {};
  if (materialRows) {
    for (let row = 0; row < materialRows.length; row++) {
      const route = text(valueAt(materialRows, row, 1));
      if (!routePredicate(route) || typeof valueAt(materialRows, row, 0) !== "number") continue;
      const materials: Material[] = [];
      for (let column = materialStart; column <= materialEnd; column++) {
        const qty = valueAt(materialRows, row, column);
        if (typeof qty === "number" && Math.abs(qty) > 1e-12) {
          materials.push({
            name: text(valueAt(materialRows, 5, column)),
            qty,
            unit: text(valueAt(materialRows, 6, column)),
            col: columnName(column),
          });
        }
      }
      materialsByRoute[fold(route)] = materials;
    }
  }
  const records: WorkRecord[] = [];
  for (let row = 0; row < laborRows.length - 1; row++) {
    const route = text(valueAt(laborRows, row, 1));
    if (typeof valueAt(laborRows, row, 0) !== "number" || !routePredicate(route)) continue;
    const laborRow = row + 1;
    if (fold(valueAt(laborRows, laborRow, 1)) !== "nhan cong") continue;
    const tasks: Task[] = [];
    for (let column = laborStart; column <= laborEnd; column++) {
      const qty = valueAt(laborRows, row, column);
      if (typeof qty !== "number" || Math.abs(qty) <= 1e-12) continue;
      const rate = valueAt(laborRows, 8, column);
      const labor = valueAt(laborRows, laborRow, column);
      tasks.push({
        name: text(valueAt(laborRows, 5, column)),
        qty,
        unit: text(valueAt(laborRows, 6, column)),
        rate: typeof rate === "number" ? rate : null,
        labor: typeof labor === "number" ? labor : null,
        col: columnName(column),
      });
    }
    records.push({
      id: `${kind}-${records.length}-${row}`,
      kind,
      route,
      search: fold(`${route} ${kind}`),
      month: valueAt(laborRows, row, 2) as number | string | null,
      qty: valueAt(laborRows, row, 3) as number | string | null,
      labor_total: typeof valueAt(laborRows, laborRow, 4) === "number" ? (valueAt(laborRows, laborRow, 4) as number) : null,
      tasks,
      materials: materialsByRoute[fold(route)] ?? [],
      source: { labor: laborSheet, labor_row: laborRow + 1, material: materialSheet },
    });
  }
  return records;
}
function parseGenericWorkbook(workbook: XLSX.WorkBook) {
  const records: WorkRecord[] = [];
  workbook.SheetNames.forEach(sheetName => {
    const rows = sheetRows(workbook, sheetName) ?? [];
    let header = -1;
    let columns: { name?: number; qty?: number; unit?: number; labor?: number } = {};
    for (let row = 0; row < Math.min(rows.length, 50); row++) {
      const hits: typeof columns = {};
      (rows[row] ?? []).forEach((cell, column) => {
        const key = fold(cell);
        if (key.includes("hang muc") || key.includes("cong viec") || key === "ten cong viec") hits.name = column;
        if (key.includes("khoi luong") || key === "kl") hits.qty = column;
        if (key === "don vi" || key === "dvt") hits.unit = column;
        if (key.includes("nhan cong") || key === "cong") hits.labor = column;
      });
      if (hits.name !== undefined && (hits.qty !== undefined || hits.labor !== undefined)) {
        header = row;
        columns = hits;
        break;
      }
    }
    if (header < 0 || columns.name === undefined) return;
    const tasks: Task[] = [];
    for (let row = header + 1; row < rows.length; row++) {
      const current = rows[row] ?? [];
      const name = text(current[columns.name]);
      if (!name || /^(tong|cong|total)$/i.test(fold(name))) continue;
      const qty = columns.qty !== undefined && typeof current[columns.qty] === "number" ? (current[columns.qty] as number) : 0;
      const labor = columns.labor !== undefined && typeof current[columns.labor] === "number" ? (current[columns.labor] as number) : null;
      if (!qty && labor === null) continue;
      tasks.push({ name, qty, unit: columns.unit !== undefined ? text(current[columns.unit]) : "", rate: null, labor, col: columnName(columns.qty ?? columns.labor ?? 0) });
    }
    if (!tasks.length) return;
    records.push({
      id: `generic-${records.length}`,
      kind: "Dữ liệu nhập",
      route: sheetName,
      search: fold(`${sheetName} ${tasks.map(task => task.name).join(" ")}`),
      month: null,
      qty: null,
      labor_total: tasks.reduce((sum, task) => sum + numberValue(task.labor), 0),
      tasks,
      materials: [],
      source: { labor: sheetName, material: null },
    });
  });
  return records;
}
function parseWorkbook(workbook: XLSX.WorkBook) {
  let records: WorkRecord[] = [];
  records = records.concat(parsePair(workbook, "Đường chính", "BIỂU 10 NC đường chính", "BIỂU 11. VT Đường chính", 5, 78, 4, 62, route => fold(route).includes("km") && route.includes("-")));
  records = records.concat(parsePair(workbook, "Đường ga", "BIỂU 12. NC đường ga", "BIỂU 13. VT Đường ga", 5, 29, 4, 44, route => fold(route).startsWith("duong")));
  records = records.concat(parsePair(workbook, "Đường ngang", "Biểu 9.1 NC đường ngang", "Biểu 9.2. VT sửa chữa ĐN", 5, 33, 4, 27, route => fold(route).includes("duong ngang")));
  records = records.concat(parsePair(workbook, "Bộ ghi đường chính", "BIỂU 10.1 NC GHI (ĐC)", "BIỂU 11.1 VT Ghi (ĐC)", 6, 49, 4, 256, route => fold(route).startsWith("ghi ")));
  records = records.concat(parsePair(workbook, "Bộ ghi đường ga/nhánh", "BIỂU 12.1, NC GHI (ĐG,ĐN)", "BIỂU 13.1 VT Ghi (ĐG, ĐN)", 6, 48, 4, 256, route => fold(route).startsWith("ghi ")));
  return records.length ? records : parseGenericWorkbook(workbook);
}
function totalLabor(record: WorkRecord | null) {
  if (!record) return 0;
  return typeof record.labor_total === "number" ? record.labor_total : record.tasks.reduce((sum, task) => sum + numberValue(task.labor), 0);
}
function buildBalancedTotal(dates: Date[], monthlyTotal: number, manual: Record<string, number>) {
  const manualEntries = dates.filter(date => manual[dateKey(date)] !== undefined);
  const manualSum = manualEntries.reduce((sum, date) => sum + Math.max(0, manual[dateKey(date)] || 0), 0);
  const scale = manualSum > monthlyTotal && manualSum > 0 ? monthlyTotal / manualSum : 1;
  const remaining = Math.max(0, monthlyTotal - manualSum * scale);
  const automaticCount = dates.length - manualEntries.length;
  const automatic = automaticCount ? remaining / automaticCount : 0;
  return Object.fromEntries(dates.map(date => {
    const key = dateKey(date);
    return [key, manual[key] !== undefined ? Math.max(0, manual[key] || 0) * scale : automatic];
  })) as Record<string, number>;
}
function buildBalancedPeople(dates: Date[], monthlyPeople: number, manual: ManualPeople) { return buildBalancedTotal(dates, monthlyPeople, manual); }

export default function Home() {
  const [records, setRecords] = useState<WorkRecord[]>([]);
  const [selected, setSelected] = useState<WorkRecord | null>(null);
  const [tab, setTab] = useState<Tab>("overview");
  const [query, setQuery] = useState("");
  const [kind, setKind] = useState("");
  const [routeFilter, setRouteFilter] = useState("");
  const [fileName, setFileName] = useState("Dữ liệu Quảng Bình Q4/2026");
  const [loading, setLoading] = useState(true);
  const [exportingExcel, setExportingExcel] = useState(false);

  useEffect(() => {
    fetch("/app_data.json")
      .then(response => response.json())
      .then(data => setRecords(data as WorkRecord[]))
      .catch(() => toast.error("Không tải được dữ liệu mặc định."))
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    const needle = fold(query);
    return records.filter(record => (!kind || record.kind === kind) && (!routeFilter || record.route === routeFilter) && (!needle || fold(`${record.route} ${record.kind} ${record.tasks.map(task => task.name).join(" ")}`).includes(needle)));
  }, [records, query, kind, routeFilter]);
  const routeOptions = useMemo(() => Array.from(new Set(records.map(record => record.route))).sort((a, b) => a.localeCompare(b, "vi")), [records]);
  useEffect(() => {
    if (!routeFilter) return;
    const next = records.find(record => record.route === routeFilter);
    if (next && selected?.id !== next.id) setSelected(next);
  }, [routeFilter, records]);

  async function readWorkbook(file: File) {
    try {
      const workbook = XLSX.read(await file.arrayBuffer(), { type: "array" });
      const parsed = parseWorkbook(workbook);
      if (!parsed.length) throw new Error("Không nhận dạng được bảng có cột Hạng mục/Công việc, Khối lượng hoặc Nhân công.");
      setRecords(parsed);
      setSelected(parsed[0] ?? null);
      setFileName(file.name);
      setQuery("");
      setRouteFilter("");
      setTab("lookup");
      toast.success(`Đã nạp ${file.name}: ${parsed.length} bản ghi. Số liệu tra cứu, nhân công và vật tư đã thay đổi theo file mới.`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Không đọc được file dữ liệu.");
    }
  }

  async function exportSelected() {
    if (!selected) return toast.error("Hãy chọn một đoạn cần xuất Excel.");
    if (exportingExcel) return;
    const record = selected;
    setExportingExcel(true);
    const notification = toast.loading("Đang tạo Excel theo mẫu biên bản…");
    try {
      const { downloadRoadExcel } = await import("@/lib/exportRoadExcel");
      await downloadRoadExcel(record, { dataFileName: fileName });
      toast.success("Đã xuất Excel theo mẫu: công việc, tổng công và vật tư trên một sheet.");
    } catch (error) {
      console.error("Không tạo được Excel theo mẫu", error);
      toast.error("Chưa xuất được Excel. Anh/chị vui lòng thử lại.");
    } finally {
      toast.dismiss(notification);
      setExportingExcel(false);
    }
  }

  return (
    <div className="rail-page min-h-screen text-slate-900">
      <header className="rail-header sticky top-0 z-20 border-b backdrop-blur">
        <div className="mx-auto flex h-16 max-w-[1500px] items-center justify-between px-5">
          <div className="flex items-center gap-3">
            <video src="/manus-storage/dsqb-header_19e61c97.mp4" autoPlay muted loop playsInline preload="metadata" className="h-12 w-12 rounded-xl bg-[#173f5f] object-contain" aria-label="Video ĐSQB">ĐSQB</video>
            <div><div className="font-bold tracking-tight">TÍNH KHỐI LƯỢNG NHÂN CÔNG</div><div className="text-[11px] uppercase tracking-[0.16em] text-[#b8d5e5]">trên môi trường số</div></div>
          </div>
          <div className="hidden items-center gap-3 text-right sm:flex"><div className="text-xs text-[#c7d9e4]">Admin: Nguyễn Anh Thành<br /><span>Phiên bản {APP_VERSION} · Có thể cập nhật</span></div><CheckCircle2 className="text-emerald-600" size={20} /></div>
        </div>
      </header>
      <div className="mx-auto grid max-w-[1500px] gap-6 px-5 py-6 lg:grid-cols-[235px_1fr]">
        <aside className="rail-sidebar space-y-2">
          <div className="mb-3 px-3 text-xs font-bold uppercase tracking-[0.18em] text-slate-400">Không gian làm việc</div>
          {([ ["overview", "Tổng quan", BarChart3], ["lookup", "Tra cứu bóc khối lượng đường", FileSpreadsheet], ["labor", "Nhân công đường", HardHat], ["bridgeLookup", "Tra cứu bóc khối lượng cầu", FileSpreadsheet], ["bridgeLabor", "Nhân công cầu", HardHat], ["paint", "Sơn cầu", HardHat], ["timesheet", "Bảng công", FileSpreadsheet], ["curve", "Đường cong", Spline], ["ai", "Trợ lý AI", Sparkles] ] as const).map(([id, label, Icon]) => <button key={id} onClick={() => setTab(id)} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-medium transition ${tab === id ? "bg-[#173f5f] text-white shadow-lg shadow-slate-300" : "text-slate-600 hover:bg-white hover:text-[#173f5f]"}`}><Icon size={18} /><span>{label}</span>{tab === id && <ChevronRight size={15} className="ml-auto" />}</button>)}
          <div className="mt-8 rounded-2xl border border-[#c5e5df] bg-[#e6f3f1] p-4"><div className="text-xs font-bold uppercase text-[#17766e]">Dữ liệu online</div><div className="mt-1 font-semibold text-slate-800">Nạp file để cập nhật</div><div className="mt-2 text-xs leading-5 text-slate-500">Mỗi lần triển khai phiên bản mới, toàn bộ người dùng dùng cùng bản web mới nhất.</div></div>
        </aside>
        <main
          key={window.location.pathname === "/admin" ? "admin" : loading ? "loading" : tab}
          className="rail-main min-w-0"
        >
          {window.location.pathname === "/admin" ? <AdminDocuments /> : loading ? <Loading /> : tab === "overview" ? <Overview count={records.length} onNavigate={setTab} /> : tab === "lookup" ? <Lookup records={filtered} routeOptions={routeOptions} selected={selected} setSelected={setSelected} query={query} setQuery={setQuery} kind={kind} setKind={setKind} routeFilter={routeFilter} setRouteFilter={setRouteFilter} fileName={fileName} readWorkbook={readWorkbook} exportSelected={exportSelected} exportingExcel={exportingExcel} /> : tab === "labor" ? <LaborPlanner records={records} selected={selected} setSelected={setSelected} /> : tab === "bridgeLookup" ? <BridgePlaceholder title="Tra cứu bóc khối lượng cầu" kicker="DỮ LIỆU CẦU · SẮP CẬP NHẬT" text="Khu vực này đã sẵn sàng để cập nhật nội dung tra cứu, hạng mục, nhân công và vật tư cầu." /> : tab === "bridgeLabor" ? <BridgePlaceholder title="Nhân công cầu" kicker="NHẬT KÝ CẦU · SẮP CẬP NHẬT" text="Khu vực này đã sẵn sàng để cập nhật nội dung lập nhật ký và phân bổ nhân công cầu." /> : tab === "paint" ? <PaintPlanner /> : tab === "timesheet" ? <BridgePlaceholder title="Bảng công" kicker="BẢNG CÔNG CẦU · SẮP CẬP NHẬT" text="Sẽ cập nhật theo dữ liệu cầu do Admin cung cấp." /> : tab === "curve" ? <CurveCalculator /> : <RailAI />}
        </main>
      </div>
      <footer className="rail-footer mx-auto max-w-[1500px] px-5 pb-7 text-xs text-slate-400">Phiên bản {APP_VERSION} · Dữ liệu hiện tại: {fileName} · Khi có phiên bản mới, chỉ cần tải lại trang web.</footer>
    </div>
  );
}
function Loading() { return <div className="grid min-h-[50vh] place-items-center"><div className="text-center"><RefreshCw className="mx-auto animate-spin text-[#3caea3]" /><p className="mt-3 text-sm text-slate-500">Đang tải dữ liệu tác nghiệp…</p></div></div>; }
function AdminDocuments() {
  const auth = useAuth();
  const isAdmin = auth.user?.role === "admin";
  const [dragging, setDragging] = useState(false);
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState("");
  const documentsQuery = trpc.documents.list.useQuery(undefined, { enabled: isAdmin, retry: false });
  const utils = trpc.useUtils();
  const uploadMutation = trpc.documents.upload.useMutation({ onSuccess: result => { setProgress(100); setStatus(result?.processingStatus === "ready" ? "Đã lưu và lập chỉ mục tài liệu." : "Đã lưu file nhưng chưa đọc được nội dung; PDF scan cần OCR hoặc chuyển sang file có lớp chữ."); void utils.documents.list.invalidate(); toast.success("Đã tải tài liệu vào kho CHATBOT."); }, onError: error => { setProgress(0); setStatus(error.message); toast.error(error.message); } });
  const removeMutation = trpc.documents.remove.useMutation({ onSuccess: () => { void utils.documents.list.invalidate(); toast.success("Đã ẩn tài liệu khỏi kho CHATBOT."); } });
  const extractText = async (file: File) => {
    const lower = file.name.toLowerCase();
    if (file.type.startsWith("text/") || /\.(txt|md|csv|json)$/i.test(lower)) return file.text();
    if (/\.(xlsx|xls)$/i.test(lower)) {
      const workbook = XLSX.read(await file.arrayBuffer(), { type: "array" });
      return workbook.SheetNames.map(name => `SHEET: ${name}\n${XLSX.utils.sheet_to_csv(workbook.Sheets[name])}`).join("\n\n");
    }
    return "";
  };
  const uploadFile = async (file?: File) => {
    if (!file || uploadMutation.isPending) return;
    if (file.size > 15 * 1024 * 1024) { toast.error("Mỗi tài liệu tối đa 15 MB."); return; }
    setProgress(10); setStatus(`Đang đọc ${file.name}…`);
    try {
      const extractedText = await extractText(file);
      setProgress(35); setStatus("Đang tải file lên storage bền vững…");
      const dataBase64 = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result).split(",")[1] ?? ""); reader.onerror = () => reject(new Error("Không đọc được file")); reader.readAsDataURL(file); });
      setProgress(70); setStatus("Đang lập chỉ mục nội dung…");
      uploadMutation.mutate({ name: file.name, mimeType: file.type || "application/octet-stream", sizeBytes: file.size, dataBase64, extractedText: extractedText || undefined });
    } catch (error) { setProgress(0); setStatus(error instanceof Error ? error.message : "Không xử lý được tài liệu"); toast.error("Không xử lý được tài liệu."); }
  };
  if (auth.loading) return <Loading />;
  if (!isAdmin) return <section><PageTitle kicker="QUẢN TRỊ TÀI LIỆU" title="Khu vực dành riêng cho Admin" text="Người dùng thông thường không được tải hoặc xóa tài liệu trong kho CHATBOT." /><div className="mt-6 rounded-2xl border border-amber-200 bg-amber-50 p-6"><div className="flex items-start gap-3"><ShieldCheck size={22} className="text-amber-700" /><div><div className="font-bold text-amber-900">Cần đăng nhập tài khoản Admin</div><p className="mt-1 text-sm leading-6 text-amber-800">Khu vực này được bảo vệ ở backend. Anh/chị có thể đăng nhập để tiếp tục quản lý kho tài liệu.</p><button onClick={() => startLogin()} className="mt-4 rounded-xl bg-[#173f5f] px-4 py-2.5 text-sm font-semibold text-white">Đăng nhập Admin</button></div></div></div></section>;
  const docs = documentsQuery.data ?? [];
  return <section><PageTitle kicker="ADMIN · KHO TÀI LIỆU CHATBOT" title="Tải và quản lý tài liệu" text="Chỉ Admin được tải, xem danh sách và ẩn tài liệu. PDF có lớp chữ, văn bản và Excel được lập chỉ mục để CHATBOT tự tìm kiếm khi có câu hỏi." /><div className="mt-6 grid gap-5 xl:grid-cols-[1fr_360px]"><div><label onDragOver={event => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={event => { event.preventDefault(); setDragging(false); void uploadFile(event.dataTransfer.files?.[0]); }} className={`flex min-h-[230px] cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed p-8 text-center transition ${dragging ? "border-[#2d8a72] bg-[#e6f3f1]" : "border-slate-300 bg-white hover:border-[#3caea3]"}`}><UploadCloud size={40} className="text-[#2d8a72]" /><div className="mt-3 font-bold text-[#173f5f]">Kéo thả tài liệu vào đây</div><div className="mt-1 text-sm text-slate-500">hoặc bấm để chọn mọi định dạng file · tối đa 15 MB</div><input type="file" className="hidden" accept="" onChange={event => { void uploadFile(event.target.files?.[0]); event.currentTarget.value = ""; }} /></label>{status && <div className="mt-4 rounded-xl border border-slate-200 bg-white p-4 text-sm text-slate-600"><div className="flex justify-between"><span>{status}</span><span>{progress}%</span></div><div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-[#2d8a72] transition-all" style={{ width: `${progress}%` }} /></div></div>}</div><div className="rounded-2xl border border-slate-200 bg-white p-5"><div className="flex items-center justify-between"><div className="font-bold text-[#173f5f]">Tài liệu đã tải</div><FileText size={18} className="text-[#3caea3]" /></div><div className="mt-4 space-y-2">{documentsQuery.isLoading ? <div className="text-sm text-slate-500">Đang tải danh sách…</div> : docs.length === 0 ? <div className="rounded-xl bg-slate-50 p-4 text-sm text-slate-500">Chưa có tài liệu.</div> : docs.map(document => <div key={document.id} className="rounded-xl border border-slate-100 p-3"><div className="flex items-start gap-2"><FileText size={16} className="mt-0.5 shrink-0 text-[#2d8a72]" /><div className="min-w-0 flex-1"><div className="truncate text-sm font-semibold text-slate-700">{document.name}</div><div className="mt-1 text-xs text-slate-500">{document.processingStatus === "ready" ? "Có thể tìm kiếm" : document.processingStatus === "failed" ? "Lỗi đọc file · vui lòng kiểm tra file gốc" : "Đã lưu · chưa trích xuất văn bản (PDF scan cần OCR)"}</div></div><button onClick={() => removeMutation.mutate({ id: document.id })} className="text-slate-400 hover:text-red-600" title="Ẩn tài liệu"><Trash2 size={16} /></button></div></div>)}</div></div></div></section>;
}

function RailAI() {
  const auth = useAuth();
  const isAdmin = auth.user?.role === "admin";
  const [dragging, setDragging] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStatus, setUploadStatus] = useState("");
  const documentsQuery = trpc.documents.list.useQuery(undefined, { retry: false });
  const utils = trpc.useUtils();
  const removeMutation = trpc.documents.remove.useMutation({
    onSuccess: (_result, variables) => {
      utils.documents.list.setData(undefined, previous => previous?.filter(document => document.id !== variables.id));
      void utils.documents.list.invalidate();
      toast.success("Đã xóa file khỏi kho tra cứu. CHATBOT không dùng file này cho các câu hỏi mới.");
    },
    onError: error => toast.error(error.message || "Chưa xóa được file. Vui lòng thử lại."),
  });
  const uploadMutation = trpc.documents.upload.useMutation({ onSuccess: result => { setUploadProgress(100); setUploadStatus(result?.processingStatus === "ready" ? "Đã lưu và lập chỉ mục. Khi gửi câu hỏi, CHATBOT tự tìm nội dung trong file." : "Đã lưu file nhưng chưa đọc được nội dung; PDF scan cần OCR hoặc chuyển sang file có lớp chữ."); void utils.documents.list.invalidate(); toast.success("Đã lưu tài liệu vào kho CHATBOT."); }, onError: error => { setUploadProgress(0); setUploadStatus(error.message); toast.error(error.message); } });
  const extractText = async (file: File) => {
    const lower = file.name.toLowerCase();
    if (file.type.startsWith("text/") || /\.(txt|md|csv|json)$/i.test(lower)) return file.text();
    if (/\.(xlsx|xls)$/i.test(lower)) { const workbook = XLSX.read(await file.arrayBuffer(), { type: "array" }); return workbook.SheetNames.map(name => `SHEET: ${name}\n${XLSX.utils.sheet_to_csv(workbook.Sheets[name])}`).join("\n\n"); }
    return "";
  };
  const uploadFile = async (file?: File) => {
    if (!file || uploadMutation.isPending) return;
    if (!isAdmin) { toast.error("Chỉ Admin được tải tài liệu vào kho CHATBOT."); return; }
    if (file.size > 15 * 1024 * 1024) { toast.error("Mỗi tài liệu tối đa 15 MB."); return; }
    setUploadProgress(10); setUploadStatus(`Đang đọc ${file.name}…`);
    try {
      const extractedText = await extractText(file); setUploadProgress(35); setUploadStatus("Đang lưu file vào kho bền vững…");
      const dataBase64 = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result).split(",")[1] ?? ""); reader.onerror = () => reject(new Error("Không đọc được file")); reader.readAsDataURL(file); });
      setUploadProgress(70); setUploadStatus(extractedText ? "Đang lập chỉ mục nội dung…" : "Đang lưu file; định dạng này chưa trích xuất được văn bản tự động…");
      uploadMutation.mutate({ name: file.name, mimeType: file.type || "application/octet-stream", sizeBytes: file.size, dataBase64, extractedText: extractedText || undefined });
    } catch (error) { setUploadProgress(0); setUploadStatus(error instanceof Error ? error.message : "Không xử lý được tài liệu"); toast.error("Không xử lý được tài liệu."); }
  };
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Array<{ role: "user" | "assistant"; content: string; sources?: Array<{ label: string; excerpt: string }> }>>([]);
  const [listening, setListening] = useState(false);
  const [autoRead, setAutoRead] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const recognitionRef = useRef<any>(null);
  const questionInputRef = useRef<HTMLTextAreaElement>(null);
  const askMutation = trpc.ai.ask.useMutation({
    onSuccess: result => { setMessages(old => [...old, { role: "assistant", content: result.answer, sources: result.sources }]); if (autoRead) speak(result.answer); },
    onError: error => { toast.error(error.message || "Không gọi được CHATBOT"); setMessages(old => [...old, { role: "assistant", content: "CHATBOT chưa thể kiểm chứng câu trả lời với tài liệu lúc này. Vui lòng thử lại; hệ thống không hiển thị câu trả lời chưa được đối chiếu với file." }]); },
  });
  const ask = (question: string) => {
    const trimmed = question.trim();
    if (!trimmed || askMutation.isPending) return;
    setMessages(old => [...old, { role: "user", content: trimmed }]);
    setInput("");
    askMutation.mutate({ question: trimmed, previousQuestions: messages.filter(message => message.role === "user").slice(-3).map(message => message.content) });
  };
  const startVoice = () => {
    const SpeechRecognition = (window as typeof window & { webkitSpeechRecognition?: new () => any }).webkitSpeechRecognition;
    if (!SpeechRecognition) { toast.error("Trình duyệt này chưa hỗ trợ nhận diện giọng nói tiếng Việt"); return; }
    if (listening) { recognitionRef.current?.stop(); setListening(false); return; }
    const recognition = new SpeechRecognition();
    recognition.lang = "vi-VN";
    recognition.interimResults = false;
    recognition.onresult = (event: any) => setInput((event.results?.[0]?.[0]?.transcript ?? "").trim());
    recognition.onerror = () => { setListening(false); toast.error("Không nhận diện được giọng nói, anh/chị thử lại nhé"); };
    recognition.onend = () => setListening(false);
    recognitionRef.current = recognition;
    recognition.start();
    setListening(true);
  };
  const speak = (text: string) => { if (!("speechSynthesis" in window)) { toast.error("Trình duyệt chưa hỗ trợ đọc câu trả lời"); return; } window.speechSynthesis.cancel(); const utterance = new SpeechSynthesisUtterance(text); const voice = window.speechSynthesis.getVoices().find(item => item.lang.toLowerCase().startsWith("vi")); if (voice) utterance.voice = voice; utterance.lang = "vi-VN"; utterance.rate = 0.95; utterance.onstart = () => setSpeaking(true); utterance.onend = () => setSpeaking(false); utterance.onerror = () => { setSpeaking(false); toast.error("TTS gặp lỗi, nội dung vẫn được giữ nguyên bằng văn bản."); }; window.speechSynthesis.speak(utterance); };
  const pauseSpeech = () => window.speechSynthesis?.pause();
  const resumeSpeech = () => window.speechSynthesis?.resume();
  const stopSpeech = () => { window.speechSynthesis?.cancel(); setSpeaking(false); };
  const returnToQuestion = () => {
    if (askMutation.isPending) return;
    stopSpeech();
    const recognition = recognitionRef.current;
    if (recognition) {
      recognition.onresult = null;
      recognition.onerror = null;
      recognition.onend = null;
      recognition.abort?.();
      recognitionRef.current = null;
    }
    setListening(false);
    setMessages([]);
    setInput("");
    askMutation.reset();
    window.requestAnimationFrame(() => {
      questionInputRef.current?.focus({ preventScroll: true });
      questionInputRef.current?.scrollIntoView({ behavior: getScrollBehavior(), block: "center" });
    });
  };
  return <section><PageTitle kicker="CHATBOT · TRỢ LÝ AI" title="Trợ lý AI chuyên ngành đường sắt Việt Nam" text="CHATBOT chỉ trả lời dựa trên nội dung các file Admin đã tải lên. Nếu file không có căn cứ, hệ thống sẽ thông báo rõ." /><div className="mt-6 rounded-2xl border border-[#c5e5df] bg-[#f7fcfb] p-4 sm:p-5"><div className="flex flex-wrap items-center justify-between gap-2"><div><div className="font-bold text-[#173f5f]">KHO TÀI LIỆU DÙNG CHO CÂU HỎI</div><div className="mt-1 text-xs text-slate-500">Mỗi câu hỏi tự tìm trong nội dung file đã lập chỉ mục. Hỗ trợ PDF có lớp chữ, văn bản và Excel; PDF scan cần OCR. Các định dạng khác vẫn được lưu nguyên bản.</div></div><FileText size={20} className="text-[#3caea3]" /></div>{isAdmin ? <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_320px]"><label onDragOver={event => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={event => { event.preventDefault(); setDragging(false); void uploadFile(event.dataTransfer.files?.[0]); }} className={`flex min-h-[125px] cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed p-5 text-center transition ${dragging ? "border-[#2d8a72] bg-[#e6f3f1]" : "border-slate-300 bg-white hover:border-[#3caea3]"}`}><UploadCloud size={28} className="text-[#2d8a72]" /><div className="mt-2 text-sm font-bold text-[#173f5f]">Kéo thả hoặc chọn file để lưu vào kho</div><div className="mt-1 text-xs text-slate-500">Mọi định dạng · tối đa 15 MB · chỉ Admin được tải</div><input type="file" className="hidden" accept="" onChange={event => { void uploadFile(event.target.files?.[0]); event.currentTarget.value = ""; }} /></label><div className="rounded-xl border border-slate-200 bg-white p-3"><div className="text-sm font-bold text-[#173f5f]">File đã lưu</div><div className="mt-2 max-h-48 space-y-2 overflow-auto">{documentsQuery.isLoading ? <div className="text-xs text-slate-500">Đang tải danh sách…</div> : (documentsQuery.data ?? []).length === 0 ? <div className="text-xs text-slate-500">Chưa có file trong kho.</div> : (documentsQuery.data ?? []).map(document => <div key={document.id} className="flex min-w-0 items-center gap-2 rounded-lg border border-slate-100 p-2 text-xs"><FileText size={15} className="shrink-0 text-[#2d8a72]" /><div className="min-w-0 flex-1"><div className="truncate font-medium text-slate-600" title={document.name}>{document.name}</div><div className="mt-1 text-[#17766e]">{document.processingStatus === "ready" ? "Có thể tìm kiếm" : document.processingStatus === "failed" ? "Lỗi đọc file" : "Chưa đọc được nội dung"}</div></div><ReadDocumentButton id={document.id} name={document.name} processingStatus={document.processingStatus} /><DeleteDocumentButton name={document.name} disabled={removeMutation.isPending} deleting={removeMutation.isPending && removeMutation.variables?.id === document.id} onDelete={() => removeMutation.mutateAsync({ id: document.id })} /></div>)}</div></div></div> : <div className="mt-4 space-y-3">
        <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">
          <b>Quyền tải file:</b> chỉ Admin được thêm hoặc quản lý tài liệu. Mọi người đều có thể xem và đọc nội dung file đã lưu.
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-3">
          <div className="flex items-center justify-between">
            <div className="text-sm font-bold text-[#173f5f]">File đã lưu</div>
            <FileText size={18} className="text-[#3caea3]" />
          </div>
          <div className="mt-2 max-h-64 space-y-2 overflow-auto">
            {documentsQuery.isLoading ? <div className="text-xs text-slate-500">Đang tải danh sách…</div>
              : documentsQuery.isError ? <div className="rounded-lg bg-red-50 p-3 text-xs text-red-700">Không tải được danh sách file. Vui lòng thử lại.</div>
              : (documentsQuery.data ?? []).length === 0 ? <div className="text-xs text-slate-500">Chưa có file trong kho.</div>
              : (documentsQuery.data ?? []).map(document => <div key={document.id} className="flex min-w-0 items-center gap-2 rounded-lg border border-slate-100 p-2 text-xs">
                <FileText size={15} className="shrink-0 text-[#2d8a72]" />
                <div className="min-w-0 flex-1">
                  <div className="truncate font-medium text-slate-600" title={document.name}>{document.name}</div>
                  <div className="mt-1 text-[#17766e]">{document.processingStatus === "ready" ? "Có thể tìm kiếm và đọc" : document.processingStatus === "failed" ? "Lỗi đọc file" : "Chưa đọc được nội dung"}</div>
                </div>
                <ReadDocumentButton id={document.id} name={document.name} processingStatus={document.processingStatus} />
              </div>)}
          </div>
        </div>
      </div>}{uploadStatus && <div className="mt-3 rounded-xl border border-slate-200 bg-white p-3 text-xs text-slate-600"><div className="flex justify-between"><span>{uploadStatus}</span><span>{uploadProgress}%</span></div><div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-[#2d8a72] transition-all" style={{ width: `${uploadProgress}%` }} /></div></div>}</div><div className="mt-6 overflow-hidden rounded-2xl border border-[#c5e5df] bg-white shadow-sm"><div className="flex items-center gap-3 border-b border-slate-100 bg-[#edf8f6] px-4 py-4 sm:px-6"><div className="grid size-11 place-items-center rounded-2xl bg-[#173f5f] text-white"><Sparkles size={22} /></div><div><div className="font-black text-[#173f5f]">CHATBOT</div><div className="text-xs text-slate-500">Trợ lý AI chuyên ngành Đường sắt Việt Nam</div></div></div><div className="min-h-[330px] space-y-4 p-4 sm:p-6">{messages.length === 0 ? <div className="grid min-h-[250px] place-items-center text-center"><div><WelcomeMedia defaultVideo="/manus-storage/nen-dep_154c8755.mp4" defaultPoster="/manus-storage/ai-dsqb-reference_28fdb57c.jpg" /><p className="mt-3 font-semibold text-[#173f5f]">Xin chào, tôi là CHATBOT</p></div></div> : messages.map((message, index) => <div key={`${message.role}-${index}`} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}><div className={`max-w-[92%] rounded-2xl px-4 py-3 text-sm leading-6 sm:max-w-[78%] ${message.role === "user" ? "bg-[#173f5f] text-white" : "bg-[#f1f5f7] text-slate-700"}`}>{message.role === "assistant" ? <Suspense fallback={<div className="whitespace-pre-wrap">{message.content}</div>}><ChatbotAnswer content={message.content} /></Suspense> : <div className="whitespace-pre-wrap">{message.content}</div>}{message.sources?.length ? <div className="mt-3 border-t border-slate-200 pt-3"><div className="text-xs font-bold uppercase tracking-wide text-[#17766e]">Căn cứ / nguồn truy hồi</div>{message.sources.map(source => <div key={source.label} className="mt-2 rounded-lg bg-white p-2 text-xs text-slate-600"><div className="font-semibold text-[#173f5f]">{source.label}</div><details className="mt-1"><summary className="cursor-pointer font-medium text-[#17766e]">Xem đầy đủ đoạn trích gốc</summary><div className="mt-2 max-h-72 overflow-auto whitespace-pre-wrap break-words rounded-md bg-slate-50 p-2 leading-6">{source.excerpt}</div></details></div>)}</div> : null}{message.role === "assistant" && <button onClick={() => speak(message.content)} className="mt-3 inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-2 py-1 text-xs text-[#173f5f]"><Volume2 size={13} /> Nghe câu trả lời</button>}</div></div>)}{askMutation.isPending && <div className="flex items-center gap-2 text-sm text-slate-500"><Sparkles className="animate-pulse text-[#3caea3]" size={17} /> CHATBOT đang tra cứu và tổng hợp...</div>}</div><div className="border-t border-slate-100 bg-slate-50 p-4 sm:p-6">{messages.length > 0 && <div className="mb-3"><button type="button" onClick={returnToQuestion} disabled={askMutation.isPending} title={askMutation.isPending ? "Vui lòng chờ CHATBOT trả lời xong" : "Trở về khung hỏi mới; giữ nguyên file đã lưu"} className="inline-flex min-h-11 items-center gap-2 rounded-xl border border-[#a8d4cc] bg-white px-4 py-2.5 text-sm font-semibold text-[#173f5f] transition hover:bg-[#e6f3f1] disabled:cursor-wait disabled:opacity-50"><ArrowLeft size={17} /> Trở về / Hỏi câu khác</button></div>}<div className="flex items-end gap-2"><textarea ref={questionInputRef} aria-label="Câu hỏi cho CHATBOT" value={input} onChange={event => setInput(event.target.value)} onKeyDown={event => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); ask(input); } }} rows={2} placeholder="Nhập câu hỏi cho CHATBOT..." className="min-w-0 flex-1 resize-none rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm outline-none focus:ring-2 focus:ring-[#3caea3]" /><button onClick={startVoice} className={`grid size-11 shrink-0 place-items-center rounded-xl text-white ${listening ? "bg-[#c94c4c]" : "bg-[#2d8a72]"}`} title={listening ? "Dừng nghe" : "Hỏi bằng giọng nói"}>{listening ? <Square size={17} /> : <Mic size={19} />}</button><button onClick={() => ask(input)} disabled={!input.trim() || askMutation.isPending} className="grid size-11 shrink-0 place-items-center rounded-xl bg-[#173f5f] text-white disabled:opacity-40" title="Gửi câu hỏi"><ArrowRight size={19} /></button></div><div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500"><span>Enter để gửi · Shift+Enter xuống dòng · Micro nhận tiếng Việt</span><div className="flex flex-wrap items-center gap-2"><label className="inline-flex items-center gap-1"><input type="checkbox" checked={autoRead} onChange={event => setAutoRead(event.target.checked)} /> Tự đọc</label><button onClick={() => { const last = [...messages].reverse().find(message => message.role === "assistant"); if (last) speak(last.content); }} className="inline-flex items-center gap-1 hover:text-[#173f5f]"><Play size={12} /> Phát</button><button onClick={pauseSpeech} className="inline-flex items-center gap-1 hover:text-[#173f5f]"><Pause size={12} /> Tạm dừng</button><button onClick={resumeSpeech} className="inline-flex items-center gap-1 hover:text-[#173f5f]"><Play size={12} /> Tiếp tục</button><button onClick={stopSpeech} className="inline-flex items-center gap-1 hover:text-[#173f5f]"><Square size={12} /> Dừng</button></div></div></div></div></section>;
}

function Overview({ count, onNavigate }: { count: number; onNavigate: (tab: Tab) => void }) { return <section><div className="text-sm font-semibold text-[#3caea3]">TRUNG TÂM ĐIỀU HÀNH</div><h1 className="mt-2 text-3xl font-black tracking-tight text-[#173f5f] md:text-4xl">Tính khối lượng trên web</h1><p className="mt-3 max-w-2xl leading-7 text-slate-500">Tra cứu tác nghiệp đường sắt Quảng Bình, lập nhật ký nhân công theo tháng và cập nhật dữ liệu đầu vào trực tiếp trên môi trường online.</p><div className="mt-8 grid gap-4 sm:grid-cols-3"><Stat icon={Database} label="Bản ghi đang dùng" value={`${count} bản ghi`} /><Stat icon={HardHat} label="Nhật ký" value="Theo ngày làm việc" /><Stat icon={RefreshCw} label="Cập nhật" value="Không cần cài lại" /></div><div className="mt-6 grid gap-5 md:grid-cols-2"><Action title="Tra cứu bóc khối lượng đường" text="Nạp file mới, tìm theo lý trình, xem hạng mục, nhân công, vật tư và xuất Excel." icon={FileSpreadsheet} onClick={() => onNavigate("lookup")} /><Action title="Lập nhật ký nhân công đường" text="Chia số người theo ngày, tự cân đối tổng tháng và phân công hạng mục từ trên xuống." icon={CalendarDays} onClick={() => onNavigate("labor")} /><Action title="Sơn cầu" text="Tính 3 công đoạn sơn cầu theo tỷ lệ 1 + 3 + 3 và lập lịch xử lý theo ngày." icon={HardHat} onClick={() => onNavigate("paint")} /><Action title="Trợ lý AI CHATBOT" text="Hỏi đáp dựa trên nội dung các file Admin đã tải lên, kèm nguồn đối chiếu." icon={Sparkles} onClick={() => onNavigate("ai")} /></div></section>; }
function Stat({ icon: Icon, label, value }: { icon: typeof BarChart3; label: string; value: string }) { return <div className="rail-stat flex items-center gap-4 rounded-2xl border border-slate-200 bg-white p-5"><div className="grid h-11 w-11 place-items-center rounded-xl bg-[#e6f3f1] text-[#17766e]"><Icon size={21} /></div><div><div className="text-xs font-bold uppercase tracking-wider text-slate-400">{label}</div><div className="mt-1 text-xl font-black text-[#173f5f]">{value}</div></div></div>; }
function Action({ title, text: description, icon: Icon, onClick }: { title: string; text: string; icon: typeof FileUp; onClick: () => void }) { return <button onClick={onClick} className="rail-action group rounded-2xl border border-slate-200 bg-white p-6 text-left transition hover:border-[#3caea3] hover:shadow-md"><div className="flex items-start justify-between"><div className="grid h-11 w-11 place-items-center rounded-xl bg-[#173f5f] text-white"><Icon size={20} /></div><ArrowRight className="text-slate-300 transition group-hover:text-[#3caea3]" /></div><h2 className="mt-5 text-lg font-bold text-[#173f5f]">{title}</h2><p className="mt-2 text-sm leading-6 text-slate-500">{description}</p></button>; }
function Lookup({ records, routeOptions, selected, setSelected, query, setQuery, kind, setKind, routeFilter, setRouteFilter, fileName, readWorkbook, exportSelected, exportingExcel }: { records: WorkRecord[]; routeOptions: string[]; selected: WorkRecord | null; setSelected: (record: WorkRecord) => void; query: string; setQuery: (value: string) => void; kind: string; setKind: (value: string) => void; routeFilter: string; setRouteFilter: (value: string) => void; fileName: string; readWorkbook: (file: File) => void; exportSelected: () => void; exportingExcel: boolean }) { return <section><PageTitle kicker="DỮ LIỆU ĐẦU VÀO" title="Tra cứu bóc khối lượng đường" text="Chọn file mới để thay toàn bộ dữ liệu trên web, sau đó tìm theo lý trình hoặc tên hạng mục." /><div className="mt-6 rounded-2xl border border-slate-200 bg-white p-5"><div className="flex flex-wrap items-center gap-3"><label className="inline-flex cursor-pointer items-center gap-2 rounded-xl bg-[#173f5f] px-4 py-2.5 font-semibold text-white hover:bg-[#102f48]"><FileUp size={17} /> Nạp file dữ liệu mới<input type="file" accept="*/*" className="hidden" onChange={event => { const file = event.target.files?.[0]; if (file) { void readWorkbook(file); event.currentTarget.value = ""; } }} /></label><div className="relative min-w-[240px] flex-1"><Search className="absolute left-3 top-3 text-slate-400" size={17} /><input value={query} onChange={event => setQuery(event.target.value)} placeholder="Tìm Km408, đường ngang, vật tư…" className="w-full rounded-xl border border-slate-200 py-2.5 pl-10 pr-4 outline-none focus:ring-2 focus:ring-[#3caea3]" /></div><select value={kind} onChange={event => setKind(event.target.value)} className="rounded-xl border border-slate-200 px-3 py-2.5 text-sm"><option value="">Tất cả loại</option>{kinds.map(item => <option key={item}>{item}</option>)}</select><select aria-label="Chọn Km hoặc đoạn công việc" value={routeFilter} onChange={event => setRouteFilter(event.target.value)} className="min-w-[210px] rounded-xl border border-[#b9d2de] bg-[#f8fbfc] px-3 py-2.5 text-sm font-semibold text-[#173f5f]"><option value="">Chọn Km / đoạn công việc</option>{routeOptions.map(route => <option key={route} value={route}>{route}</option>)}</select>{selected && <button onClick={exportSelected} disabled={exportingExcel} className="inline-flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-2.5 font-semibold text-slate-700 hover:bg-slate-50 disabled:cursor-wait disabled:opacity-50"><Download size={17} /> {exportingExcel ? "Đang xuất…" : "Xuất Excel theo mẫu"}</button>}</div><div className="mt-4 flex items-center gap-2 text-sm text-slate-500"><CheckCircle2 size={16} className="text-emerald-600" /> Đang dùng: <b className="text-slate-700">{fileName}</b> · {records.length} kết quả</div></div><div className="mt-5 grid gap-5 xl:grid-cols-[330px_1fr]"><div className="rail-record-list space-y-2" role="region" aria-label="Danh sách lý trình" tabIndex={0}>{records.slice(0, 200).map(record => <button key={record.id} onClick={() => setSelected(record)} className={`w-full rounded-xl border p-4 text-left transition ${selected?.id === record.id ? "border-[#3caea3] bg-[#e6f3f1]" : "border-slate-200 bg-white hover:border-[#3caea3]"}`}><div className="font-semibold text-[#173f5f]">{record.route}</div><div className="mt-1 text-xs text-slate-500">{record.kind} · {record.tasks.length} hạng mục · {record.materials.length} vật tư</div></button>)}{!records.length && <div className="rounded-xl border border-dashed border-slate-300 p-8 text-center text-sm text-slate-500">Không tìm thấy dữ liệu phù hợp.</div>}</div>{selected ? <RecordDetail record={selected} /> : <div className="grid min-h-[320px] place-items-center rounded-2xl border border-dashed border-slate-300 bg-white p-8 text-center text-slate-400"><div><FileSpreadsheet className="mx-auto" size={36} /><p className="mt-3">Chọn một đoạn ở danh sách bên trái để xem hạng mục và vật tư.</p></div></div>}</div></section>; }
function RecordDetail({ record }: { record: WorkRecord }) { return <div className="space-y-5"><div className="rounded-2xl border border-slate-200 bg-white p-5"><div className="text-xs font-bold uppercase tracking-wider text-[#3caea3]">{record.kind}</div><h2 className="mt-2 text-2xl font-black text-[#173f5f]">{record.route}</h2><div className="mt-5 grid gap-3 sm:grid-cols-2"><Mini label="Nhân công theo biểu" value={`${display(totalLabor(record))} công`} /><Mini label="Hạng mục / vật tư" value={`${record.tasks.length} / ${record.materials.length}`} /></div></div><TableCard title="1. HẠNG MỤC CÔNG VIỆC" headers={["STT", "Hạng mục", "Khối lượng", "Đơn vị", "Định mức", "Nhân công"]} rows={record.tasks.map((task, index) => [index + 1, task.name, display(task.qty), task.unit, task.rate == null ? "—" : display(task.rate, 4), task.labor == null ? "—" : display(task.labor)])} footer={["", "TỔNG NHÂN CÔNG", "", "", "", display(totalLabor(record))]} /><TableCard title="2. VẬT TƯ" headers={["STT", "Tên vật tư", "Số lượng", "Đơn vị"]} rows={record.materials.map((material, index) => [index + 1, material.name, display(material.qty), material.unit])} /></div>; }
function Mini({ label, value }: { label: string; value: string }) { return <div className="rounded-xl bg-[#f4f7f8] p-3"><div className="text-xs text-slate-500">{label}</div><div className="mt-1 font-bold text-[#173f5f]">{value}</div></div>; }
function TableCard({ title, headers, rows, footer }: { title: string; headers: string[]; rows: Array<Array<string | number>>; footer?: Array<string> }) { return <div className="rail-table-card overflow-auto rounded-2xl border border-slate-200 bg-white"><div className="border-b border-slate-100 px-5 py-4 font-bold text-[#173f5f]">{title}</div><table className="rail-table min-w-full text-sm"><thead className="bg-[#edf3f5] text-[#173f5f]"><tr>{headers.map(header => <th key={header} className="whitespace-nowrap px-4 py-3 text-left">{header}</th>)}</tr></thead><tbody>{rows.map((row, index) => <tr key={index} className="border-t border-slate-100">{row.map((cell, cellIndex) => <td key={cellIndex} className={`px-4 py-3 ${cellIndex > 1 ? "text-right" : ""}`}>{cell}</td>)}</tr>)}{footer && <tr className="border-t-2 border-[#3caea3] bg-[#fff8df] font-bold">{footer.map((cell, index) => <td key={index} className={`px-4 py-3 ${index > 1 ? "text-right" : ""}`}>{cell}</td>)}</tr>}</tbody></table>{!rows.length && <div className="p-6 text-center text-sm text-slate-400">Không có dữ liệu.</div>}</div>; }
function LaborPlanner({ records, selected, setSelected }: { records: WorkRecord[]; selected: WorkRecord | null; setSelected: (record: WorkRecord) => void }) { const [month, setMonth] = useState(currentMonthValue()); const [people, setPeople] = useState(100); const [manual, setManual] = useState<ManualPeople>({}); const record = selected ?? records[0] ?? null; const dates = workingDates(month); const monthlyLabor = totalLabor(record); const balanced = useMemo(() => buildBalancedPeople(dates, people, manual), [dates, people, manual]); const totalMonthlyWork = Object.values(balanced).reduce((sum, value) => sum + value, 0); const perPersonMonth = people > 0 ? monthlyLabor / people : 0; const detail = useMemo(() => { const remaining = (record?.tasks ?? []).map(task => Math.max(0, numberValue(task.labor))); const result: Array<Array<string | number>> = []; dates.forEach(date => { const key = dateKey(date); let capacity = (balanced[key] ?? 0) * perPersonMonth; for (let index = 0; index < (record?.tasks.length ?? 0) && capacity > 0.0000001; index++) { const task = record!.tasks[index]; const take = Math.min(capacity, remaining[index]); if (take <= 0.0000001) continue; const taskQty = numberValue(task.qty); const taskLabor = numberValue(task.labor); const workQty = taskLabor > 0 ? (taskQty / taskLabor) * take : 0; result.push([dateLabel(date), task.name, display(workQty) + (task.unit ? ` ${task.unit}` : ""), display(take) + " công", display(balanced[key] ?? 0), index + 1, display(take) + " công", display(remaining[index]) + " công"]); remaining[index] -= take; capacity -= take; } } ); return result; }, [record, dates, balanced, perPersonMonth]); if (!record) return <EmptyState text="Hãy nạp dữ liệu hoặc chọn một bản ghi ở menu Tra cứu trước." />; const setDay = (date: Date, value: number) => setManual(old => ({ ...old, [dateKey(date)]: Math.max(0, value) })); return <section><PageTitle kicker="NHẬT KÝ SẢN LƯỢNG" title="Nhân công đường theo tháng" text="Tổng công ngày được cân đối theo số người trong tháng; có thể sửa số người từng ngày theo thực tế." /><div className="mt-6 grid gap-4 rounded-2xl border border-slate-200 bg-white p-5 md:grid-cols-5"><Field label="Hạng mục/đoạn công việc"><select value={record.id} onChange={event => { const next = records.find(item => item.id === event.target.value); if (next) { setSelected(next); setManual({}); } }}><option value="">Chọn hạng mục/đoạn</option>{records.map(item => <option key={item.id} value={item.id}>{item.route} — {item.kind}</option>)}</select></Field><Field label="Tháng/năm"><input type="month" value={month} onChange={event => { setMonth(event.target.value); setManual({}); }} /></Field><Field label="Số người trong tháng"><input type="number" min="1" step="1" value={people} onChange={event => setPeople(Math.max(1, Number(event.target.value) || 1))} /></Field><div className="rounded-xl bg-[#e6f3f1] p-3 text-sm"><div className="text-slate-500">Khối lượng/người/tháng</div><div className="mt-1 text-xl font-black text-[#173f5f]">{display(perPersonMonth)} c</div></div><div className="rounded-xl bg-[#fff8df] p-3 text-sm"><div className="text-slate-500">Tổng số công trong tháng</div><div className="mt-1 text-xl font-black text-[#9a6500]">{display(totalMonthlyWork, 2)} công</div></div></div><div className="mt-4 rounded-xl border border-[#c5e5df] bg-[#e6f3f1] p-3 text-sm text-[#17766e]">{record.route} · {dates.length} ngày làm việc, đã loại Chủ nhật · KL tổng ngày = Tổng công trong ngày × Khối lượng/người/tháng. Sửa một ngày thì các ngày chưa sửa tự cân đối phần còn lại.</div><div className="mt-5 overflow-auto rounded-2xl border border-slate-200 bg-white"><div className="px-5 py-4 font-bold text-[#173f5f]">NHẬT KÝ LÀM VIỆC HÀNG NGÀY</div><table className="rail-table min-w-full text-sm"><thead className="bg-[#edf3f5]"><tr>{["Ngày", "Số người phân bổ/ngày", "Tổng công trong ngày", "KL tổng ngày"].map(header => <th key={header} className="px-4 py-3 text-left">{header}</th>)}</tr></thead><tbody>{dates.map(date => { const key = dateKey(date); const dailyPeople = balanced[key] ?? 0; const dailyQty = dailyPeople * perPersonMonth; return <tr key={key} className="border-t border-slate-100"><td className="px-4 py-3">{dateLabel(date)}</td><td className="px-4 py-3"><input className="w-28 rounded-lg border border-slate-200 px-2 py-1.5 text-right" type="number" min="0" step="0.1" value={Number(dailyPeople.toFixed(1))} onChange={event => setDay(date, Number(event.target.value) || 0)} /></td><td className="px-4 py-3 text-right font-semibold">{display(dailyPeople)} công</td><td className="px-4 py-3 text-right font-semibold">{display(dailyQty)} c</td></tr>; })}<tr className="border-t-2 border-[#3caea3] bg-[#fff8df] font-bold"><td className="px-4 py-3">TỔNG</td><td className="px-4 py-3 text-right">{display(totalMonthlyWork, 2)}</td><td className="px-4 py-3 text-right">{display(totalMonthlyWork, 2)} công</td><td className="px-4 py-3 text-right">{display(totalMonthlyWork * perPersonMonth)} c</td></tr></tbody></table></div><div className="mt-5"><TableCard title="CHI TIẾT CÔNG LÀM CÔNG VIỆC GÌ — PHÂN THEO THỨ TỰ TỪ TRÊN XUỐNG" headers={["Ngày", "Hạng mục công việc cụ thể", "Khối lượng", "Khối lượng làm hàng ngày (theo Nhân công tra cứu)", "Tổng công ngày", "Thứ tự", "Công phân bổ", "Công còn trước ngày"]} rows={detail} /></div></section>; }

function paintDates(month: string, weekdays: boolean[], overrides: Record<string, boolean>) {
  const [year, monthNumber] = month.split("-").map(Number);
  if (!year || !monthNumber) return [] as Array<{ date: Date; key: string; working: boolean }>;
  const last = new Date(year, monthNumber, 0).getDate();
  return Array.from({ length: last }, (_, index) => {
    const date = new Date(year, monthNumber - 1, index + 1);
    const key = dateKey(date);
    const mondayIndex = (date.getDay() + 6) % 7;
    return { date, key, working: overrides[key] ?? weekdays[mondayIndex] ?? false };
  });
}
function PaintPlanner() {
  const [area, setArea] = useState(0);
  const [month, setMonth] = useState(currentMonthValue());
  const [crew, setCrew] = useState(0);
  const [antiRustPaint, setAntiRustPaint] = useState(0);
  const [topcoatPaint, setTopcoatPaint] = useState(0);
  const [weekdays, setWeekdays] = useState([true, true, true, true, true, true, false]);
  const [dayOverrides, setDayOverrides] = useState<Record<string, boolean>>({});
  const [manualCrew, setManualCrew] = useState<Record<string, number>>({});
  const [manualSurface, setManualSurface] = useState<Record<string, number>>({});
  const [parts, setParts] = useState({ surface: 3, coat1: 1, coat2: 1 });
  const days = paintDates(month, weekdays, dayOverrides);
  const calendarLead = days.length ? (days[0].date.getDay() + 6) % 7 : 0;
  const working = days.filter(day => day.working);
  const crewByDay = useMemo(() => buildBalancedPeople(working.map(day => day.date), crew, manualCrew), [working, crew, manualCrew]);
  const antiRustDays = Math.max(1, Math.round(parts.surface));
  const baseDays = working.slice(0, Math.max(0, working.length - antiRustDays - 1));
  const baseArea = buildBalancedTotal(baseDays.map(day => day.date), area, manualSurface);
  const rows = days.map(day => {
    const workIndex = working.findIndex(item => item.key === day.key);
    const surface = day.working && baseArea[day.key] !== undefined ? Math.max(0, baseArea[day.key]) : 0;
    const coat1Source = workIndex >= antiRustDays ? working[workIndex - antiRustDays] : undefined;
    const coat2Source = workIndex >= antiRustDays + 1 ? working[workIndex - antiRustDays - 1] : undefined;
    const coat1 = coat1Source ? baseArea[coat1Source.key] ?? 0 : 0;
    const coat2 = coat2Source ? baseArea[coat2Source.key] ?? 0 : 0;
    const total = surface + coat1 + coat2;
    const people = day.working ? crewByDay[day.key] ?? 0 : 0;
    const antiRustKg = area > 0 ? (antiRustPaint / area) * surface : 0;
    const topcoatKg = area > 0 ? (topcoatPaint / (area * 2)) * (coat1 + coat2) : 0;
    return { ...day, people, surface, coat1, coat2, total, antiRustKg, topcoatKg };
  });
  const required = { surface: area, coat1: area, coat2: area };
  const planned = { surface: rows.reduce((sum, row) => sum + row.surface, 0), coat1: rows.reduce((sum, row) => sum + row.coat1, 0), coat2: rows.reduce((sum, row) => sum + row.coat2, 0) };
  const scheduleTotals = {
    people: rows.reduce((sum, row) => sum + row.people, 0),
    surface: planned.surface,
    coat1: planned.coat1,
    coat2: planned.coat2,
    antiRustKg: rows.reduce((sum, row) => sum + row.antiRustKg, 0),
    topcoatKg: rows.reduce((sum, row) => sum + row.topcoatKg, 0),
  };
  const setManual = (setter: React.Dispatch<React.SetStateAction<Record<string, number>>>, key: string, value: string) => setter(old => ({ ...old, [key]: Math.max(0, Number(value) || 0) }));
  return <section className="paint-planner"><PageTitle kicker="ĐIỀU ĐỘ THI CÔNG" title="Tính khối lượng & lập tiến độ sơn cầu" />
    <div className="paint-input-grid mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-6"><Field label="Diện tích sơn gốc (m²)"><input type="number" min="0" step="0.01" value={area || ""} placeholder="Nhập diện tích" onChange={event => setArea(Math.max(0, Number(event.target.value) || 0))} /></Field><Field label="Tháng lập kế hoạch"><input type="month" value={month} onChange={event => { setMonth(event.target.value); setManualCrew({}); setManualSurface({}); setDayOverrides({}); }} /></Field><Field label="Tổng số người trong tháng"><input type="number" min="0" step="1" value={crew || ""} placeholder="Ví dụ: 10" onChange={event => setCrew(Math.max(0, Number(event.target.value) || 0))} /></Field><Field label="Khối lượng sơn chống rỉ (kg)"><input type="number" min="0" step="0.01" value={antiRustPaint || ""} placeholder="Nhập tổng kg" onChange={event => setAntiRustPaint(Math.max(0, Number(event.target.value) || 0))} /></Field><Field label="Khối lượng sơn phủ (kg)"><input type="number" min="0" step="0.01" value={topcoatPaint || ""} placeholder="Nhập tổng kg" onChange={event => setTopcoatPaint(Math.max(0, Number(event.target.value) || 0))} /></Field></div>
    <div className="mt-3 grid gap-2 md:grid-cols-3"><Mini label="Ngày bắt đầu phủ 1" value={working[antiRustDays] ? dateLabel(working[antiRustDays].date) : `Chưa đủ ${antiRustDays + 1} ngày làm`} /><Mini label="Ngày bắt đầu phủ 2" value={working[antiRustDays + 1] ? dateLabel(working[antiRustDays + 1].date) : `Chưa đủ ${antiRustDays + 2} ngày làm`} /><Mini label="Phủ 2 đã xếp lịch" value={`${display(planned.coat2)} / ${display(required.coat2)} m²`} /></div>
    <div className="mt-3 space-y-3"><div className="grid gap-3 md:grid-cols-2"><div className="rounded-xl border border-slate-200 bg-white p-3 sm:p-4"><div className="font-bold text-[#173f5f]">Số ngày theo công đoạn</div><p className="mt-2 text-sm text-slate-500">Mặc định: chống rỉ 3 ngày, phủ 1 một ngày, phủ 2 một ngày.</p><div className="mt-3 grid gap-2 sm:grid-cols-3"><Field label="Gõ, cạo, chải rỉ + chống rỉ (ngày)"><input type="number" min="0" step="0.1" value={parts.surface} onChange={event => setParts(old => ({ ...old, surface: Math.max(0, Number(event.target.value) || 0) }))} /></Field><Field label="Sơn phủ 1 (ngày)"><input type="number" min="0" step="0.1" value={parts.coat1} onChange={event => setParts(old => ({ ...old, coat1: Math.max(0, Number(event.target.value) || 0) }))} /></Field><Field label="Sơn phủ 2 (ngày)"><input type="number" min="0" step="0.1" value={parts.coat2} onChange={event => setParts(old => ({ ...old, coat2: Math.max(0, Number(event.target.value) || 0) }))} /></Field></div></div><div className="rounded-xl border border-slate-200 bg-white p-3 sm:p-4"><div className="font-bold text-[#173f5f]">Ngày làm việc thường lệ</div><div className="mt-3 grid grid-cols-7 gap-1">{["T2","T3","T4","T5","T6","T7","CN"].map((label, index) => <button key={label} onClick={() => setWeekdays(old => old.map((value, i) => i === index ? !value : value))} className={`rounded-lg px-2 py-2 text-xs font-bold ${weekdays[index] ? "bg-[#e6f3f1] text-[#17766e]" : "bg-slate-100 text-slate-400"}`}>{label}</button>)}</div><p className="mt-3 text-xs text-slate-500">Có thể bấm từng ngày trong lịch để đổi riêng ngày làm/nghỉ.</p></div></div>
      <div className="min-w-0 overflow-hidden rounded-2xl border border-slate-200 bg-white"><div className="border-b border-slate-100 px-3 py-3 text-sm font-bold text-[#173f5f] sm:px-4">LỊCH CÔNG VIỆC TRONG THÁNG</div><div className="min-w-0 w-full p-2.5 sm:p-3"><div className="grid w-full grid-cols-7 gap-1"><div className="col-span-7 grid grid-cols-7 gap-1 text-center text-[10px] font-bold text-slate-400 sm:text-xs">{["T2", "T3", "T4", "T5", "T6", "T7", "CN"].map(label => <div key={label} className={label === "CN" ? "text-red-400" : ""}>{label}</div>)}</div>{Array.from({ length: calendarLead }, (_, index) => <div key={`empty-${index}`} aria-hidden="true" />)}{rows.map(day => <button key={day.key} onClick={() => setDayOverrides(old => ({ ...old, [day.key]: !day.working }))} className={`flex min-w-0 flex-col items-center justify-center gap-0.5 rounded-md border p-1 text-center text-[10px] sm:flex-row sm:gap-1 sm:p-1.5 sm:text-xs ${day.working ? "border-[#c5e5df] bg-[#e6f3f1] text-[#17766e]" : "border-slate-200 bg-slate-100 text-slate-400"}`}><div className="font-black">{day.date.getDate()}</div><div>{day.working ? "Làm" : "Nghỉ"}</div></button>)}</div><p className="mt-3 rounded-lg border border-[#c5e5df] bg-[#e6f3f1] p-2.5 text-xs leading-5 text-[#17766e]">Khối lượng chống rỉ được chia đều trên các ngày làm việc đủ điều kiện trong tháng. Mỗi lô được chuyển sang phủ 1 sau 3 ngày làm việc và phủ 2 sau thêm 1 ngày làm việc; Chủ nhật không tính.</p><div className="mt-3">
        <div className="grid gap-2 sm:grid-cols-2 lg:hidden">{rows.map(day => <div key={day.key} className="rounded-xl border border-slate-200 bg-white p-3"><div className="flex items-center justify-between"><span className="font-semibold text-[#173f5f]">{dateLabel(day.date)}</span><span className={`rounded-full px-2 py-1 text-xs font-semibold ${day.working ? "bg-[#e6f3f1] text-[#17766e]" : "bg-slate-100 text-slate-400"}`}>{day.working ? "Làm việc" : "Nghỉ"}</span></div><div className="mt-2 grid grid-cols-2 gap-1.5 text-xs"><div className="rounded-lg bg-slate-50 p-2"><div className="text-slate-500">Số người</div><div className="mt-1 font-bold">{day.working ? <input className="w-full rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-right" type="number" min="0" step="0.1" value={Number((manualCrew[day.key] ?? day.people).toFixed(2))} onChange={event => setManual(setManualCrew, day.key, event.target.value)} /> : "—"}</div></div><div className="rounded-lg bg-slate-50 p-2"><div className="text-slate-500">Xử lý rỉ + chống rỉ</div><div className="mt-1 font-bold">{day.working && day.surface > 0 ? <input className="w-full rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-right" type="number" min="0" step="0.01" value={Number((day.surface).toFixed(2))} onChange={event => setManual(setManualSurface, day.key, event.target.value)} /> : "—"}</div></div><div className="rounded-lg bg-[#edf3f5] p-2"><div className="text-slate-500">Sơn phủ 1 · ngày thứ 4</div><div className="mt-1 text-right font-bold text-[#173f5f]">{day.coat1 ? display(day.coat1) : "—"} m²</div></div><div className="rounded-lg border border-[#f0c36a] bg-[#fff8df] p-2"><div className="text-slate-500">Sơn phủ 2 · ngày thứ 5</div><div className="mt-1 text-right font-black text-[#9a6500]">{day.coat2 ? display(day.coat2) : "—"} m²</div></div></div><div className="rounded-lg border border-[#c5e5df] bg-[#f7fcfb] p-2"><div className="text-slate-500">Sơn chống rỉ (kg)</div><div className="mt-1 text-right font-bold">{day.antiRustKg > 0 ? display(day.antiRustKg, 2) : "—"}</div></div><div className="rounded-lg border border-[#f0c36a] bg-[#fff8df] p-2"><div className="text-slate-500">Sơn phủ (kg)</div><div className="mt-1 text-right font-bold text-[#9a6500]">{day.topcoatKg > 0 ? display(day.topcoatKg, 2) : "—"}</div></div><div className="mt-2 flex justify-end border-t border-slate-100 pt-2 text-xs"><span>Tổng ngày: <b>{day.total ? display(day.total) : "—"} m²</b></span></div></div>)}</div>
        <div className="hidden w-full min-w-0 overflow-x-auto lg:block"><table className="rail-table paint-schedule-table w-full table-fixed text-xs"><colgroup><col style={{ width: "17%" }} /><col style={{ width: "10%" }} /><col style={{ width: "17%" }} /><col style={{ width: "16%" }} /><col style={{ width: "16%" }} /><col style={{ width: "12%" }} /><col style={{ width: "12%" }} /></colgroup><thead className="bg-[#edf3f5]"><tr>{["Ngày","Số người","Xử lý rỉ + chống rỉ","Sơn phủ 1 (ngày thứ 4)","Sơn phủ 2 (ngày thứ 5)","Sơn chống rỉ (kg)","Sơn phủ (kg)"].map(header => <th key={header} className="px-2 py-2 text-left">{header}</th>)}</tr></thead><tbody>{rows.map(day => <tr key={day.key} className="border-t border-slate-100"><td className="px-2 py-2">{dateLabel(day.date)}</td><td className="px-2 py-1.5">{day.working ? <input className="w-full min-w-0 rounded-md border border-slate-200 px-1.5 py-1 text-right" type="number" min="0" step="0.1" value={Number((manualCrew[day.key] ?? day.people).toFixed(2))} onChange={event => setManual(setManualCrew, day.key, event.target.value)} /> : "—"}</td><td className="px-2 py-1.5">{day.working && day.surface > 0 ? <input className="w-full min-w-0 rounded-md border border-slate-200 px-1.5 py-1 text-right" type="number" min="0" step="0.01" value={Number((day.surface).toFixed(2))} onChange={event => setManual(setManualSurface, day.key, event.target.value)} /> : "—"}</td><td className="px-2 py-2 text-right">{day.coat1 ? display(day.coat1) : "—"}</td><td className="bg-[#fff8df] px-2 py-2 text-right font-black text-[#9a6500]">{day.coat2 ? display(day.coat2) : "—"}</td><td className="bg-[#f7fcfb] px-2 py-2 text-right font-semibold">{day.antiRustKg > 0 ? display(day.antiRustKg, 2) : "—"}</td><td className="bg-[#fff8df] px-2 py-2 text-right font-semibold text-[#9a6500]">{day.topcoatKg > 0 ? display(day.topcoatKg, 2) : "—"}</td></tr>)}</tbody><tfoot><tr className="border-t-2 border-[#3caea3] bg-[#f7fcfb] font-black text-[#173f5f]"><td className="px-2 py-2">TỔNG</td><td className="px-2 py-2 text-right">{display(scheduleTotals.people, 2)}</td><td className="px-2 py-2 text-right">{display(scheduleTotals.surface, 2)}</td><td className="px-2 py-2 text-right">{display(scheduleTotals.coat1, 2)}</td><td className="bg-[#fff8df] px-2 py-2 text-right text-[#9a6500]">{display(scheduleTotals.coat2, 2)}</td><td className="bg-[#f7fcfb] px-2 py-2 text-right">{display(scheduleTotals.antiRustKg, 2)}</td><td className="bg-[#fff8df] px-2 py-2 text-right text-[#9a6500]">{display(scheduleTotals.topcoatKg, 2)}</td></tr></tfoot></table></div></div></div></div></div>
  </section>;
}
function Field({ label, children }: { label: string; children: React.ReactNode }) { return <label className="text-sm font-semibold text-slate-700"><span className="mb-2 block">{label}</span><span className="block [&_input]:w-full [&_input]:rounded-xl [&_input]:border [&_input]:border-slate-200 [&_input]:px-3 [&_input]:py-2.5 [&_input]:outline-none [&_input]:focus:ring-2 [&_input]:focus:ring-[#3caea3] [&_select]:w-full [&_select]:rounded-xl [&_select]:border [&_select]:border-slate-200 [&_select]:bg-white [&_select]:px-3 [&_select]:py-2.5">{children}</span></label>; }
function PageTitle({ kicker, title, text: description }: { kicker: string; title: string; text?: string }) { return <div><div className="text-xs font-bold uppercase tracking-[0.2em] text-[#3caea3]">{kicker}</div><h1 className="mt-2 text-3xl font-black text-[#173f5f]">{title}</h1>{description ? <p className="mt-2 text-slate-500">{description}</p> : null}</div>; }
function BridgePlaceholder({ kicker, title, text }: { kicker: string; title: string; text: string }) { return <section><PageTitle kicker={kicker} title={title} text={text} /><div className="mt-6 grid min-h-[360px] place-items-center rounded-2xl border border-dashed border-[#9acfc8] bg-gradient-to-br from-[#f5fbfa] to-white p-8 text-center"><div className="max-w-xl"><div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-[#e6f3f1] text-[#17766e]"><HardHat size={30} /></div><h2 className="mt-5 text-xl font-black text-[#173f5f]">Khu vực đang chờ nội dung nghiệp vụ</h2><p className="mt-2 leading-7 text-slate-500">{text}</p><div className="mt-5 inline-flex items-center rounded-full bg-[#fff8df] px-4 py-2 text-sm font-semibold text-[#9a6500]">Sẽ cập nhật theo dữ liệu cầu do Admin cung cấp</div></div></div></section>; }
function EmptyState({ text: message }: { text: string }) { return <div className="grid min-h-[50vh] place-items-center rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center text-slate-500"><div><Database className="mx-auto text-slate-300" size={38} /><p className="mt-3">{message}</p></div></div>; }

import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  CURVE_EXAMPLES,
  calculateCircularElements,
  calculateCurve,
  formatChainage,
  type CurveInput,
  type CurveResult,
  validateCurveInput,
  versineAt,
} from "@/lib/curveCalculations";
import { downloadCurveWorkbook, readCurveWorkbook } from "@/lib/curveWorkbook";
import {
  readCurveDraft,
  saveCurveDraft,
  type CurveDraft,
} from "@/lib/curveDraft";

type CurveMode = "circular" | "transition";
type FormState = CurveDraft["form"];
type CircularForm = CurveDraft["circularForm"];
type PendingSheets = Awaited<ReturnType<typeof readCurveWorkbook>>;

type CircularResult = ReturnType<typeof calculateCircularElements>;

const firstExample = CURVE_EXAMPLES[0];
const emptyForm: FormState = {
  name: "",
  radius: "",
  transitionIn: "",
  transitionOut: "",
  length: "",
  chord: "",
  startChainage: "",
  sampleOffset: "",
};
const defaultCircular: CircularForm = {
  radius: "100",
  degrees: "16",
  minutes: "46",
  seconds: "23",
};

function numberText(value: number, digits = 3, fixed = false) {
  if (!Number.isFinite(value)) return "—";
  return value.toLocaleString("vi-VN", {
    minimumFractionDigits: fixed ? digits : 0,
    maximumFractionDigits: digits,
  });
}

function parseNumber(value: string) {
  const trimmed = value.trim();
  if (!trimmed) return Number.NaN;
  return Number(trimmed.replace(/\s/g, "").replace(",", "."));
}

function formFromInput(name: string, input: CurveInput): FormState {
  const asText = (value: number) => String(value).replace(".", ",");
  return {
    name,
    radius: asText(input.radius),
    transitionIn: asText(input.transitionIn),
    transitionOut: asText(input.transitionOut),
    length: asText(input.length),
    chord: asText(input.chord),
    startChainage: asText(input.startChainage),
    sampleOffset: asText(input.sampleOffset),
  };
}

function parseCurveForm(form: FormState, mode: CurveMode): CurveInput {
  return {
    radius: parseNumber(form.radius),
    transitionIn: mode === "circular" ? 0 : parseNumber(form.transitionIn),
    transitionOut: mode === "circular" ? 0 : parseNumber(form.transitionOut),
    length: parseNumber(form.length),
    chord: parseNumber(form.chord),
    startChainage: parseNumber(form.startChainage),
    sampleOffset: parseNumber(form.sampleOffset),
  };
}

function displayInputValue(value: number) {
  return Number.isFinite(value) ? String(value).replace(".", ",") : "";
}

function chartRows(result: CurveResult) {
  const rows = result.rows;
  if (rows.length <= 1000) return rows;
  const stride = (rows.length - 1) / 999;
  return Array.from(
    { length: 1000 },
    (_, index) => rows[Math.round(index * stride)]
  );
}

function curveErrors(input: CurveInput) {
  try {
    return validateCurveInput(input);
  } catch (error) {
    return [
      error instanceof Error
        ? error.message
        : "Số liệu đường cong chưa hợp lệ.",
    ];
  }
}

function Field({
  id,
  label,
  value,
  onChange,
  suffix,
  hint,
  disabled = false,
  type = "text",
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  suffix?: string;
  hint?: string;
  disabled?: boolean;
  type?: React.HTMLInputTypeAttribute;
}) {
  return (
    <label
      htmlFor={id}
      className="block min-w-0 text-sm font-semibold text-slate-700"
    >
      <span className="mb-1.5 block leading-5">{label}</span>
      <span className="relative block">
        <input
          id={id}
          type={type}
          value={value}
          disabled={disabled}
          onChange={event => onChange(event.target.value)}
          className={`h-9 w-full min-w-0 rounded-lg border border-slate-200 bg-white px-3 text-right font-normal text-slate-800 outline-none transition focus:border-[#3caea3] focus:ring-2 focus:ring-[#3caea3]/25 disabled:bg-slate-100 disabled:text-slate-400 ${suffix ? "pr-12" : ""}`}
          inputMode={
            id === "curve-name"
              ? "text"
              : type === "text"
                ? "decimal"
                : undefined
          }
        />
        {suffix && (
          <span className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-xs font-normal text-slate-400">
            {suffix}
          </span>
        )}
      </span>
      {hint && (
        <span className="mt-1 block text-[11px] font-normal leading-4 text-slate-400">
          {hint}
        </span>
      )}
    </label>
  );
}

function Metric({
  label,
  value,
  suffix,
}: {
  label: string;
  value: React.ReactNode;
  suffix?: string;
}) {
  return (
    <div className="rounded-xl border border-[#c5e5df] bg-[#e6f3f1] p-3">
      <div className="text-[11px] font-semibold uppercase tracking-wide text-[#17766e]">
        {label}
      </div>
      <div className="mt-1 tabular-nums text-lg font-black text-[#173f5f]">
        {value}
        {suffix && (
          <span className="ml-1 text-xs font-semibold text-slate-500">
            {suffix}
          </span>
        )}
      </div>
    </div>
  );
}

function ErrorBox({ errors }: { errors: string[] }) {
  if (!errors.length) return null;
  return (
    <div
      role="alert"
      className="rounded-xl border border-red-200 bg-red-50 px-3 py-2.5 text-sm leading-6 text-red-800"
    >
      <div className="font-bold">Chưa thể tính đường cong</div>
      <ul className="ml-5 list-disc">
        {errors.map(error => (
          <li key={error}>{error}</li>
        ))}
      </ul>
    </div>
  );
}

export function CurveCalculator() {
  const [initialDraft] = useState(readCurveDraft);
  const [mode, setMode] = useState<CurveMode>(
    initialDraft?.mode ?? "transition"
  );
  const [form, setForm] = useState<FormState>(
    () =>
      initialDraft?.form ?? formFromInput(firstExample.name, firstExample.input)
  );
  const [sourceBanner, setSourceBanner] = useState(
    initialDraft?.sourceBanner ||
      (initialDraft
        ? "Đã khôi phục số liệu Đường cong trên trình duyệt này."
        : `Đang hiển thị mẫu từ file đã gửi: ${firstExample.name}. Hãy thay bằng số liệu đường cong cần tính.`)
  );
  const [pendingSheets, setPendingSheets] = useState<PendingSheets>([]);
  const [importState, setImportState] = useState("");
  const [exporting, setExporting] = useState(false);
  const [circularForm, setCircularForm] = useState<CircularForm>(
    initialDraft?.circularForm ?? defaultCircular
  );
  const [position, setPosition] = useState(initialDraft?.position ?? "");
  const [includeCircular, setIncludeCircular] = useState(
    initialDraft?.includeCircular ?? false
  );
  const [positionMessage, setPositionMessage] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const importVersionRef = useRef(0);

  useEffect(() => {
    saveCurveDraft({
      mode,
      form,
      circularForm,
      position,
      sourceBanner,
      includeCircular,
    });
  }, [mode, form, circularForm, position, sourceBanner, includeCircular]);

  useEffect(() => {
    setPositionMessage("");
  }, [form, mode]);

  const parsed = useMemo(() => {
    const input = parseCurveForm(form, mode);
    const errors = curveErrors(input);
    if (errors.length)
      return { input, errors, result: null as CurveResult | null };
    try {
      return { input, errors: [] as string[], result: calculateCurve(input) };
    } catch (error) {
      return {
        input,
        errors: [
          error instanceof Error
            ? error.message
            : "Không tính được đường cong.",
        ],
        result: null as CurveResult | null,
      };
    }
  }, [form, mode]);
  const result = parsed.result;
  const chartData = useMemo(
    () =>
      result
        ? chartRows(result).map(row => ({ x: row.distance, f: row.f }))
        : [],
    [result]
  );

  const circular = useMemo(() => {
    const values = {
      radius: parseNumber(circularForm.radius),
      degrees: parseNumber(circularForm.degrees),
      minutes: parseNumber(circularForm.minutes),
      seconds: parseNumber(circularForm.seconds),
    };
    if (!Object.values(values).every(Number.isFinite)) {
      return {
        result: null as CircularResult | null,
        errors: ["Nhập đầy đủ bán kính và góc độ/phút/giây."],
      };
    }
    try {
      return {
        result: calculateCircularElements(
          values.radius,
          values.degrees,
          values.minutes,
          values.seconds
        ),
        errors: [] as string[],
      };
    } catch (error) {
      return {
        result: null as CircularResult | null,
        errors: [
          error instanceof Error ? error.message : "Góc tròn chưa hợp lệ.",
        ],
      };
    }
  }, [circularForm]);

  const updateForm = (key: keyof FormState, value: string) => {
    importVersionRef.current += 1;
    setImportState("");
    setForm(old => ({ ...old, [key]: value }));
    setPendingSheets([]);
    setSourceBanner("");
  };

  const selectMode = (nextMode: CurveMode) => {
    importVersionRef.current += 1;
    setImportState("");
    setMode(nextMode);
    setPendingSheets([]);
    setForm(old => ({
      ...old,
      transitionIn: nextMode === "circular" ? "0" : old.transitionIn || "0",
      transitionOut: nextMode === "circular" ? "0" : old.transitionOut || "0",
    }));
    setSourceBanner("");
  };

  const loadInput = (name: string, input: CurveInput, message: string) => {
    importVersionRef.current += 1;
    setImportState("");
    setMode(
      input.transitionIn === 0 && input.transitionOut === 0
        ? "circular"
        : "transition"
    );
    setForm(formFromInput(name, input));
    setSourceBanner(message);
    setPendingSheets([]);
  };

  const resetForm = () => {
    importVersionRef.current += 1;
    setImportState("");
    setMode("transition");
    setForm(emptyForm);
    setSourceBanner("Đã xóa biểu mẫu. Nhập số liệu mới để bắt đầu tính.");
    setPendingSheets([]);
    setImportState("");
    setPosition("");
    setPositionMessage("");
  };

  const importWorkbook = async (file?: File) => {
    if (!file || exporting || importState.startsWith("Đang")) return;
    const version = ++importVersionRef.current;
    setImportState(`Đang đọc ${file.name}…`);
    try {
      const sheets = await readCurveWorkbook(file);
      if (version !== importVersionRef.current) return;
      if (!sheets.length)
        throw new Error(
          "Không tìm thấy sheet có thông số đường cong tương thích."
        );
      if (sheets.length === 1) {
        loadInput(
          sheets[0].name,
          sheets[0].input,
          `Đã nạp sheet “${sheets[0].name}” từ ${file.name}. Bạn đang xem số liệu đã nhập, không phải mẫu mặc định.`
        );
      } else {
        setPendingSheets(sheets);
        setSourceBanner(
          `Đã đọc ${sheets.length} sheet từ ${file.name}; số liệu hiện tại chưa thay đổi. Chọn sheet cần đưa vào bảng đường tên.`
        );
      }
      setImportState("");
    } catch (error) {
      if (version !== importVersionRef.current) return;
      setImportState(
        error instanceof Error ? error.message : "Không đọc được workbook."
      );
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const exportWorkbook = async () => {
    if (!result || exporting) return;
    setExporting(true);
    setImportState("Đang tạo file Excel kết quả…");
    try {
      await downloadCurveWorkbook(
        result,
        form.name.trim() || "duong-cong",
        includeCircular ? (circular.result ?? undefined) : undefined
      );
      setImportState("Đã xuất bảng đường cong.");
    } catch (error) {
      setImportState(
        error instanceof Error ? error.message : "Chưa xuất được file Excel."
      );
    } finally {
      setExporting(false);
    }
  };

  const calculatePosition = () => {
    if (!result) {
      setPositionMessage("Cần có bộ số liệu hợp lệ trước khi tính vị trí.");
      return;
    }
    const x = parseNumber(position);
    if (!Number.isFinite(x)) {
      setPositionMessage(
        "Nhập x (m) là một số hữu hạn. Có thể nhập số âm hoặc lớn hơn KT."
      );
      return;
    }
    try {
      setPositionMessage(
        `FKH tại x = ${numberText(x, 3)} m: ${numberText(versineAt(parsed.input, x), 0)} mm.`
      );
    } catch (error) {
      setPositionMessage(
        error instanceof Error ? error.message : "Không tính được vị trí."
      );
    }
  };

  return (
    <section className="min-w-0">
      <div>
        <div className="text-xs font-bold uppercase tracking-[0.2em] text-[#3caea3]">
          ĐƯỜNG CONG · TÍNH THEO WORKBOOK
        </div>
        <h1 className="mt-2 text-3xl font-black text-[#173f5f]">
          Phân tích và tính đường cong
        </h1>
        <p className="mt-2 max-w-4xl text-sm leading-6 text-slate-500">
          Nhập số liệu đường cong hoặc nạp workbook tương thích để tính FKH theo
          từng điểm. Mô hình giữ cách xấp xỉ nhỏ-góc của file mẫu, được tổng
          quát hóa cho hòa hoãn không đối xứng và các mốc lẻ.
        </p>
      </div>

      {sourceBanner && (
        <div className="mt-4 rounded-xl border border-[#c5e5df] bg-[#e6f3f1] px-3 py-2.5 text-sm leading-6 text-[#17665f]">
          {sourceBanner}
        </div>
      )}
      {importState && (
        <div
          className={`mt-3 rounded-xl border px-3 py-2.5 text-sm ${importState.startsWith("Đã") ? "border-[#c5e5df] bg-[#e6f3f1] text-[#17665f]" : importState.startsWith("Đang") ? "border-slate-200 bg-white text-slate-600" : "border-red-200 bg-red-50 text-red-800"}`}
          role={importState.startsWith("Đang") ? "status" : "alert"}
        >
          {importState}
          {(importState.startsWith("Đang") || exporting) && (
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-100">
              <div className="h-full w-2/3 animate-pulse rounded-full bg-[#2d8a72]" />
            </div>
          )}
        </div>
      )}

      <div className="mt-4 grid gap-4 xl:grid-cols-[minmax(0,1fr)_320px]">
        <div className="min-w-0 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 pb-4">
            <div>
              <div className="text-sm font-black text-[#173f5f]">
                BẢNG ĐƯỜNG TÊN
              </div>
              <p className="mt-1 text-xs leading-5 text-slate-500">
                Các ô giữ dạng chuỗi khi nhập để ô trống được báo lỗi, không tự
                biến thành 0.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={importState.startsWith("Đang") || exporting}
                className="rounded-lg bg-[#173f5f] px-3 py-2 text-xs font-bold text-white hover:bg-[#102f48] disabled:opacity-50"
              >
                Nạp Excel
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xls"
                className="hidden"
                onChange={event => {
                  void importWorkbook(event.target.files?.[0]);
                }}
              />
              <button
                type="button"
                onClick={resetForm}
                disabled={exporting}
                className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50 disabled:opacity-50"
              >
                Mẫu mới / xóa
              </button>
              <button
                type="button"
                onClick={() => void exportWorkbook()}
                disabled={!result || exporting}
                className="rounded-lg border border-[#9acfc8] bg-[#f1faf8] px-3 py-2 text-xs font-bold text-[#17766e] hover:bg-[#e6f3f1] disabled:opacity-50"
              >
                {exporting ? "Đang xuất…" : "Xuất Excel"}
              </button>
            </div>
          </div>

          <div className="mt-4 grid gap-3 sm:grid-cols-[minmax(0,1fr)_180px]">
            <Field
              id="curve-name"
              label="Tên đường cong / sheet"
              value={form.name}
              onChange={value => updateForm("name", value)}
              hint="Dùng làm tên file và tiêu đề kết quả."
            />
            <label
              htmlFor="curve-example"
              className="block text-sm font-semibold text-slate-700"
            >
              <span className="mb-1.5 block">Mẫu thực từ workbook</span>
              <select
                id="curve-example"
                defaultValue=""
                onChange={event => {
                  const example = CURVE_EXAMPLES[Number(event.target.value)];
                  if (example)
                    loadInput(
                      example.name,
                      example.input,
                      `Đã nạp mẫu từ file đã gửi: ${example.name}. Hãy thay bằng số liệu đường cong cần tính.`
                    );
                  event.currentTarget.value = "";
                }}
                className="h-9 w-full rounded-lg border border-slate-200 bg-white px-2 text-sm font-normal outline-none focus:border-[#3caea3] focus:ring-2 focus:ring-[#3caea3]/25"
              >
                <option value="">Chọn mẫu…</option>
                {CURVE_EXAMPLES.map((example, index) => (
                  <option key={example.name} value={index}>
                    {example.name}
                  </option>
                ))}
              </select>
            </label>
          </div>

          <div className="mt-4 rounded-xl border border-[#d7e2e8] bg-[#f8fbfc] p-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="text-xs font-black uppercase tracking-wide text-[#173f5f]">
                Chế độ hình học
              </div>
              <span className="text-[11px] text-slate-500">
                Tròn sẽ đặt L1 = L2 = 0
              </span>
            </div>
            <div className="mt-2 grid gap-2 sm:grid-cols-2">
              <button
                type="button"
                onClick={() => selectMode("transition")}
                className={`rounded-lg border px-3 py-2 text-left text-sm ${mode === "transition" ? "border-[#3caea3] bg-[#e6f3f1] font-bold text-[#17766e]" : "border-slate-200 bg-white text-slate-600"}`}
              >
                <span className="block">Hòa hoãn</span>
                <span className="mt-0.5 block text-[11px] font-normal text-slate-500">
                  Cho phép L1/L2 lệch nhau hoặc một bên bằng 0.
                </span>
              </button>
              <button
                type="button"
                onClick={() => selectMode("circular")}
                className={`rounded-lg border px-3 py-2 text-left text-sm ${mode === "circular" ? "border-[#3caea3] bg-[#e6f3f1] font-bold text-[#17766e]" : "border-slate-200 bg-white text-slate-600"}`}
              >
                <span className="block">Tròn</span>
                <span className="mt-0.5 block text-[11px] font-normal text-slate-500">
                  Chỉ đoạn cong tròn một bán kính.
                </span>
              </button>
            </div>
          </div>

          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Field
              id="curve-radius"
              label="Bán kính R"
              value={form.radius}
              onChange={value => updateForm("radius", value)}
              suffix="m"
            />
            <Field
              id="curve-length"
              label="Chiều dài khai triển KT"
              value={form.length}
              onChange={value => updateForm("length", value)}
              suffix="m"
            />
            <Field
              id="curve-chord"
              label="Dây cung C"
              value={form.chord}
              onChange={value => updateForm("chord", value)}
              suffix="m"
              hint="Bước bảng = C/2."
            />
            <Field
              id="curve-transition-in"
              label="Hòa hoãn vào L1"
              value={form.transitionIn}
              onChange={value => updateForm("transitionIn", value)}
              suffix="m"
              disabled={mode === "circular"}
            />
            <Field
              id="curve-transition-out"
              label="Hòa hoãn ra L2"
              value={form.transitionOut}
              onChange={value => updateForm("transitionOut", value)}
              suffix="m"
              disabled={mode === "circular"}
            />
            <Field
              id="curve-start-chainage"
              label="Lý trình NĐ"
              value={form.startChainage}
              onChange={value => updateForm("startChainage", value)}
              suffix="m"
              hint="Nhập mét tuyệt đối, ví dụ 546324,63. Giá trị 0 chỉ là mốc tương đối; không tự lấy từ tên sheet."
            />
            <Field
              id="curve-sample-offset"
              label="Vị trí điểm đo đầu"
              value={form.sampleOffset}
              onChange={value => updateForm("sampleOffset", value)}
              suffix="m"
              hint="Cho phép [-C/2, C/2). Mặc định 0."
            />
          </div>
          <div className="mt-3">
            <ErrorBox errors={parsed.errors} />
          </div>
        </div>

        <div className="space-y-3">
          <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="text-sm font-black text-[#173f5f]">
              MỐC VÀ THÔNG SỐ TÍNH
            </div>
            {result ? (
              <div className="mt-3 grid gap-2 sm:grid-cols-2 xl:grid-cols-1">
                <Metric
                  label="Fc = C²/(8R) × 1000"
                  value={numberText(result.fc)}
                  suffix="mm"
                />
                <Metric
                  label="C/2 · bước tính"
                  value={numberText(result.step)}
                  suffix="m"
                />
                <Metric
                  label="Z1 / Z2"
                  value={`${result.zIn === null ? "—" : numberText(result.zIn)} / ${result.zOut === null ? "—" : numberText(result.zOut)}`}
                  suffix="mm"
                />
                <Metric
                  label="Đoạn cong tròn"
                  value={numberText(result.circularLength)}
                  suffix="m"
                />
                <Metric
                  label="Góc tổng"
                  value={numberText(result.totalAngleDegrees)}
                  suffix="°"
                />
              </div>
            ) : (
              <div className="mt-3 rounded-xl bg-slate-50 p-3 text-sm leading-6 text-slate-500">
                Nhập đủ và sửa lỗi số liệu để xem các mốc.
              </div>
            )}
          </div>
          {result?.warnings.length ? (
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs leading-5 text-amber-900">
              <div className="font-bold">Cảnh báo kỹ thuật</div>
              {result.warnings.map(warning => (
                <div key={warning} className="mt-1">
                  {warning}
                </div>
              ))}
            </div>
          ) : null}
        </div>
      </div>

      {pendingSheets.length > 0 && (
        <div className="mt-4 rounded-2xl border border-[#9acfc8] bg-[#f7fcfb] p-4">
          <div className="font-bold text-[#173f5f]">Chọn sheet cần nhập</div>
          <p className="mt-1 text-xs leading-5 text-slate-500">
            Workbook có nhiều sheet đường cong. Chọn một sheet để đưa thông số
            vào biểu mẫu.
          </p>
          <div className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {pendingSheets.map(sheet => (
              <button
                key={sheet.name}
                type="button"
                onClick={() =>
                  loadInput(
                    sheet.name,
                    sheet.input,
                    `Đã nạp sheet “${sheet.name}”. Bạn đang xem số liệu đã nhập, không phải mẫu mặc định.`
                  )
                }
                className="rounded-lg border border-[#c5e5df] bg-white px-3 py-2 text-left text-sm font-semibold text-[#17766e] hover:bg-[#e6f3f1]"
              >
                {sheet.name}
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="mt-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
        <div className="flex flex-wrap items-end justify-between gap-2">
          <div>
            <div className="text-sm font-black text-[#173f5f]">
              ĐỒ THỊ FKH THEO ĐIỂM ĐO
            </div>
            <p className="mt-1 text-xs text-slate-500">
              Dữ liệu thực từ kết quả tính; chỉ giảm số điểm hiển thị trên đồ
              thị khi bảng có hơn 1.000 dòng.
            </p>
          </div>
          {result && (
            <div className="text-xs tabular-nums text-slate-500">
              {result.rows.length.toLocaleString("vi-VN")} dòng bảng
            </div>
          )}
        </div>
        {result ? (
          <div className="mt-3 h-64 w-full min-w-0">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={chartData}
                margin={{ top: 8, right: 12, left: 0, bottom: 8 }}
              >
                <CartesianGrid stroke="#e5edf1" strokeDasharray="3 3" />
                <XAxis
                  dataKey="x"
                  type="number"
                  domain={["dataMin", "dataMax"]}
                  tickFormatter={(value: number) => numberText(value, 1)}
                  tick={{ fontSize: 11 }}
                />
                <YAxis
                  tickFormatter={(value: number) => numberText(value, 0)}
                  tick={{ fontSize: 11 }}
                  width={44}
                />
                <Tooltip
                  formatter={(value: number) => [
                    `${numberText(value, 0)} mm`,
                    "FKH",
                  ]}
                  labelFormatter={(value: number) =>
                    `x = ${numberText(value, 3)} m`
                  }
                />
                <Line
                  type="linear"
                  dataKey="f"
                  stroke="#17766e"
                  strokeWidth={2}
                  dot={false}
                  isAnimationActive={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="mt-3 grid h-48 place-items-center rounded-xl bg-slate-50 text-sm text-slate-500">
            Đồ thị sẽ xuất hiện sau khi số liệu hợp lệ.
          </div>
        )}
      </div>

      <div className="mt-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <div className="text-sm font-black text-[#173f5f]">
              BẢNG ĐIỂM TÍNH
            </div>
            <p className="mt-1 text-xs text-slate-500">
              Giữ toàn bộ dòng kết quả; khung cuộn ngang/dọc để không làm tràn
              màn hình.
            </p>
          </div>
          {result && (
            <span className="rounded-full bg-[#e6f3f1] px-2.5 py-1 text-xs font-bold text-[#17766e]">
              FKH làm tròn đến mm (số nguyên)
            </span>
          )}
        </div>
        {result ? (
          <div
            className="mt-3 max-h-[520px] overflow-auto rounded-xl border border-slate-200 focus-visible:outline-2 focus-visible:outline-[#3caea3]"
            role="region"
            aria-label="Bảng điểm đường tên"
            tabIndex={0}
          >
            <table className="rail-table min-w-[760px] w-full text-xs tabular-nums">
              <thead className="sticky top-0 z-10 bg-[#edf3f5] text-[#173f5f]">
                <tr>
                  <th className="px-3 py-2 text-left">Điểm</th>
                  <th className="px-3 py-2 text-right">x (m)</th>
                  <th className="px-3 py-2 text-right">Lý trình</th>
                  <th className="px-3 py-2 text-left">Vị trí vùng</th>
                  <th className="px-3 py-2 text-right">FKH (mm)</th>
                </tr>
              </thead>
              <tbody>
                {result.rows.map(row => (
                  <tr
                    key={`${row.index}-${row.distance}`}
                    className="border-t border-slate-100"
                  >
                    <td className="px-3 py-2 font-semibold text-[#173f5f]">
                      {row.index}
                      {row.label && (
                        <span className="ml-2 rounded bg-[#fff8df] px-1.5 py-0.5 text-[10px] text-[#9a6500]">
                          {row.label}
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-2 text-right">
                      {numberText(row.distance, 3)}
                    </td>
                    <td className="px-3 py-2 text-right">
                      {formatChainage(row.chainage)}
                    </td>
                    <td className="px-3 py-2">{row.region}</td>
                    <td className="px-3 py-2 text-right font-bold">
                      {numberText(row.f, 0)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="mt-3 rounded-xl bg-slate-50 p-4 text-sm text-slate-500">
            Chưa có bảng vì số liệu đang thiếu hoặc chưa hợp lệ.
          </div>
        )}
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[minmax(0,1fr)_360px]">
        <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
          <div className="text-sm font-black text-[#173f5f]">
            MỐC BIÊN ĐƯỜNG CONG
          </div>
          {result ? (
            <div
              className="mt-3 overflow-auto rounded-xl border border-slate-200 focus-visible:outline-2 focus-visible:outline-[#3caea3]"
              role="region"
              aria-label="Mốc biên đường cong"
              tabIndex={0}
            >
              <table className="min-w-[760px] w-full text-xs tabular-nums">
                <thead className="bg-[#edf3f5] text-[#173f5f]">
                  <tr>
                    <th className="px-3 py-2 text-left">Mốc</th>
                    <th className="px-3 py-2 text-right">m</th>
                    <th className="px-3 py-2 text-right">Lý trình</th>
                    <th className="px-3 py-2 text-right">F (mm)</th>
                    <th className="px-3 py-2 text-left">Vị trí trong bảng</th>
                  </tr>
                </thead>
                <tbody>
                  {result.boundaries.map(boundary => (
                    <tr
                      key={`${boundary.label}-${boundary.distance}`}
                      className="border-t border-slate-100"
                    >
                      <td className="px-3 py-2 font-bold text-[#173f5f]">
                        {boundary.label}
                      </td>
                      <td className="px-3 py-2 text-right">
                        {numberText(boundary.distance, 3)}
                      </td>
                      <td className="px-3 py-2 text-right">
                        {formatChainage(boundary.chainage)}
                      </td>
                      <td className="px-3 py-2 text-right">
                        {numberText(boundary.f, 0)}
                      </td>
                      <td className="px-3 py-2">{boundary.placement}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="mt-3 rounded-xl bg-slate-50 p-3 text-sm text-slate-500">
              Các mốc NĐ, TĐ, TC, NC sẽ hiện ở đây.
            </div>
          )}
        </div>
        <div className="rounded-2xl border border-[#c5e5df] bg-[#f7fcfb] p-4 shadow-sm sm:p-5">
          <div className="text-sm font-black text-[#173f5f]">
            TÍNH FKH TẠI VỊ TRÍ BẤT KỲ
          </div>
          <p className="mt-1 text-xs leading-5 text-slate-500">
            Dùng cùng mô hình tích phân, độc lập với bước bảng. Cho phép x âm
            hoặc x lớn hơn KT để kiểm tra ngoài phạm vi điểm đầu/cuối.
          </p>
          <div className="mt-3 flex gap-2">
            <input
              aria-label="Vị trí x"
              value={position}
              onChange={event => {
                setPosition(event.target.value);
                setPositionMessage("");
              }}
              placeholder="x (m)"
              className="h-9 min-w-0 flex-1 rounded-lg border border-slate-200 bg-white px-3 text-right text-sm outline-none focus:border-[#3caea3] focus:ring-2 focus:ring-[#3caea3]/25"
            />
            <button
              type="button"
              onClick={calculatePosition}
              className="rounded-lg bg-[#17766e] px-3 text-xs font-bold text-white hover:bg-[#125d58]"
            >
              Tính
            </button>
          </div>
          {positionMessage && (
            <div
              role="status"
              className={`mt-2 text-xs leading-5 ${positionMessage.startsWith("FKH") ? "text-[#17766e]" : "text-red-700"}`}
            >
              {positionMessage}
            </div>
          )}
        </div>
      </div>

      <div className="mt-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
        <div className="text-sm font-black text-[#173f5f]">
          T, P, KT CỦA ĐƯỜNG CONG TRÒN
        </div>
        <p className="mt-1 text-xs leading-5 text-slate-500">
          Tính riêng hình học tròn từ R và góc độ/phút/giây; dùng Math.PI thống
          nhất. Kết quả này không thay thế phần hòa hoãn.
        </p>
        <div className="mt-3 grid gap-3 sm:grid-cols-4">
          <Field
            id="circular-radius"
            label="R"
            value={circularForm.radius}
            onChange={value =>
              setCircularForm(old => ({ ...old, radius: value }))
            }
            suffix="m"
          />
          <Field
            id="circular-degrees"
            label="Độ"
            value={circularForm.degrees}
            onChange={value =>
              setCircularForm(old => ({ ...old, degrees: value }))
            }
          />
          <Field
            id="circular-minutes"
            label="Phút"
            value={circularForm.minutes}
            onChange={value =>
              setCircularForm(old => ({ ...old, minutes: value }))
            }
          />
          <Field
            id="circular-seconds"
            label="Giây"
            value={circularForm.seconds}
            onChange={value =>
              setCircularForm(old => ({ ...old, seconds: value }))
            }
          />
        </div>
        <div className="mt-3">
          <ErrorBox errors={circular.errors} />
        </div>
        <label className="mt-3 inline-flex items-center gap-2 text-xs text-slate-600">
          <input
            type="checkbox"
            checked={includeCircular}
            onChange={event => setIncludeCircular(event.target.checked)}
          />
          Kèm phần T/P/KT tính riêng khi xuất Excel (chỉ khi số liệu hợp lệ)
        </label>
        {circular.result && (
          <>
            <div className="mt-3 grid gap-2 sm:grid-cols-3">
              <Metric
                label="T = R tan(α/2)"
                value={numberText(circular.result.tangent)}
                suffix="m"
              />
              <Metric
                label="KT = R α(rad)"
                value={numberText(circular.result.length)}
                suffix="m"
              />
              <Metric
                label="P = R(sec(α/2)−1)"
                value={numberText(circular.result.external)}
                suffix="m"
              />
            </div>
            <button
              type="button"
              onClick={() => {
                importVersionRef.current += 1;
                setImportState("");
                setMode("circular");
                setPendingSheets([]);
                setForm(old => ({
                  ...old,
                  radius: circularForm.radius,
                  length: displayInputValue(
                    circular.result?.length ?? Number.NaN
                  ),
                  transitionIn: "0",
                  transitionOut: "0",
                }));
                setSourceBanner(
                  "Đã dùng R/KT từ phần hình học tròn cho bảng đường tên; L1 = L2 = 0."
                );
              }}
              className="mt-3 rounded-lg border border-[#9acfc8] bg-white px-3 py-2 text-xs font-bold text-[#17766e] hover:bg-[#e6f3f1]"
            >
              Dùng R/KT cho bảng đường tên
            </button>
          </>
        )}
      </div>

      <details className="mt-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-5">
        <summary className="cursor-pointer text-sm font-black text-[#173f5f]">
          PHÂN TÍCH FILE &amp; PHẠM VI
        </summary>
        <div className="mt-3 grid gap-3 text-sm leading-6 text-slate-600 lg:grid-cols-2">
          <div>
            <p>
              Workbook mẫu có 3 sheet: <b>HH</b> với R=500 m, L1=L2=40 m, KT=276
              m, C=20 m; <b>tròn</b> với R=2000 m, KT=441,62 m, C=20 m; và{" "}
              <b>Sheet1</b> có các giá trị T/P/KT theo góc DMS.
            </p>
            <p className="mt-2">
              Bản tính xử lý trực tiếp các mốc NĐ, TĐ, TC, NC, hòa hoãn không
              đối xứng, L=0 và đoạn ngắn; không làm tròn trung gian.
            </p>
          </div>
          <div>
            <p>
              Nguồn workbook có các vấn đề cần tránh khi dùng lại: hardcode{" "}
              <b>/10</b>, chia cho đoạn có độ dài bằng 0, lỗi <b>#REF!</b> và
              hằng số π không nhất quán. FKH ở đây là mô hình xấp xỉ nhỏ-góc của
              workbook, <b>không phải sagitta tròn chính xác</b>.
            </p>
            <p className="mt-2">
              Phạm vi chỉ gồm đường cong đơn một bán kính và hòa hoãn biến thiên
              tuyến tính; không bao gồm đường cong tổ hợp hoặc ngược. Cần kỹ
              thuật kiểm tra trước khi dùng ngoài hiện trường.
            </p>
          </div>
        </div>
        <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs leading-5 text-amber-900">
          Công cụ hỗ trợ phân tích và kiểm tra số liệu. Không tự suy diễn định
          mức hoặc quy định pháp lý.
        </div>
      </details>
    </section>
  );
}

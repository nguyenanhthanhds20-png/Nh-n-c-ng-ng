import React, { useState } from "react";
import { Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

type Props = {
  name: string;
  disabled: boolean;
  deleting: boolean;
  onDelete: () => Promise<unknown>;
};

export function DeleteDocumentButton({ name, disabled, deleting, onDelete }: Props) {
  const [open, setOpen] = useState(false);
  return (
    <AlertDialog open={open} onOpenChange={value => { if (!deleting) setOpen(value); }}>
      <AlertDialogTrigger asChild>
        <button
          type="button"
          disabled={disabled}
          aria-label={`Xóa file ${name} khỏi kho CHATBOT`}
          title={`Xóa ${name} khỏi kho tra cứu`}
          className="inline-flex min-h-10 shrink-0 items-center gap-1 rounded-lg border border-red-200 bg-white px-2 py-2 text-xs font-semibold text-red-700 transition hover:bg-red-50 disabled:cursor-wait disabled:opacity-50"
        >
          <Trash2 size={15} aria-hidden="true" />
          {deleting ? "Đang xóa…" : "Xóa"}
        </button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Xóa file khỏi kho CHATBOT?</AlertDialogTitle>
          <AlertDialogDescription className="break-words text-left leading-6">
            File: <strong className="text-slate-800">{name}</strong>.
            <br />
            File sẽ bị ẩn khỏi danh sách và không còn được dùng cho các câu hỏi mới.
            Các câu trả lời cũ vẫn giữ nguyên. Thao tác này chưa xóa vĩnh viễn bản gốc khỏi bộ nhớ lưu trữ.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={deleting}>Hủy</AlertDialogCancel>
          <AlertDialogAction
            disabled={disabled}
            className="bg-red-700 text-white hover:bg-red-800"
            onClick={async event => {
              event.preventDefault();
              if (disabled) return;
              try {
                await onDelete();
                setOpen(false);
              } catch {
                // The mutation displays an error; keep confirmation open so Admin can retry.
              }
            }}
          >
            {deleting ? "Đang xóa…" : "Xóa khỏi kho"}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

import React from "react";
import { Streamdown } from "streamdown";

/** Display document-grounded answers without loading links, remote images or raw HTML. */
export function ChatbotAnswer({ content }: { content: string }) {
  return (
    <Streamdown
      parseIncompleteMarkdown={false}
      controls={false}
      skipHtml
      rehypePlugins={[]}
      components={{
        img: () => null,
        a: ({ children }) => <span>{children}</span>,
        table: ({ children }) => (
          <div className="my-3 max-w-full overflow-x-auto rounded-lg border border-slate-300 bg-white">
            <table className="w-full border-collapse text-left text-sm">{children}</table>
          </div>
        ),
      }}
      className="min-w-0 max-w-full break-words leading-7 [&_p]:my-2 [&_h1]:mt-4 [&_h1]:text-lg [&_h1]:font-bold [&_h2]:mt-4 [&_h2]:text-base [&_h2]:font-bold [&_h3]:mt-3 [&_h3]:font-bold [&_ul]:my-2 [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:my-2 [&_ol]:list-decimal [&_ol]:pl-5 [&_li]:my-1 [&_blockquote]:my-3 [&_blockquote]:border-l-4 [&_blockquote]:border-[#3caea3] [&_blockquote]:bg-white [&_blockquote]:px-3 [&_blockquote]:py-2 [&_th]:border [&_th]:border-slate-200 [&_th]:bg-slate-100 [&_th]:px-3 [&_th]:py-2 [&_td]:border [&_td]:border-slate-200 [&_td]:px-3 [&_td]:py-2"
    >
      {content}
    </Streamdown>
  );
}

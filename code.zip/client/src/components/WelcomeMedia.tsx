import { ImagePlus, Pause, Play, RotateCcw } from "lucide-react";
import React, { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import {
  readWelcomeMedia,
  saveWelcomeMedia,
  validateWelcomeMedia,
} from "@/lib/welcomeMedia";

type Media = {
  src: string;
  kind: "image" | "video";
  name: string;
  custom: boolean;
};

export function WelcomeMedia({
  defaultVideo,
  defaultPoster,
}: {
  defaultVideo: string;
  defaultPoster: string;
}) {
  const [media, setMedia] = useState<Media>({
    src: defaultVideo,
    kind: "video",
    name: "nen-dep.mp4",
    custom: false,
  });
  const [ready, setReady] = useState(false);
  const [saving, setSaving] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(true);
  const [playing, setPlaying] = useState(false);
  const [mediaError, setMediaError] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  function showFile(file: File) {
    videoRef.current?.pause();
    setPlaying(false);
    setMedia({
      src: URL.createObjectURL(file),
      kind: file.type.startsWith("video/") ? "video" : "image",
      name: file.name,
      custom: true,
    });
    setMediaError(false);
  }

  useEffect(() => {
    let cancelled = false;
    readWelcomeMedia()
      .then(file => {
        if (!cancelled && file && !validateWelcomeMedia(file)) showFile(file);
      })
      .catch(() => {
        // Private browsing or disabled storage still permits a session-only preview.
      })
      .finally(() => {
        if (!cancelled) setReady(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (typeof window.matchMedia !== "function") return;
    const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReducedMotion(preference.matches);
    update();
    preference.addEventListener("change", update);
    return () => preference.removeEventListener("change", update);
  }, []);

  useEffect(() => {
    return () => {
      if (media.src.startsWith("blob:")) URL.revokeObjectURL(media.src);
    };
  }, [media.src]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    if (!ready || reducedMotion) video.pause();
    else
      void video.play().catch(() => {
        /* The play button handles autoplay blocking. */
      });
  }, [media.src, media.kind, ready, reducedMotion]);

  async function selectFile(file?: File) {
    if (!file || saving) return;
    const error = validateWelcomeMedia(file);
    if (error) {
      toast.error(error);
      return;
    }
    setSaving(true);
    showFile(file);
    try {
      await saveWelcomeMedia(file);
      toast.success("Đã lưu ảnh/video cho khung chào trên trình duyệt này.");
    } catch {
      toast.warning(
        "Đã hiển thị file, nhưng trình duyệt không cho lưu. Lựa chọn chỉ dùng trong phiên hiện tại."
      );
    } finally {
      setSaving(false);
    }
  }

  async function restoreDefault() {
    if (saving) return;
    setSaving(true);
    try {
      await saveWelcomeMedia(null);
      videoRef.current?.pause();
      setPlaying(false);
      setMedia({
        src: defaultVideo,
        kind: "video",
        name: "nen-dep.mp4",
        custom: false,
      });
      setMediaError(false);
    } catch {
      toast.error("Chưa xóa được lựa chọn đã lưu. Vui lòng thử lại.");
    } finally {
      setSaving(false);
    }
  }

  function toggleVideo() {
    const video = videoRef.current;
    if (!video) return;
    if (!video.paused) video.pause();
    else
      void video
        .play()
        .catch(() =>
          toast.error(
            "Trình duyệt chưa phát được video này. Hãy chọn video MP4/WebM khác."
          )
        );
  }

  return (
    <div className="mx-auto w-fit max-w-full">
      <div
        className="relative mx-auto size-44 overflow-hidden rounded-2xl border border-[#c5e5df] bg-white shadow-sm sm:size-48"
        aria-label="Khung ảnh hoặc video chào CHATBOT"
      >
        {media.kind === "video" ? (
          <video
            key={media.src}
            ref={videoRef}
            src={media.src}
            poster={media.custom ? undefined : defaultPoster}
            muted
            loop
            playsInline
            preload="metadata"
            autoPlay={ready && !reducedMotion}
            className="h-full w-full object-contain"
            aria-label={`Video chào CHATBOT: ${media.name}`}
            onPlay={() => setPlaying(true)}
            onPause={() => setPlaying(false)}
            onError={() => {
              setMediaError(true);
              setPlaying(false);
            }}
            onLoadedMetadata={event => setPlaying(!event.currentTarget.paused)}
          />
        ) : (
          <img
            src={media.src}
            alt={`Ảnh chào CHATBOT: ${media.name}`}
            className="h-full w-full object-contain"
            onError={() => setMediaError(true)}
          />
        )}
        {mediaError && !media.custom && (
          <img
            src={defaultPoster}
            alt="Ảnh dự phòng chào CHATBOT"
            className="absolute inset-0 h-full w-full object-contain"
          />
        )}
        {mediaError && (
          <div
            className={
              media.custom
                ? "absolute inset-0 grid place-items-center bg-slate-50 p-4 text-xs leading-5 text-slate-600"
                : "absolute inset-x-0 bottom-0 bg-white/95 px-2 py-1 text-[10px] leading-4 text-slate-600"
            }
            role="alert"
          >
            {media.custom
              ? "Không đọc được ảnh/video. Vui lòng chọn file khác."
              : "Video chưa phát được; đang hiển thị ảnh dự phòng."}
          </div>
        )}
        {media.kind === "video" && !mediaError && (
          <button
            type="button"
            onClick={toggleVideo}
            className="absolute bottom-2 right-2 grid size-8 place-items-center rounded-full bg-[#173f5f]/90 text-white"
            aria-label={playing ? "Tạm dừng video chào" : "Phát video chào"}
            title={playing ? "Tạm dừng video" : "Phát video"}
          >
            {playing ? <Pause size={15} /> : <Play size={15} />}
          </button>
        )}
      </div>
      <div className="mt-2 flex flex-wrap items-center justify-center gap-2">
        <input
          ref={inputRef}
          type="file"
          accept="image/*,video/*"
          className="hidden"
          aria-label="Chọn ảnh hoặc video cho khung chào"
          onChange={event => {
            void selectFile(event.target.files?.[0]);
            event.currentTarget.value = "";
          }}
        />
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={!ready || saving}
          className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-[#173f5f] hover:bg-[#edf8f6] disabled:opacity-50"
        >
          <ImagePlus size={14} /> {saving ? "Đang lưu…" : "Tải ảnh / video"}
        </button>
        {media.custom && (
          <button
            type="button"
            onClick={() => {
              void restoreDefault();
            }}
            disabled={saving}
            className="inline-flex items-center gap-1 rounded-lg px-2 py-1.5 text-xs text-slate-500 hover:text-[#173f5f] disabled:opacity-50"
            title="Dùng lại video AIĐSQB.mp4"
          >
            <RotateCcw size={13} /> Video gốc
          </button>
        )}
      </div>
      <div className="mt-1 text-[10px] leading-4 text-slate-400">
        Tối đa 50 MB · Lưu trên trình duyệt này
      </div>
    </div>
  );
}

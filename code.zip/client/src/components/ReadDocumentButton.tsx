import React from "react";
import { BookOpen, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

type Props = {
  id: number;
  name: string;
  processingStatus: string;
};

export function ReadDocumentButton({ id, name, processingStatus }: Props) {
  const [open, setOpen] = React.useState(false);
  const documentQuery = trpc.documents.read.useQuery({ id }, { enabled: open, retry: false });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button
          type="button"
          aria-label={`Đọc file ${name}`}
          title={`Đọc ${name}`}
          className="inline-flex min-h-10 shrink-0 items-center gap-1 rounded-lg border border-[#b9d2de] bg-white px-2 py-2 text-xs font-semibold text-[#173f5f] transition hover:bg-[#edf8f6]"
        >
          <BookOpen size={15} aria-hidden="true" />
          Đọc
        </button>
      </DialogTrigger>
      <DialogContent className="max-h-[88vh] max-w-3xl overflow-hidden p-0">
        <DialogHeader className="border-b border-slate-100 bg-[#edf8f6] px-5 py-4 pr-12 text-left">
          <DialogTitle className="break-words text-[#173f5f]">{name}</DialogTitle>
          <DialogDescription>
            Nội dung văn bản đã trích xuất từ file trong kho CHATBOT.
          </DialogDescription>
        </DialogHeader>
        <div className="max-h-[68vh] overflow-auto px-5 py-4">
          {documentQuery.isLoading ? (
            <div className="flex items-center gap-2 py-8 text-sm text-slate-500">
              <Loader2 className="animate-spin text-[#2d8a72]" size={18} /> Đang đọc file…
            </div>
          ) : documentQuery.isError ? (
            <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm leading-6 text-red-800">
              Chưa đọc được file này. Vui lòng thử lại hoặc kiểm tra file gốc.
            </div>
          ) : documentQuery.data?.extractedText ? (
            <pre className="whitespace-pre-wrap break-words rounded-xl border border-slate-200 bg-white p-4 font-sans text-sm leading-6 text-slate-700">
              {documentQuery.data.extractedText}
            </pre>
          ) : (
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm leading-6 text-amber-800">
              {processingStatus === "failed"
                ? "File đã lưu nhưng trích xuất nội dung bị lỗi. Hãy tải lại file có thể đọc được."
                : "File đã lưu nhưng chưa có nội dung văn bản để hiển thị. PDF scan cần OCR; định dạng chưa hỗ trợ cần chuyển sang PDF có lớp chữ, TXT hoặc Excel."}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

/** Opt into smooth scrolling only when the user explicitly allows motion. */
export function getScrollBehavior(): ScrollBehavior {
  if (typeof window === "undefined" || typeof window.matchMedia !== "function") {
    return "auto";
  }

  return window.matchMedia("(prefers-reduced-motion: no-preference)").matches
    ? "smooth"
    : "auto";
}

import * as XLSX from "xlsx";
import {
  calculateCurve,
  formatChainage,
  validateCurveInput,
  type CurveInput,
  type CurveResult,
  type calculateCircularElements,
} from "./curveCalculations";

function fold(value: unknown) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/gi, "d")
    .toLowerCase()
    .trim();
}
function numeric(value: unknown): number {
  if (typeof value === "number") return value;
  if (typeof value === "string" && value.trim())
    return Number(value.trim().replace(",", "."));
  return Number.NaN;
}

export function extractCurveInputs(
  workbook: XLSX.WorkBook
): { name: string; input: CurveInput }[] {
  const results: { name: string; input: CurveInput }[] = [];
  const rejected: string[] = [];
  for (const name of workbook.SheetNames) {
    const sheet = workbook.Sheets[name];
    let input: CurveInput | null = null;
    if (
      fold(sheet.B3?.v).includes("ban kinh") &&
      fold(sheet.B6?.v).includes("khai trien")
    ) {
      input = {
        radius: numeric(sheet.E3?.v),
        transitionIn: numeric(sheet.E4?.v),
        transitionOut: numeric(sheet.E5?.v),
        length: numeric(sheet.E6?.v),
        chord: numeric(sheet.E7?.v),
        startChainage: 0,
        sampleOffset: 0,
      };
    } else if (sheet.A1?.v === "CURVE_WORKSPACE_V1") {
      const values: Record<string, unknown> = {};
      for (const row of XLSX.utils.sheet_to_json<unknown[]>(sheet, {
        header: 1,
        raw: true,
      })) {
        if (typeof row[0] === "string") values[row[0]] = row[1];
      }
      input = {
        radius: numeric(values.R),
        transitionIn: numeric(values.L1),
        transitionOut: numeric(values.L2),
        length: numeric(values.KT),
        chord: numeric(values.C),
        startChainage: numeric(values.START),
        sampleOffset: numeric(values.OFFSET),
      };
    }
    if (!input) continue;
    const errors = validateCurveInput(input);
    if (errors.length) rejected.push(`${name}: ${errors.join(" ")}`);
    else results.push({ name, input });
  }
  if (!results.length)
    throw new Error(
      rejected.length
        ? rejected.join("\n")
        : "Không tìm thấy sheet thông số tương thích. File mẫu cần R/L1/L2/KT/C ở E3:E7 và nhãn bán kính/khai triển ở B3/B6, hoặc file xuất từ tab Đường cong."
    );
  // Do not hide invalid recognized sheets behind the successfully imported ones.
  if (rejected.length)
    throw new Error(
      `Có sheet thông số chưa hợp lệ; chưa nhập file:\n${rejected.join("\n")}`
    );
  return results;
}

export async function readCurveWorkbook(file: File) {
  if (!/\.(xlsx|xls)$/i.test(file.name))
    throw new Error("Vui lòng chọn file .xlsx hoặc .xls.");
  if (file.size > 10 * 1024 * 1024) throw new Error("Workbook tối đa 10 MB.");
  if (!file.size) throw new Error("Workbook đang trống.");
  const workbook = XLSX.read(await file.arrayBuffer(), {
    type: "array",
    cellFormula: false,
  });
  return extractCurveInputs(workbook);
}

type CircularElements = ReturnType<typeof calculateCircularElements>;
export async function createCurveWorkbook(
  result: CurveResult,
  name: string,
  circular?: CircularElements
) {
  // Recompute from the current inputs instead of exporting a stale or altered table.
  const current = calculateCurve(result.input);
  const { default: ExcelJS } = await import("exceljs");
  const book = new ExcelJS.Workbook();
  book.creator = "Phần mềm Tính khối lượng nhân công - Đường cong";
  const params = book.addWorksheet("Thông số");
  params.addRows([
    ["CURVE_WORKSPACE_V1", name],
    ["Thông số", "Giá trị", "Đơn vị", "Diễn giải"],
    ["R", current.input.radius, "m", "Bán kính đường cong"],
    ["L1", current.input.transitionIn, "m", "Hòa hoãn vào"],
    ["L2", current.input.transitionOut, "m", "Hòa hoãn ra"],
    ["KT", current.input.length, "m", "Chiều dài khai triển tổng"],
    ["C", current.input.chord, "m", "Chiều dài dây cung"],
    ["START", current.input.startChainage, "m", "Lý trình NĐ (m tuyệt đối)"],
    ["OFFSET", current.input.sampleOffset, "m", "Vị trí điểm đo đầu so với NĐ"],
    ["C/2", current.step, "m", "Bước điểm đo"],
    ["Fc", current.fc, "mm", "1000 × C² / (8R)"],
    [
      "Z1",
      current.zIn,
      "mm",
      current.zIn === null ? "Không có hòa hoãn vào" : "1000 × (C/2)³ / (2RL1)",
    ],
    [
      "Z2",
      current.zOut,
      "mm",
      current.zOut === null ? "Không có hòa hoãn ra" : "1000 × (C/2)³ / (2RL2)",
    ],
    ["Đoạn cong tròn", current.circularLength, "m", "KT - L1 - L2"],
    [
      "Góc chuyển hướng mô hình",
      current.totalAngleDegrees,
      "độ",
      "[KT - (L1+L2)/2] / R",
    ],
    [
      "Mô hình",
      "Đường cong đơn, một bán kính; độ cong hòa hoãn tuyến tính. FKH là xấp xỉ góc nhỏ theo workbook, không phải đường tên hình học chính xác.",
    ],
    [
      "Lưu ý",
      "Không áp dụng tự động cho đường cong ghép/ngược. Kiểm tra chuyên môn trước khi dùng ngoài hiện trường.",
    ],
    [
      "Làm tròn",
      "Không làm tròn trung gian; FKH hiển thị số nguyên mm, các đại lượng khác 3 chữ số thập phân. Số gốc được giữ nguyên.",
    ],
    ...current.warnings.map(warning => ["Cảnh báo", warning]),
  ]);
  params.columns = [{ width: 30 }, { width: 25 }, { width: 12 }, { width: 65 }];
  const table = book.addWorksheet("Đường tên");
  table.addRows([
    [name || "ĐƯỜNG CONG"],
    ["Điểm", "x so với NĐ (m)", "Lý trình", "Vùng", "Mốc", "FKH (mm)"],
    ...current.rows.map(row => [
      row.index,
      row.distance,
      formatChainage(row.chainage),
      row.region,
      row.label,
      row.f,
    ]),
  ]);
  table.columns = [
    { width: 10 },
    { width: 20 },
    { width: 24 },
    { width: 30 },
    { width: 22 },
    { width: 18 },
  ];
  table.views = [{ state: "frozen", ySplit: 2 }];
  table.autoFilter = { from: "A2", to: "F2" };
  const boundaries = book.addWorksheet("Mốc đường cong");
  boundaries.addRows([
    ["Mốc chính xác của đường cong"],
    [
      "Mốc",
      "x so với NĐ (m)",
      "Lý trình",
      "FKH tại mốc (mm)",
      "Vị trí so với điểm đo",
    ],
    ...current.boundaries.map(point => [
      point.label,
      point.distance,
      formatChainage(point.chainage),
      point.f,
      point.placement,
    ]),
  ]);
  boundaries.columns = [
    { width: 22 },
    { width: 20 },
    { width: 24 },
    { width: 22 },
    { width: 40 },
  ];
  if (circular) {
    const sheet = book.addWorksheet("T P KT tính riêng");
    sheet.addRows([
      [
        "Thông số đường cong tròn tính riêng - không mặc nhiên là đường cong của bảng FKH",
      ],
      ["Đại lượng", "Giá trị", "Đơn vị", "Công thức"],
      ["R", circular.radius, "m", "Bán kính của phần T/P/KT tính riêng"],
      ["Góc α", circular.angleDegrees, "độ"],
      ["Góc α (radian)", circular.radians, "radian"],
      ["T", circular.tangent, "m", "R × tan(α/2)"],
      ["KT", circular.length, "m", "R × α (radian)"],
      ["P", circular.external, "m", "R × [1/cos(α/2) - 1]"],
    ]);
    sheet.columns = [
      { width: 40 },
      { width: 25 },
      { width: 14 },
      { width: 45 },
    ];
  }
  for (const sheet of book.worksheets) {
    sheet.views = [{ state: "frozen", ySplit: 2 }];
    sheet.pageSetup = {
      paperSize: 9,
      orientation: sheet === table ? "landscape" : "portrait",
      fitToPage: true,
      fitToWidth: 1,
      fitToHeight: 0,
    };
    sheet.eachRow((row, rowIndex) => {
      row.eachCell(cell => {
        cell.font = {
          name: "Arial",
          size: 10,
          bold: rowIndex <= 2,
          color: rowIndex <= 2 ? { argb: "FFFFFFFF" } : { argb: "FF173F5F" },
        };
        cell.alignment = { vertical: "middle", wrapText: true };
        if (rowIndex <= 2)
          cell.fill = {
            type: "pattern",
            pattern: "solid",
            fgColor: { argb: "FF173F5F" },
          };
        if (typeof cell.value === "number") cell.numFmt = "0.000";
        cell.border = {
          bottom: { style: "hair", color: { argb: "FFDDE6EB" } },
        };
      });
    });
  }
  table.getColumn(1).numFmt = "0";
  table.getColumn(6).numFmt = "0";
  boundaries.getColumn(4).numFmt = "0";
  table.eachRow((row, index) => {
    if (index > 2) row.getCell(6).numFmt = "0";
  });
  boundaries.eachRow((row, index) => {
    if (index > 2) row.getCell(4).numFmt = "0";
  });
  return book;
}

export async function downloadCurveWorkbook(
  result: CurveResult,
  name: string,
  circular?: CircularElements
) {
  const book = await createCurveWorkbook(result, name, circular);
  const buffer = await book.xlsx.writeBuffer();
  const blob = new Blob([new Uint8Array(buffer)], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${(name || "Duong-cong").replace(/[\\/:*?"<>|]/g, "-").slice(0, 100)}.xlsx`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

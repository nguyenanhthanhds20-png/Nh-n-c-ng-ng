export const MAX_WELCOME_MEDIA_BYTES = 50 * 1024 * 1024;

export function validateWelcomeMedia(
  file: Pick<File, "size" | "type">
): string | null {
  if (!file.type.startsWith("image/") && !file.type.startsWith("video/")) {
    return "Vui lòng chọn file hình ảnh hoặc video.";
  }
  if (file.size === 0) return "File đang trống, vui lòng chọn file khác.";
  if (file.size > MAX_WELCOME_MEDIA_BYTES) return "Ảnh/video tối đa 50 MB.";
  return null;
}

const DATABASE = "rail-welcome-media";
const STORE = "media";
const KEY = "chatbot-welcome";

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE, 1);
    request.onupgradeneeded = () => request.result.createObjectStore(STORE);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
    request.onblocked = () =>
      reject(new Error("Trình duyệt đang khóa lưu trữ ảnh/video."));
  });
}

export async function readWelcomeMedia(): Promise<File | null> {
  const database = await openDatabase();
  try {
    return await new Promise((resolve, reject) => {
      const request = database
        .transaction(STORE, "readonly")
        .objectStore(STORE)
        .get(KEY);
      request.onsuccess = () =>
        resolve(request.result instanceof File ? request.result : null);
      request.onerror = () => reject(request.error);
    });
  } finally {
    database.close();
  }
}

/** Passing null clears only this frame's browser preference, not chatbot documents. */
export async function saveWelcomeMedia(file: File | null): Promise<void> {
  const database = await openDatabase();
  try {
    await new Promise<void>((resolve, reject) => {
      const transaction = database.transaction(STORE, "readwrite");
      const store = transaction.objectStore(STORE);
      if (file) store.put(file, KEY);
      else store.delete(KEY);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error);
    });
  } finally {
    database.close();
  }
}

export type CurveInput = {
  radius: number;
  transitionIn: number;
  transitionOut: number;
  length: number;
  chord: number;
  startChainage: number;
  sampleOffset: number;
};
export type CurveRow = {
  index: number;
  distance: number;
  chainage: number;
  region: string;
  label: string;
  f: number;
};
export type CurveBoundary = {
  label: string;
  distance: number;
  chainage: number;
  f: number;
  placement: string;
};
export type CurveResult = {
  input: CurveInput;
  step: number;
  fc: number;
  zIn: number | null;
  zOut: number | null;
  circularLength: number;
  totalAngleDegrees: number;
  rows: CurveRow[];
  boundaries: CurveBoundary[];
  warnings: string[];
};

export const CURVE_ROW_LIMIT = 10000;
export const CURVE_EXAMPLES: { name: string; input: CurveInput }[] = [
  {
    name: "Hòa hoãn: R=500m, L1=L2=40m, KT=276m",
    input: {
      radius: 500,
      transitionIn: 40,
      transitionOut: 40,
      length: 276,
      chord: 20,
      startChainage: 0,
      sampleOffset: 0,
    },
  },
  {
    name: "Cong tròn: R=2000m, KT=441,62m",
    input: {
      radius: 2000,
      transitionIn: 0,
      transitionOut: 0,
      length: 441.62,
      chord: 20,
      startChainage: 546324.63,
      sampleOffset: 0,
    },
  },
];

export function validateCurveInput(input: CurveInput): string[] {
  const errors: string[] = [];
  if (!Object.values(input).every(Number.isFinite))
    return [
      "Nhập đầy đủ số liệu hợp lệ; không để trống hoặc nhập giá trị vô hạn.",
    ];
  if (input.radius <= 0) errors.push("Bán kính R phải lớn hơn 0 m.");
  if (input.chord <= 0) errors.push("Dây cung C phải lớn hơn 0 m.");
  if (input.length <= 0)
    errors.push("Chiều dài khai triển KT phải lớn hơn 0 m.");
  if (input.transitionIn < 0 || input.transitionOut < 0)
    errors.push("Chiều dài hòa hoãn L1/L2 không được âm.");
  if (input.transitionIn + input.transitionOut > input.length)
    errors.push("L1 + L2 không được lớn hơn KT.");
  if (input.chord >= 2 * input.radius)
    errors.push("Dây cung C phải nhỏ hơn 2R.");
  const step = input.chord / 2;
  if (step > 0 && (input.sampleOffset < -step || input.sampleOffset >= step))
    errors.push("Vị trí điểm đo đầu phải nằm trong khoảng [-C/2, C/2).");
  if (
    step > 0 &&
    Math.ceil((input.length - input.sampleOffset) / step) + 1 > CURVE_ROW_LIMIT
  )
    errors.push(
      `Bảng vượt ${CURVE_ROW_LIMIT.toLocaleString("vi-VN")} điểm. Hãy tăng dây cung C hoặc chia đoạn tính.`
    );
  if (
    step === 0 ||
    !Object.values(input).every(value =>
      Number.isSafeInteger(Math.round(value * 1000))
    )
  ) {
    errors.push(
      "Số liệu vượt miền biểu diễn chính xác đến milimét; hãy kiểm tra đơn vị và giá trị."
    );
  }
  return errors;
}

function assertInput(input: CurveInput) {
  const errors = validateCurveInput(input);
  if (errors.length) throw new Error(errors.join(" "));
}

type Segment = { start: number; end: number; kStart: number; slope: number };
function segments(input: CurveInput): Segment[] {
  const {
    transitionIn: l1,
    transitionOut: l2,
    length: length,
    radius: r,
  } = input;
  const result: Segment[] = [];
  if (l1 > 0) result.push({ start: 0, end: l1, kStart: 0, slope: 1 / r / l1 });
  if (length - l2 > l1)
    result.push({ start: l1, end: length - l2, kStart: 1 / r, slope: 0 });
  if (l2 > 0)
    result.push({
      start: length - l2,
      end: length,
      kStart: 1 / r,
      slope: -(1 / r) / l2,
    });
  return result;
}

/**
 * Same small-angle versine model as the workbook, in mm.
 * F(x) = 500 ∫ (h - |t-x|) κ(t) dt, h=C/2.
 * Each clipped segment is split at x. Its integrand is a quadratic, so Simpson's
 * three-point integration is exact for this piecewise-linear curvature model.
 * This is NOT the exact circular sagitta or a general compound-curve solution.
 */
function versineUnchecked(input: CurveInput, distance: number): number {
  const h = input.chord / 2;
  let integral = 0;
  for (const segment of segments(input)) {
    const low = Math.max(segment.start, distance - h);
    const high = Math.min(segment.end, distance + h);
    if (high <= low) continue;
    const cuts =
      low < distance && distance < high ? [low, distance, high] : [low, high];
    const integrand = (t: number) =>
      Math.max(0, h - Math.abs(t - distance)) *
      Math.max(0, segment.kStart + segment.slope * (t - segment.start));
    for (let i = 0; i < cuts.length - 1; i++) {
      const a = cuts[i],
        b = cuts[i + 1];
      integral +=
        ((b - a) / 6) *
        (integrand(a) + 4 * integrand((a + b) / 2) + integrand(b));
    }
  }
  const value = integral * 500;
  if (!Number.isFinite(value))
    throw new Error(
      "Số liệu quá lớn hoặc quá nhỏ để tính an toàn. Hãy kiểm tra lại đơn vị và giá trị."
    );
  return Math.max(0, value);
}

export function versineAt(input: CurveInput, distance: number): number {
  assertInput(input);
  if (!Number.isFinite(distance))
    throw new Error("Vị trí x phải là số hữu hạn (m).");
  return versineUnchecked(input, distance);
}

export function formatChainage(value: number): string {
  if (!Number.isFinite(value)) return "—";
  const sign = value < 0 ? "−" : "";
  const rounded = Math.round(Math.abs(value) * 1000) / 1000;
  const km = Math.floor(rounded / 1000);
  const metres = (rounded - km * 1000)
    .toFixed(3)
    .replace(".", ",")
    .padStart(7, "0");
  return `${sign}Km${km}+${metres}`;
}

export function calculateCurve(input: CurveInput): CurveResult {
  assertInput(input);
  const {
    chord,
    radius,
    length,
    transitionIn: l1,
    transitionOut: l2,
    sampleOffset,
  } = input;
  const step = chord / 2;
  const fc = 125 * (chord / radius) * chord;
  const rawBoundaries: { label: string; distance: number }[] = [
    { label: "NĐ", distance: 0 },
    { label: "TĐ", distance: l1 },
    { label: "TC", distance: length - l2 },
    { label: "NC", distance: length },
  ];
  const grouped: { label: string; distance: number }[] = [];
  for (const point of rawBoundaries) {
    const same = grouped.find(
      existing => Math.abs(existing.distance - point.distance) < 1e-8
    );
    if (same) same.label += ` / ${point.label}`;
    else grouped.push({ ...point });
  }
  const boundaries = grouped.map(point => {
    const position = (point.distance - sampleOffset) / step;
    const nearest = Math.round(position);
    const placement =
      Math.abs(position - nearest) < 1e-8
        ? `Trùng điểm ${nearest}`
        : position < 0
          ? "Trước điểm đo đầu"
          : `Giữa điểm ${Math.floor(position)} và ${Math.ceil(position)}`;
    return {
      ...point,
      chainage: input.startChainage + point.distance,
      f: versineUnchecked(input, point.distance),
      placement,
    };
  });
  const count = Math.ceil((length - sampleOffset) / step) + 1;
  const rows = Array.from({ length: count }, (_, index) => {
    const distance = sampleOffset + index * step;
    const label = boundaries
      .filter(point => Math.abs(point.distance - distance) < 1e-7)
      .map(point => point.label)
      .join(" · ");
    const region =
      distance < 0 || distance > length
        ? "Đường thẳng ngoài cong"
        : l1 > 0 && distance < l1
          ? "Hòa hoãn vào"
          : l2 > 0 && distance > length - l2
            ? "Hòa hoãn ra"
            : "Đường cong tròn";
    return {
      index,
      distance,
      chainage: input.startChainage + distance,
      region,
      label,
      f: versineUnchecked(input, distance),
    };
  });
  const warnings: string[] = [];
  if (chord / radius > 0.1)
    warnings.push(
      "C/R > 0,1: xấp xỉ góc nhỏ có thể sai lệch đáng kể. Cần kiểm tra hình học trước khi dùng ngoài hiện trường."
    );
  if ((l1 > 0 && l1 < step) || (l2 > 0 && l2 < step))
    warnings.push(
      "Hòa hoãn ngắn hơn C/2: công cụ tích phân toàn bộ vùng dây cung; các IF chia vùng trong Excel mẫu có thể không phù hợp."
    );
  const zIn = l1 > 0 ? 500 * (step / radius) * (step / l1) * step : null;
  const zOut = l2 > 0 ? 500 * (step / radius) * (step / l2) * step : null;
  const totalAngleDegrees =
    (((length - (l1 + l2) / 2) / radius) * 180) / Math.PI;
  if (
    ![
      fc,
      zIn ?? 0,
      zOut ?? 0,
      totalAngleDegrees,
      ...rows.map(row => row.chainage),
    ].every(Number.isFinite)
  ) {
    throw new Error(
      "Kết quả không hữu hạn. Hãy kiểm tra lại đơn vị và số liệu."
    );
  }
  return {
    input: { ...input },
    step,
    fc,
    zIn,
    zOut,
    circularLength: length - l1 - l2,
    totalAngleDegrees,
    rows,
    boundaries,
    warnings,
  };
}

export function calculateCircularElements(
  radius: number,
  degrees: number,
  minutes: number,
  seconds: number
) {
  if (![radius, degrees, minutes, seconds].every(Number.isFinite))
    throw new Error("Nhập đầy đủ bán kính và góc hợp lệ.");
  if (radius <= 0) throw new Error("Bán kính R phải lớn hơn 0 m.");
  if (degrees < 0 || !Number.isInteger(degrees))
    throw new Error("Độ phải là số nguyên không âm; nhập phần lẻ ở phút/giây.");
  if (
    minutes < 0 ||
    minutes >= 60 ||
    !Number.isInteger(minutes) ||
    seconds < 0 ||
    seconds >= 60
  )
    throw new Error(
      "Phút phải là số nguyên 0–59; giây phải từ 0 đến nhỏ hơn 60."
    );
  const angleDegrees = degrees + minutes / 60 + seconds / 3600;
  if (angleDegrees <= 0 || angleDegrees >= 180)
    throw new Error("Góc tổng phải lớn hơn 0° và nhỏ hơn 180°.");
  const radians = (angleDegrees * Math.PI) / 180;
  const result = {
    radius,
    angleDegrees,
    radians,
    tangent: radius * Math.tan(radians / 2),
    length: radius * radians,
    external: radius * (1 / Math.cos(radians / 2) - 1),
  };
  if (!Object.values(result).every(Number.isFinite))
    throw new Error(
      "Kết quả hình học không hữu hạn; hãy kiểm tra bán kính và góc."
    );
  return result;
}

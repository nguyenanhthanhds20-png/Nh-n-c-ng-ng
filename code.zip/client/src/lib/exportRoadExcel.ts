import ExcelJS from "exceljs";

export type RoadExportRecord = {
  id: string;
  kind: string;
  route: string;
  month: number | string | null;
  qty: number | string | null;
  labor_total: number | null;
  tasks: Array<{ name: string; unit: string; qty: number | string; rate: number | null; labor: number | null }>;
  materials: Array<{ name: string; unit: string; qty: number }>;
};

type ExportOptions = { dataFileName?: string; year?: number; now?: Date };
const FONT = "Times New Roman";
const THIN: Partial<ExcelJS.Border> = { style: "thin", color: { argb: "FF000000" } };
const HAIR: Partial<ExcelJS.Border> = { style: "hair", color: { argb: "FF000000" } };

function finite(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function textNumber(value: number | string | null) {
  return typeof value === "number" && Number.isFinite(value)
    ? value.toLocaleString("vi-VN", { minimumFractionDigits: 1, maximumFractionDigits: 1 })
    : String(value ?? "");
}

function period(record: RoadExportRecord, options: ExportOptions) {
  const dated = typeof record.month === "string" ? /^(20\d{2})-(\d{1,2})$/.exec(record.month) : null;
  const month = dated ? Number(dated[2]) : Number(record.month);
  const sourceYear = options.dataFileName?.match(/(?:19|20)\d{2}/)?.[0];
  const year = options.year ?? (dated ? Number(dated[1]) : sourceYear ? Number(sourceYear) : (options.now ?? new Date()).getFullYear());
  return { month: Number.isInteger(month) && month >= 1 && month <= 12 ? String(month).padStart(2, "0") : "……", year };
}

function bodyHeight(value: string, characters = 43) {
  let lines = 0;
  for (const paragraph of value.normalize("NFC").split(/\r?\n/)) {
    let width = 0;
    lines++;
    for (const word of paragraph.split(/\s+/)) {
      if (width && width + word.length + 1 > characters) { lines++; width = 0; }
      if (word.length > characters) { lines += Math.floor(word.length / characters); width = word.length % characters; }
      else width += (width ? 1 : 0) + word.length;
    }
  }
  return Math.max(18.75, lines * 14.5 + 3);
}

/** Clean, single-sheet reconstruction of the user's active “539 - 540” template. */
export function createRoadWorkbook(record: RoadExportRecord, options: ExportOptions = {}) {
  const book = new ExcelJS.Workbook();
  book.creator = "Đường sắt Quảng Bình";
  book.created = options.now ?? new Date();
  book.calcProperties.fullCalcOnLoad = true;
  const sheet = book.addWorksheet("Bóc khối lượng", {
    properties: { defaultRowHeight: 18 },
    views: [{ showGridLines: false }],
    pageSetup: {
      paperSize: 9,
      orientation: "portrait",
      fitToPage: true,
      fitToWidth: 1,
      fitToHeight: 0,
      horizontalCentered: true,
      margins: { left: 0.590551, right: 0.393701, top: 0.590551, bottom: 0.590551, header: 0, footer: 0.2 },
    },
  });
  [4.5, 24, 15, 8.5, 10.5, 11.5, 11.5].forEach((width, index) => { sheet.getColumn(index + 1).width = width; });

  const set = (address: string, value: ExcelJS.CellValue, bold = false, size = 12, horizontal: ExcelJS.Alignment["horizontal"] = "left") => {
    const cell = sheet.getCell(address);
    cell.value = value;
    cell.font = { name: FONT, size, bold, color: { argb: "FF000000" } };
    cell.alignment = { horizontal, vertical: "middle", wrapText: true };
    return cell;
  };
  const merged = (range: string, value: ExcelJS.CellValue, bold = false, size = 12, horizontal: ExcelJS.Alignment["horizontal"] = "left") => {
    sheet.mergeCells(range);
    return set(range.split(":")[0], value, bold, size, horizontal);
  };
  const borderRow = (row: number, header = false) => {
    for (let column = 1; column <= 7; column++) {
      const cell = sheet.getCell(row, column);
      cell.font = { name: FONT, size: header ? 13 : 12, bold: header, color: { argb: "FF000000" } };
      cell.alignment = { horizontal: "center", vertical: "middle", wrapText: true };
      cell.border = { top: header ? THIN : HAIR, bottom: header ? THIN : HAIR, left: THIN, right: THIN };
    }
  };
  // Crossing records count an object, not a length; the input does not define their header unit.
  const kind = record.kind.toLocaleLowerCase("vi");
  const qtyUnit = kind.includes("ghi") ? "bộ" : kind === "đường ngang" ? "" : "m";
  const reportPeriod = period(record, options);
  merged("A1:B1", "CÔNG TY CỔ PHẦN", true, 12, "center");
  merged("C1:G1", "CỘNG HOÀ XÃ HỘI CHỦ NGHĨA VIỆT NAM", true, 12, "center");
  merged("A2:B2", "ĐƯỜNG SẮT QUẢNG BÌNH", true, 12, "center");
  merged("C2:G2", "Độc lập - Tự do - Hạnh phúc", true, 12, "center");
  merged("C4:G4", "…………, ngày …… tháng …… năm …………", false, 13, "right").font.italic = true;
  merged("A6:G6", "BIÊN BẢN ĐIỀU TRA KHỐI LƯỢNG BDĐK", true, 14, "center");
  merged("A7:G7", `SẢN PHẨM ${record.kind.toLocaleUpperCase("vi")}`, true, 14, "center");
  merged("A8:G8", `THÁNG ${reportPeriod.month} NĂM ${reportPeriod.year}`, false, 12, "center");
  merged("A9:D9", `LÝ TRÌNH: ${record.route}`);
  merged("E9:G9", record.qty === null || record.qty === "" ? "KHỐI LƯỢNG: ……………" : `KHỐI LƯỢNG: ${textNumber(record.qty)} ${qtyUnit}`.trimEnd());
  merged("A10:G10", "THÀNH PHẦN:");
  merged("A11:C11", "1. Ông/Bà: ………………………………");
  merged("D11:G11", "Chức danh: ………………………………");
  merged("A12:C12", "2. Ông/Bà: ………………………………");
  merged("D12:G12", "Chức danh: ………………………………");
  merged("A13:G13", "KHỐI LƯỢNG CÔNG VIỆC", true);
  [14.25, 16.5, 5, 16.5, 5, 18.75, 18.75, 16.5, bodyHeight(`LÝ TRÌNH: ${record.route}`, 49), 18, 18.75, 18.75, 18.75, 18, 16.5].forEach((height, index) => { sheet.getRow(index + 1).height = height; });
  borderRow(14, true); borderRow(15, true);
  merged("A14:A15", "TT", true, 13, "center");
  merged("B14:C15", "Hạng mục công việc", true, 13, "center");
  merged("D14:D15", "Đơn vị", true, 13, "center");
  set("E14", "K.lượng", true, 13, "center");
  set("E15", "Đ. tra", true, 13, "center");
  merged("F14:F15", "Đ.mức", true, 13, "center");
  merged("G14:G15", "T.công", true, 13, "center");

  const firstTask = 16;
  const taskCount = Math.max(1, record.tasks.length);
  let laborSum = 0;
  for (let index = 0; index < taskCount; index++) {
    const row = firstTask + index;
    const task = record.tasks[index];
    borderRow(row);
    merged(`B${row}:C${row}`, task?.name ?? "Chưa có hạng mục công việc");
    if (task) {
      set(`A${row}`, index + 1, false, 12, "center");
      set(`D${row}`, task.unit, false, 12, "center");
      set(`E${row}`, typeof task.qty === "number" ? finite(task.qty) : task.qty, false, 12, "right").numFmt = "0.0";
      set(`F${row}`, finite(task.rate), false, 12, "right").numFmt = "0.0000";
      // Labor is authoritative source data, not inferred from rounded quantity/rate.
      const labor = finite(task.labor);
      set(`G${row}`, labor, false, 12, "right").numFmt = "0.0";
      laborSum += labor ?? 0;
    }
    sheet.getRow(row).height = bodyHeight(task?.name ?? "Chưa có hạng mục công việc");
  }
  const lastTask = firstTask + taskCount - 1;
  const totalRow = lastTask + 1;
  borderRow(totalRow, true);
  merged(`B${totalRow}:C${totalRow}`, "Tổng công", true, 12, "center");
  set(`D${totalRow}`, "công", true, 12, "center");
  set(`G${totalRow}`, { formula: `SUM(G${firstTask}:G${lastTask})`, result: laborSum }, true, 12, "right").numFmt = "0.0";
  sheet.getRow(totalRow).height = 22;

  const materialTitleRow = totalRow + 2;
  if (finite(record.labor_total) !== null && Math.abs(record.labor_total! - laborSum) > 0.051) {
    merged(`A${totalRow + 1}:G${totalRow + 1}`, `Nhân công theo biểu: ${textNumber(record.labor_total)} công; tổng chi tiết: ${textNumber(laborSum)} công. Cần đối chiếu số liệu nguồn.`, false, 10).font.italic = true;
    sheet.getRow(totalRow + 1).height = 28;
  } else sheet.getRow(totalRow + 1).height = 8;
  merged(`A${materialTitleRow}:G${materialTitleRow}`, "VẬT TƯ ĐƯA VÀO CÔNG TRÌNH", true);
  sheet.getRow(materialTitleRow).height = 25;
  const materialHeader = materialTitleRow + 1;
  borderRow(materialHeader, true); borderRow(materialHeader + 1, true);
  merged(`A${materialHeader}:A${materialHeader + 1}`, "TT", true, 13, "center");
  merged(`B${materialHeader}:C${materialHeader + 1}`, "Tên vật tư - Quy cách", true, 13, "center");
  merged(`D${materialHeader}:D${materialHeader + 1}`, "Đơn vị", true, 13, "center");
  set(`E${materialHeader}`, "Số lượng", true, 13, "center");
  set(`E${materialHeader + 1}`, "Đ. tra", true, 13, "center");
  merged(`F${materialHeader}:G${materialHeader + 1}`, "Ghi chú", true, 13, "center");
  sheet.getRow(materialHeader).height = 20;
  sheet.getRow(materialHeader + 1).height = 18;
  const firstMaterial = materialHeader + 2;
  const materialCount = Math.max(1, record.materials.length);
  for (let index = 0; index < materialCount; index++) {
    const row = firstMaterial + index;
    const material = record.materials[index];
    borderRow(row);
    merged(`B${row}:C${row}`, material?.name ?? "Chưa có vật tư");
    merged(`F${row}:G${row}`, "");
    if (material) {
      set(`A${row}`, index + 1, false, 12, "center");
      set(`D${row}`, material.unit, false, 12, "center");
      set(`E${row}`, finite(material.qty), false, 12, "right").numFmt = "0.0";
    }
    sheet.getRow(row).height = bodyHeight(material?.name ?? "Chưa có vật tư");
  }
  const signature = firstMaterial + materialCount + 1;
  sheet.getRow(signature - 1).height = 10;
  merged(`A${signature}:C${signature}`, "ĐƠN VỊ", true, 13, "center");
  merged(`D${signature}:G${signature}`, "ĐỘI QLĐS …", true, 13, "center");
  merged(`A${signature + 1}:C${signature + 1}`, "(Ký, ghi rõ họ tên)", false, 11, "center").font.italic = true;
  merged(`D${signature + 1}:G${signature + 1}`, "(Ký, ghi rõ họ tên)", false, 11, "center").font.italic = true;
  sheet.getRow(signature).height = 22;
  sheet.getRow(signature + 1).height = 18;
  sheet.getRow(signature + 2).height = 24;
  sheet.getRow(signature + 3).height = 24;
  merged(`A${signature + 4}:C${signature + 4}`, "………………………………", false, 12, "center");
  merged(`D${signature + 4}:G${signature + 4}`, "………………………………", false, 12, "center");
  sheet.getRow(signature + 4).height = 18;
  sheet.pageSetup.printArea = `A1:G${signature + 4}`;
  // Keep ordinary records on one A4 sheet, but never shrink long reports to unreadable size.
  let printHeight = 0;
  for (let row = 1; row <= signature + 4; row++) printHeight += sheet.getRow(row).height ?? 18;
  sheet.pageSetup.fitToHeight = printHeight <= 900 ? 1 : 0;
  return book;
}

export function roadExcelFilename(record: Pick<RoadExportRecord, "route" | "id">) {
  const name = (record.route || record.id || "duong").replace(/[<>:"/\\|?*\u0000-\u001f]/g, "-").replace(/\s+/g, "-").slice(0, 120);
  return `boc-khoi-luong-${name}.xlsx`;
}

export async function downloadRoadExcel(record: RoadExportRecord, options: ExportOptions = {}) {
  const book = createRoadWorkbook(record, options);
  const buffer = await book.xlsx.writeBuffer();
  const bytes = new Uint8Array(buffer).buffer;
  const url = URL.createObjectURL(new Blob([bytes], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = roadExcelFilename(record);
  document.body.appendChild(link);
  try { link.click(); } finally {
    link.remove();
    // Allow the browser to start reading before releasing its object URL.
    window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
  }
}

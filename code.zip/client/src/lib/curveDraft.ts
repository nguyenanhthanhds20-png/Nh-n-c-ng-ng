export type CurveDraft = {
  mode: "circular" | "transition";
  form: {
    name: string;
    radius: string;
    transitionIn: string;
    transitionOut: string;
    length: string;
    chord: string;
    startChainage: string;
    sampleOffset: string;
  };
  circularForm: {
    radius: string;
    degrees: string;
    minutes: string;
    seconds: string;
  };
  position: string;
  sourceBanner: string;
  includeCircular: boolean;
};
const KEY = "rail-curve-draft-v1";
let memoryDraft: CurveDraft | null = null;

function validDraft(value: unknown): value is CurveDraft {
  if (!value || typeof value !== "object") return false;
  const draft = value as Partial<CurveDraft>;
  if (draft.mode !== "circular" && draft.mode !== "transition") return false;
  const formKeys = [
    "name",
    "radius",
    "transitionIn",
    "transitionOut",
    "length",
    "chord",
    "startChainage",
    "sampleOffset",
  ] as const;
  const circularKeys = ["radius", "degrees", "minutes", "seconds"] as const;
  return (
    !!draft.form &&
    formKeys.every(key => typeof draft.form?.[key] === "string") &&
    !!draft.circularForm &&
    circularKeys.every(key => typeof draft.circularForm?.[key] === "string") &&
    typeof draft.position === "string" &&
    typeof draft.sourceBanner === "string" &&
    typeof draft.includeCircular === "boolean"
  );
}

export function readCurveDraft(): CurveDraft | null {
  if (memoryDraft) return memoryDraft;
  if (typeof window === "undefined") return null;
  try {
    const serialized = window.localStorage.getItem(KEY);
    if (!serialized) return null;
    const draft: unknown = JSON.parse(serialized);
    if (validDraft(draft)) {
      memoryDraft = draft;
      return draft;
    }
  } catch {
    /* Storage may be disabled in embedded/private browsing. */
  }
  return null;
}

export function saveCurveDraft(draft: CurveDraft): void {
  // Memory fallback still preserves the draft across tab unmount/remount.
  memoryDraft = draft;
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(draft));
  } catch {
    /* Do not stop calculations when durable browser storage is blocked. */
  }
}
